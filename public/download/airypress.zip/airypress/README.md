# AiryPress

A WordPress plugin by [DigitalBrew](https://digitalbrew.io) that reskins and trims **wp-admin**. It gives the admin a modern look, removes clutter, and adds a few tools agencies need on every client site: a menu builder, a branded login screen, a maintenance page and a Google Analytics widget.

Everything is configured at **Settings → AiryPress**. No config files and no code are needed.

- **Requires:** WordPress 6.8+ (built and tested on 7.1), PHP 8.2+ (tested on 8.5)
- **Version:** 1.1.0

## What it does

Every feature is a toggle and can be switched off on its own. The settings page is split into tabs:

| Tab | What you get |
| --- | --- |
| **Appearance** | The admin theme: a dark frame, a 240px sidebar, a rounded content card that scrolls on its own, the Inter font and an accent colour of your choice. Also accordion submenus, accent colours inside the block editor, faster navigation (pages load on hover and fade between each other) and a custom footer text. |
| **Menu builder** | Drag and drop the admin menu: reorder items, move them under another parent (up to four levels), rename them, change icons (Dashicons or your own SVG), add custom links, headings and separators, and hide items for everyone or for chosen roles. |
| **Toolbar** | Choose which WordPress toolbar items stay visible and, with Pro, which plugin items are shown (every plugin item stays until you untick one). Choose who sees the toolbar on the front end, and replace “Howdy, …” with the user's name. |
| **Dashboard** | Choose exactly which widgets show: WordPress' own (all on by default), AiryPress's (the Site analytics widget) and, with Pro, ones plugins add (all kept until you untick one; inactive plugins are greyed out). Plus a **welcome widget** for clients (your logo, a message, a button such as “Read our knowledge base” and how-to links) and, with Pro, a **request widget**: a form with a title, message and attachments that lands in your inbox or a Slack channel. |
| **Content & tables** | Turn comments and blog posts off site-wide. For every post type's list (Posts, Pages, Products…): drag columns into order, hide any of them, choose which can be sorted, and add extra ones: featured image, ID, slug, last modified, template, order, total sales and any ACF field. Users and WooCommerce Orders columns too (last login, registration date, purchased products). |
| **Admin clean-up** | Hide Help tabs, Screen Options and update nags. Disable the admin email check. Turn off Appearance screens one by one (Themes, Design, Customizer, Fonts, Menus, Widgets, Patterns) and automatic updates. **Notice manager:** snooze plugin notices, or tuck them behind an “N notices” button for chosen roles or everyone. |
| **Front end** | Remove emoji scripts, feeds, extra `<head>` links, `?ver=` strings, oEmbed and DNS prefetch. Control jQuery and jQuery Migrate. |
| **Security** | Turn XML-RPC off, hide the REST users endpoint from visitors, and block `?author=N` username scans. |
| **Login** | Brand wp-login.php with your logo, a background colour and image, a message above the form and the accent colour. Hide the language switcher, and link the logo to your site. |
| **Maintenance** | Show visitors a holding page with your own title, subtitle, body text, background colour, background image and text colour. Anyone who can edit content still sees the site. |
| **Analytics** | A full-width GA4 dashboard widget (visitors, page views, chart, top pages, sources, devices) and a live “N online” counter in the toolbar. **Tracking:** add the GA4 tag (gtag.js) by Measurement ID, with Google Consent Mode (denied until the cookie banner grants consent) and without tracking logged-in editors; plus the Search Console verification tag. |
| **White label** | A brand name instead of “WordPress” in admin page titles, your logo at the top of the sidebar, and **settings access**: only chosen administrators can change AiryPress (and see it on the Plugins screen). |
| **Site identity** | The favicon (every icon size, on the site, the admin and the login screen) and Open Graph / X card tags: a default share image, homepage title and description, X username and Facebook App ID, plus an optional “Social sharing” sidebar box on every page, post and custom post type for its own title, description and image. Social tags are skipped while Yoast SEO, SEOPress, Rank Math or All in One SEO is active, so they're never duplicated. |
| **Tools** | Export, import or reset all settings as JSON. |

### Maintenance mode details

- Visitors get a **503 Service Unavailable** status with a `Retry-After` header, so search engines come back later instead of dropping your pages.
- Logged-in users who can edit posts see the normal site, with a red **Maintenance mode** badge in the toolbar.
- The admin, the login screen, the REST API, AJAX and cron keep working.
- Administrators can preview the page at any time, even while it is off, at `/?airy-maintenance-preview=1` (there is also a button in the Maintenance tab).

### Google Analytics setup

The widget reads GA4 through a Google service account. Its key is never stored in the database. Set it in `.env` (Bedrock) or in `wp-config.php`:

```php
define('AIRYPRESS_GA_CREDENTIALS', '/path/outside/webroot/service-account.json'); // or the raw JSON string
define('AIRYPRESS_GA_PROPERTY_ID', '123456789'); // optional, can also be set in the settings
```

Give the service account's email **Viewer** access to the GA4 property. Then use **Test connection** in the Analytics tab.

## Free and Pro

AiryPress is free; **AiryPress Pro** adds the Modern and Light themes, menu builder, plugin toolbar/widget clean-up, post type columns, GA4 reports, notice manager, white label and social tags. See [docs/free-and-pro.md](docs/free-and-pro.md). The agency's own client sites define `AIRYPRESS_AGENCY` and get everything.

## Documentation

Full user documentation, tab by tab, is in [`docs/`](docs/README.md).

## Plugin compatibility

The admin theme is a layer on top of WordPress' own admin styles. It never replaces them, so most plugins just work. The plugins below were checked page by page, on desktop (1440px) and mobile (390px), with WordPress 7.1. Where a plugin needed a fix, the fix is built into AiryPress.

| Plugin | Status | Notes |
| --- | --- | --- |
| WooCommerce 11 | ✅ Adjusted | React admin pages fit the card; the store-visibility badge is a toolbar button with a status dot; wide tab strips and the activity panel scroll on mobile. |
| Gravity Forms 3.1 (+ CLI, HubSpot, Mailchimp, Webhooks add-ons) | ✅ Adjusted | The form editor's toolbar and sidebars line up with the card; the New Form modal and its backdrop stay inside the card; dropdowns and Help pages fixed. |
| Gravity SMTP | ✅ | |
| Yoast SEO 28 | ✅ Adjusted | React pages fit the card; its notification toasts sit next to the sidebar. |
| SEOPress 10 | ✅ Adjusted | SEOPress unloads a core stylesheet the theme used to depend on, and its fixed header bar now sits on the card. |
| Rank Math SEO 1.0 | ✅ Adjusted | Its switches work with the theme's toggle styles; its notices run full width. |
| Advanced Custom Fields PRO 6.8 | ✅ Adjusted | WYSIWYG fields share the classic-editor style; button groups are segmented controls. Plus ACF Extended, ACF QuickEdit Fields and the ACF Gravity Forms add-on. |
| MonsterInsights 11 | ✅ Adjusted | Its settings screen no longer pushes the sidebar down. |
| The Events Calendar 6.17 | ✅ Adjusted | Accent colour applied to its setup guide; wide Help pages scroll inside the card. |
| All-in-One WP Migration 7 | ✅ Adjusted | Its forced menu colour is overridden, so the current item keeps the accent. |
| WPConsent | ✅ Adjusted | Its header runs edge to edge again. |
| Beautiful and responsive cookie consent | ✅ Adjusted | Its minimum page width no longer causes sideways scrolling on phones. |
| Redirection, Akismet | ✅ Adjusted | Screen Options/Help tabs no longer cover their notices. |
| Complianz, CookieAdmin, Cookie Bar, Cookiebot, Cookie Notice, iubenda | ✅ | Cookiebot needs a connected account for its own pages to load data. |
| TablePress 3.3 | ✅ Adjusted | In the table editor the row numbers stay in their own column, the sticky title bar and column header stick to the top of the card, and the title bar spans the full width. |
| Contact Form 7 6 | ✅ Adjusted | The shortcode box uses the accent colour, with rounded corners. |
| Post Types Order, Duplicate Page, Enable Media Replace, Safe SVG, Simple Custom CSS and JS | ✅ | |
| HubSpot (Leadin), Meta pixel, ShareThis, Social Intents, Better Click To Share | ✅ | HubSpot needs a connected account for its own pages to load data. |
| Really Simple Security, Two Factor | ✅ | |
| WP Migrate (Pro), Spatie Ray | ✅ | |
| Query Monitor | ⚠️ Works, with a server caveat | Query Monitor sends very large response headers. On nginx with default buffers this causes `502 upstream sent too big header` errors, with or without AiryPress. Raise `fastcgi_buffer_size` / `fastcgi_buffers`, or keep it off in production. |

WordPress core screens are covered too, including the React-based Fonts and Connectors screens, which get the accent colour. The block editor keeps its own layout: AiryPress only applies the accent colour there.

Found a plugin that doesn't look right? Open an issue with the plugin name, the admin page and a screenshot.

## Installation

AiryPress is installed with Composer from GitHub:

```json
{
  "repositories": [
    { "type": "vcs", "url": "git@github.com:digital-brew/airypress" }
  ],
  "require": {
    "digital-brew/airypress": "dev-main"
  }
}
```

Then activate it and open **Settings → AiryPress**. The built assets (`dist/`) and the autoloader (`vendor/`) are committed, so client sites need no build step.

## Development

Requires Node 25 and Composer.

```bash
npm install
npm run build      # builds assets/ into dist/ (commit the result)
npm run dev        # rebuild on change
composer install   # autoloader only
```

- `src/`: PHP. Each module in `src/Modules/` only adds hooks. Settings are declared in `src/Settings/Schema.php`.
- `assets/`: plain CSS and vanilla ES modules, built with Vite.
- All theme CSS is scoped to `body.airy-theme`, and core admin stylesheets are never removed.

Developer hooks (filters and actions) are listed in [docs/developers.md](docs/developers.md#hooks). See [AGENTS.md](AGENTS.md) for architecture notes and the rules behind the plugin-compatibility fixes.

## License

GPL-2.0-or-later
