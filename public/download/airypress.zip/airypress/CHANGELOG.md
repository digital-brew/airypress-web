# Changelog

All notable changes to AiryPress. The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses [Semantic Versioning](https://semver.org/).

## [1.1.0] — 2026-10-29

### Added

- **Free and Pro** (Freemius): one codebase, a free build without the Pro code, "Pro" pills on Pro settings, one AiryPress Pro card on the About tab. Agency mode (`AIRYPRESS_AGENCY`) keeps every feature on the agency's own sites. The Freemius Account, Contact Us, Upgrade (pricing) and opt-in screens follow the admin theme, with the AiryPress icon.
- **Row actions menu** (admin theme): list-table actions (Edit, Quick Edit, Trash, View and ones plugins add) move into a "⋮" menu at the end of each row; Trash and Delete sit last, in red. The Plugins screen keeps its own links. Quick Edit opens in a modal (dropdowns highlight in the accent colour), rows are centred vertically, and each title is followed by the post's status (Published included) and states as pills.
- **Request widget** (Pro, Dashboard): a description and a button that opens a modal form, where clients send a title, message and attachments to your inbox (Reply-To is the sender), a Slack channel through an incoming webhook, or both. "Create the Slack app" opens Slack with the app set up, and "Send a test message" checks the webhook. Every request is also saved in a Requests menu above Appearance, for your agency's administrators only, with its delivery status and attachments.
- **Welcome widget** (Dashboard): logo, message, a button (e.g. "Read our knowledge base") and how-to links for clients; limit it to roles with Pro.
- **Notice manager** (Pro, Admin clean-up): snooze plugin notices per user, tuck them behind an "N notices" button for chosen roles, or hide chosen notices for everyone. Optionally, plugin notices go to a notifications bell in the toolbar instead (errors, and warnings unless chosen, stay on the page).
- **“Saved” messages as pop-ups** (Admin clean-up, on by default): success messages appear as a toast in the top-right corner that fades after a few seconds; errors and warnings stay on the page.
- Outside agency mode, after 14 days, a one-time "Enjoying AiryPress? A review helps a lot" link next to Save changes.
- **White label** tab (Pro): brand name in admin page titles, sidebar logo (at the top or fixed above Collapse Menu, with a size slider; a dark version for the Light theme and an optional light one for the dark sidebars), and settings access — only chosen administrators can change AiryPress or see it on the Plugins screen.
- Developer hooks: `airypress/settings`, `airypress/modules`, `airypress/loaded`, `airypress/settings_saved`/`_imported`/`_reset`, theme, navigation, toolbar, dashboard, columns, maintenance, tracking and social filters. See [docs/developers.md](docs/developers.md#hooks).
- **Admin themes** (Appearance → Theme; Modern and Light are Pro). *Default* (the dark frame). *Modern*: the dark sidebar runs to the top of the screen, with a taller (56px) white toolbar on top of a light grey content card with white boxes. *Light*: a light sheet with the content as a rounded container. Each user can override it in their profile or from the account menu (Default / Modern / Light).
- **Account menu at the bottom of the sidebar** (Pro, Toolbar → Account menu position): name and avatar pinned to the bottom of the sidebar, the card opening upwards, and the Ctrl+K command palette shown as a Search field in the middle of the toolbar.
- Collapse Menu is an icon button in the sidebar's top-right corner (next to a top logo) instead of a row at the bottom.
- The session-expired login dialog drops the login background image and follows the admin theme: dark for Default, light for Light and Modern.
- Sidebar count bubbles are translucent rounded rectangles at the end of the row instead of accent circles.
- Settings switches are 40×22 rounded squares, grey when off and near-black when on; checked checkboxes and radios are near-black too.
- Collapsed-sidebar submenu cards take the sidebar's colours, with the card's corner radius; so do the hover cards when accordion submenus are off.
- Collapsing the sidebar animates.
- Form screens (Settings, profile, users, Tools, Site Health, AiryPress) sit in a centred column (at most 900px; 1150px for AiryPress and Settings → General, Reading, Media, Permalinks, Privacy and Connectors, so they line up); list tables keep the full width.
- WooCommerce screens match the theme: fields and searchable selects, settings and status tabs, help tips, buttons, page titles, toggles, Reports period bar and chart colours, and report filters.
- Dashboard widgets and empty drop zones have rounded corners.
- **About tab** (Settings → AiryPress): what AiryPress does, version and plan, Free and Pro side by side, links to the documentation for every tab, and what's new in this version. Every tab gets a Docs link in its top-right corner. Hidden while White label is on.
- Wide list tables (posts, pages, products, users…) scroll sideways inside their own box instead of squeezing every column: short values stay on one line, long text such as meta descriptions wraps at a readable width, and headers keep their sort arrows beside the label. Desktop only.
- Toolbar items (updates, live visitors, the notifications bell and items plugins add, such as Clear Caches) are small outlined buttons; on the Modern theme they and the search field are white pills with a soft shadow.
- Rounder content card corners (12px; 16px in the Light theme).
- **Account menu card**: site, user, Edit profile, theme switch and Log out; opens on click.
- **Toolbar visible-lists**: choose visible core items, and which items added by plugins stay (all of them until you untick one); plugin items are recorded for the checklist and greyed out when their plugin is inactive.
- **Dashboard visible-lists**: core widgets, AiryPress widgets (Site analytics) and plugin widgets.
- **Post type columns** (Content & tables): per post type, drag to order, show/hide, sort toggles, plus extra columns — featured image, ID, slug, last modified, template, order, total sales and ACF fields.
- **Appearance screen toggles** (Admin clean-up): Themes, Design, Customizer, Fonts, Menus, Widgets, Patterns.
- **Tracking** (Analytics): GA4 tag with Consent Mode defaults, editors excluded, Search Console verification, and the Meta Pixel (waits for marketing consent).
- **Site identity** tab: favicon (WordPress' Site Icon) and Open Graph / X card tags with an optional per-page "Social sharing" sidebar box (Per-page share details); skipped while Yoast SEO, SEOPress, Rank Math or All in One SEO is active.
- **Flyout submenus** with hover intent for the folded sidebar and when accordion submenus are off.
- **Tools**: copy/paste buttons, Export to JSON and Import from JSON files; reset asks for confirmation.
- Footer version turns orange when a WordPress update is available.
- User documentation in `docs/`.

### Changed

- **Defaults change only the look.** A new install switches on the admin theme, the accent colour and the toolbar tidy-up; comments, Posts, feeds, emoji, head links, XML-RPC, every core dashboard widget, the dashboard widgets and toolbar items plugins add (kept until you untick one), the admin email check, the menu and the other clean-up, table, front-end and security options stay as WordPress has them until you choose otherwise. Agency mode keeps the previous tidy defaults.
- **Serve jQuery from a CDN** is now Pro (WordPress.org plugins may not load scripts from a CDN).
- The GA4 tag and the Meta Pixel are printed with WordPress' script-tag functions; the free plugin no longer loads its translations itself (WordPress.org does), and output is escaped where it's printed.
- Separate readmes: `readme.txt` for WordPress.org (with the External services section) and `readme-pro.txt` for Pro; a `languages/airypress.pot` template.
- Classic editors (the post editor where it's used, e.g. WooCommerce products, and ACF WYSIWYG fields): a rounded frame with a flat toolbar, accent active states, a segmented Visual/Code switch, a rounded link pop-up with an accent apply button, and content in Inter with accent links. ACF button group fields use the same segmented style as the Visual/Code switch.
- Plugins screen: active rows are tinted in the accent with an Active pill (Inactive pill on the others), no blue side bar; row links without separators (Activate in the accent, Delete in red); quieter version meta; update notices under a row show one icon.
- Site Health and Privacy settings: the header blends into the card, Status/Info is a segmented switch, issues sit in rounded cards with tinted category pills, and the Info tables are tidier.
- Themes screen: the active theme has an accent outline and a light accent name bar instead of the colour scheme's solid blue.
- Outside agency mode, automatic updates are a setting (Admin clean-up → Updates, off by default) and the admin footer text is empty by default.
- Notices: 1px border in the type colour, darker text, type icons, Tailwind status colours.
- Settings page: vertical tabs with icons, aligned checklists, version pill.
- Screen Options/Help tabs hang from the top of the content card; the Help panel matches the AiryPress style.
- Collapse Menu is fixed to the bottom-left corner; the sidebar scroll area ends above it.
- Page-load progress bar moved above the toolbar.
- Instructions for AI agents moved from `CLAUDE.md` to `AGENTS.md`.

### Removed

- The Plugins tab (ACF menu hiding, Yoast metabox position/toolbar menu/columns). Yoast's toolbar menu and columns are covered by the toolbar and column settings.

### Fixed

- Importing settings, or saving any tab, no longer turns "keep every plugin item" into a fixed list; the toolbar and dashboard plugin lists keep newly added items until you untick one.
- Analytics: the Right now panel no longer repeats its "Being viewed now" list on every refresh, and fetching a token no longer logs a PHP deprecation that could break the widget's data.
- The page-load progress bar no longer keeps running after a form that stays on the page (Plugins → Add New search, the Menus search).
- Locked Pro cards no longer show their working footer buttons (Create the Slack app, Send a test message).
- Notice manager: no PHP 8.4+ deprecation for notices registered as `Class::method` strings, and hiding one notice from an invokable object no longer hides the others on that hook.
- The analytics widget, the live visitors counter and the menu builder can be translated, and the analytics labels and Google error messages reach the translation template.
- Menu builder: Save says when a label has no name, and custom links no longer accept protocol-relative URLs (`//host/path`).
- The account menu's theme switch answers an expired session with an error instead of WordPress' HTML page; the request dialog closes on a backdrop click in every browser; menu accordion and group links tell screen readers they toggle.
- Rank Math: its switches show the knob at the right end when on (the theme's toggle styles had pushed it below the track), and its notices run full width like the others, instead of stopping at its 978px/1020px column.
- Toolbar: WooCommerce's "Store coming soon" / "Live" badge is a toolbar button like the others (readable text, an amber or green status dot, lined up with its neighbours), and Yoast's and SEOPress' count bubbles are 18px pills centred in their buttons instead of standing taller than the button or sitting low.
- Password fields (Add User, Profile): the strength meter is as wide as the input (ACF Extended made the input narrower), sits a little below it with rounded corners, and the Show/Hide button matches the input's height.
- Notices at the top of a screen (like "WordPress 7.1.3 is available!") run full width again instead of stopping short of Screen Options/Help, and the update notice's icon lines up with its text.
- Core's colour-scheme highlight classes (`.wp-ui-highlight` and friends) use the accent colour, so Contact Form 7's shortcode box is no longer blue; it also gets rounded corners.
- "This screen requires JavaScript" warnings (e.g. in the TablePress editor) no longer show when JavaScript is on.
- TablePress table editor: the row numbers no longer slide over the first column, its sticky title bar and column header stick to the top of the card, and the title bar's buttons sit at its right edge.
- Settings cards with their own content (Post type columns, Analytics connection) no longer wrap the cards after them.
- Pages added under Appearance by themes and plugins (`themes.php?page=…`) are no longer blocked when the Themes screen is turned off.
- Unticking "My account" in the toolbar no longer leaves an empty account menu on the left.
- Recorded toolbar items, dashboard widgets and list columns keep their first-seen label, so counters in plugin titles no longer rewrite the option on every request.
- Accent colours given as 3-digit hex now produce the right `--airy-accent-rgb`.
- ACF colour-picker columns only accept hex colours.
- A plugin returning nothing from the admin footer filters no longer causes a fatal error.
- The favicon field also checks the settings form's nonce.
- Uninstall also removes the per-user sidebar style and the Social sharing post meta.
- Plugin toolbar dropdown text was too light; clicking a submenu link darkened its group; the clicked Collapse button turned the colour scheme's blue.
- Folded-sidebar flyouts were clipped by the scrolling sidebar.
- A plugin's `#adminmenuwrap` margin pushed the light sidebar down.
- Uninstall now also removes the menu layout and recorded lists.

## [1.0.0] — 2026-10-01

### Added

- Complete rewrite for WordPress 7.1 and PHP 8.2+: database-backed settings page (Settings → AiryPress) replacing the config file.
- Admin theme as a plain-CSS layer over WordPress' own styles (no core stylesheet replaced), mobile drawer, accent colour.
- Admin menu builder (4 levels, custom links, labels, separators, icons, per-role hiding).
- GA4 dashboard widget and live visitors counter.
- Login screen branding and maintenance mode.
- Faster navigation: hover prefetch and view transitions.
- Admin clean-up, front-end clean-up, security and plugin toggles.
- Plugin-compatibility fixes for WooCommerce, Gravity Forms, Yoast SEO, SEOPress, MonsterInsights and more.

### Changed

- Build: Laravel Mix replaced with Vite; Node 25; Composer autoloader only (no roots/acorn).
