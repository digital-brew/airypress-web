<?php

/**
 * Plugin Name: AiryPress
 * Description: Admin theme and clean-up toggles for WordPress.
 * Version: 1.1.0
 * Requires at least: 6.8
 * Requires PHP: 8.2
 * Author: DigitalBrew
 * Author URI: https://digitalbrew.io
 * Text Domain: airypress
 * Domain Path: /languages
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
   */

declare(strict_types=1);

defined('ABSPATH') || exit;

// Free and Pro both active: Freemius keeps one (the Pro copy) and this copy
// stops here, before its constants and classes clash with the other's.
if (function_exists('airy_fs')) {
    airy_fs()->set_basename(true, __FILE__);

    return;
}

define('AIRYPRESS_VERSION', '1.1.0');
define('AIRYPRESS_FILE', __FILE__);
define('AIRYPRESS_DIR', plugin_dir_path(__FILE__));
define('AIRYPRESS_URL', plugin_dir_url(__FILE__));

require __DIR__ . '/vendor/autoload.php';

// Declared conditionally: an unconditional top-level function exists before
// the file runs, which would trip the check above.
if (! function_exists('airy_fs')) {
    /**
     * The Freemius instance (or its stand-in in agency mode).
     */
    function airy_fs(): object
    {
        return \DigitalBrew\AiryPress\Licensing\Licensing::fs();
    }
}

airy_fs();

add_action('plugins_loaded', [\DigitalBrew\AiryPress\Plugin::class, 'boot'], 5);
