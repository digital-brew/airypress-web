<?php
/**
 * Maintenance page, rendered by DigitalBrew\AiryPress\Modules\Maintenance.
 *
 * @var array{title: string, subtitle: string, body: string, background: string, text: string, image: string, font: string, site: string, lang: string, charset: string, icon: string} $view
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

// With an image, the background colour becomes a tint over it so the text stays readable.
// Printed raw inside <style>: the colours are sanitised hex values and
// esc_url_raw() strips quotes, so nothing can break out of url("…").
$airypressBackground = $view['image'] !== ''
    ? sprintf(
        'linear-gradient(color-mix(in srgb, %1$s 55%%, transparent), color-mix(in srgb, %1$s 55%%, transparent)), url("%2$s") center / cover no-repeat, %1$s',
        $view['background'],
        esc_url_raw($view['image'])
    )
    : $view['background'];
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php echo esc_attr($view['charset']); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo esc_html($view['title'] . ($view['site'] !== '' && $view['site'] !== $view['title'] ? ' – ' . $view['site'] : '')); ?></title>
    <?php if ($view['icon'] !== '') : ?>
        <link rel="icon" href="<?php echo esc_url($view['icon']); ?>">
    <?php endif; ?>
    <style>
        @font-face {
            font-family: "Inter Variable";
            font-style: normal;
            font-display: swap;
            font-weight: 100 900;
            src: url("<?php echo esc_url_raw($view['font']); ?>") format("woff2-variations");
        }

        *, *::before, *::after { box-sizing: border-box; }

        html, body { height: 100%; margin: 0; }

        body {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 48px 24px;
            background: <?php echo $airypressBackground; // phpcs:ignore WordPress.Security.EscapeOutput ?>;
            color: <?php echo esc_attr($view['text']); ?>;
            font-family: "Inter Variable", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            font-size: 17px;
            line-height: 1.6;
            text-align: center;
            -webkit-font-smoothing: antialiased;
        }

        main { width: 100%; max-width: 640px; }

        h1 {
            margin: 0;
            font-size: clamp(2rem, 6vw, 3.25rem);
            font-weight: 700;
            line-height: 1.1;
            letter-spacing: -0.02em;
            text-wrap: balance;
        }

        .subtitle {
            margin: 16px 0 0;
            font-size: clamp(1.05rem, 2.5vw, 1.3rem);
            opacity: 0.85;
            text-wrap: balance;
        }

        .body { margin-top: 32px; opacity: 0.8; }
        .body p { margin: 0 0 1em; }
        .body p:last-child { margin-bottom: 0; }
        .body a { color: inherit; }
    </style>
</head>
<body>
    <main>
        <h1><?php echo esc_html($view['title']); ?></h1>
        <?php if ($view['subtitle'] !== '') : ?>
            <p class="subtitle"><?php echo esc_html($view['subtitle']); ?></p>
        <?php endif; ?>
        <?php if ($view['body'] !== '') : ?>
            <div class="body"><?php echo wp_kses_post($view['body']); ?></div>
        <?php endif; ?>
    </main>
</body>
</html>
