/**
 * AiryPress — admin theme behaviour (vanilla ES module, defer-loaded).
 * - Inline submenu accordion (desktop >960px and mobile drawer).
 * - Mobile drawer close on backdrop click / Escape + scroll lock.
 * No jQuery, no DOM moves, no hardcoded paths.
 */

import '../styles/admin.css';

const config = window.airypress || {};
const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

/* -------------------------------------------------------------------------
 * Accordion
 * ---------------------------------------------------------------------- */

function accordionSupported() {
  return (
    document.body.classList.contains('airy-accordion') &&
    config.accordion !== false &&
    !document.body.classList.contains('folded') &&
    (window.matchMedia('(min-width: 961px)').matches ||
      window.matchMedia('(max-width: 782px)').matches)
  );
}

function submenuOf(li) {
  return li.querySelector(':scope > .wp-submenu');
}

function linkOf(li) {
  return li.querySelector(':scope > a.menu-top');
}

function openSubmenu(li, animate) {
  const submenu = submenuOf(li);
  if (!submenu) return;
  const link = linkOf(li);

  li.classList.add('submenu-opened');
  if (link) link.setAttribute('aria-expanded', 'true');

  if (!animate || prefersReducedMotion.matches) return;

  const target = submenu.scrollHeight;
  submenu.style.overflow = 'hidden';
  const animation = submenu.animate(
    [{ height: '0px' }, { height: `${target}px` }],
    { duration: 150, easing: 'ease' }
  );
  animation.onfinish = () => {
    submenu.style.height = '';
    submenu.style.overflow = '';
  };
}

function closeSubmenu(li, animate) {
  const submenu = submenuOf(li);
  const link = linkOf(li);
  if (link) link.setAttribute('aria-expanded', 'false');
  if (!submenu) {
    li.classList.remove('submenu-opened');
    return;
  }

  if (!animate || prefersReducedMotion.matches) {
    li.classList.remove('submenu-opened');
    return;
  }

  const start = submenu.scrollHeight;
  submenu.style.overflow = 'hidden';
  const animation = submenu.animate(
    [{ height: `${start}px` }, { height: '0px' }],
    { duration: 130, easing: 'ease' }
  );
  animation.onfinish = () => {
    li.classList.remove('submenu-opened');
    submenu.style.height = '';
    submenu.style.overflow = '';
  };
}

function toggleSubmenu(li) {
  if (li.classList.contains('submenu-opened')) {
    closeSubmenu(li, true);
    return;
  }

  document
    .querySelectorAll('#adminmenu > li.submenu-opened')
    .forEach((other) => {
      if (other !== li) closeSubmenu(other, true);
    });

  openSubmenu(li, true);
}

function initAccordion() {
  const currentItems = document.querySelectorAll(
    '#adminmenu > li.wp-has-current-submenu'
  );
  currentItems.forEach((li) => li.classList.add('submenu-opened'));

  document
    .querySelectorAll('#adminmenu > li.wp-has-submenu > a.menu-top')
    .forEach((link) => {
      const li = link.parentElement;
      if (!li) return;

      if (!link.hasAttribute('aria-expanded')) {
        link.setAttribute('aria-expanded', 'false');
      }
      // A plain click toggles the section instead of opening it.
      link.setAttribute('role', 'button');

      link.addEventListener('click', (event) => {
        // Let modified clicks navigate as usual.
        if (
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey ||
          event.button !== 0
        ) {
          return;
        }
        if (!accordionSupported()) return;
        event.preventDefault();
        toggleSubmenu(li);
      });

      link.addEventListener('keydown', (event) => {
        if (event.key !== ' ' && event.key !== 'Spacebar') return;
        if (!accordionSupported()) return;
        event.preventDefault();
        toggleSubmenu(li);
      });
    });

  // Visibility is now controlled solely by li.submenu-opened (see admin-menu.css).
  // Set after the current section is marked open so there is never a flash.
  if (document.body.classList.contains('airy-accordion')) {
    document.body.classList.add('airy-accordion-ready');
  }
}

/* -------------------------------------------------------------------------
 * Mobile drawer
 * ---------------------------------------------------------------------- */

function initDrawer() {
  const wrap = document.getElementById('wpwrap');
  if (!wrap) return;

  const menu = document.getElementById('adminmenuwrap');
  const toggle = document.querySelector('#wp-admin-bar-menu-toggle');
  const toggleItem = document.querySelector('#wp-admin-bar-menu-toggle .ab-item');

  const closeDrawer = () => {
    if (!wrap.classList.contains('wp-responsive-open')) return;
    wrap.classList.remove('wp-responsive-open');
  };

  // React to the class core toggles: control scroll lock + aria.
  const observer = new MutationObserver(() => {
    const open = wrap.classList.contains('wp-responsive-open');
    document.documentElement.style.overflow = open ? 'hidden' : '';
    if (toggleItem) toggleItem.setAttribute('aria-expanded', String(open));
  });
  observer.observe(wrap, { attributes: true, attributeFilter: ['class'] });

  document.addEventListener('click', (event) => {
    if (!wrap.classList.contains('wp-responsive-open')) return;
    if (menu && menu.contains(event.target)) return;
    if (toggle && toggle.contains(event.target)) return;
    closeDrawer();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' || event.key === 'Esc') closeDrawer();
  });
}

function init() {
  // First, so an error in a later step can't leave the bar stuck.
  initProgress();
  initSubGroups();
  initAccordion();
  initDrawer();
  initFooter();
  initSidebarSwitch();
  initAccountMenu();
  initToolbarSearch();
  initFlyouts();
  initFoldAnimation();
  initTableScroll();
  initRowActions();
  initQuickEditModal();
  initReportCharts();
  initToasts();
}

/* -------------------------------------------------------------------------
 * Collapse Menu: core toggles body.folded at once. For the moment around the
 * click, .airy-folding turns on the width/offset transitions (admin-menu.css),
 * so page loads and window resizes never animate. Runs in the capture phase,
 * before core's own click handler.
 * ---------------------------------------------------------------------- */
function initFoldAnimation() {
  const button = document.getElementById('collapse-button');
  if (!button) return;

  let timer = 0;

  button.addEventListener('click', () => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    document.body.classList.add('airy-folding');
    window.clearTimeout(timer);
    timer = window.setTimeout(() => document.body.classList.remove('airy-folding'), 320);
  }, true);
}

/* -------------------------------------------------------------------------
 * Toasts: one-off success messages ("Settings saved", "Post updated",
 * "Plugin activated") leave the page and appear as a card in the top-right
 * corner that fades after 5 seconds (8 with a link, e.g. "View post"; never
 * while hovered or focused). Errors, warnings, plugin notices AiryPress
 * manages (data-airy-notice), inline notices and anything inside a form or
 * box stay where they are. Runs on DOMContentLoaded, before jQuery's ready
 * handlers (common.js moves notices under the page title in one), so a
 * notice may be picked up before core moves it; toasted ones leave the page.
 * ---------------------------------------------------------------------- */
function initToasts() {
  if (!config.toasts) return;

  const run = () => {
    const content = document.getElementById('wpbody-content');
    if (!content) return;

    const notices = Array.from(
      content.querySelectorAll('.notice-success, div.updated, #message.notice-info'),
    ).filter(
      (notice) =>
        !notice.matches('.inline, .hidden, .update-nag, [data-airy-notice], .notice-error, .notice-warning, .error') &&
        !notice.closest('form, .postbox, .inline-edit-row, .airy-toasts, template, .woocommerce-layout__notice-list') &&
        notice.offsetParent !== null &&
        notice.textContent.trim() !== '',
    );

    if (!notices.length) return;

    let stack = document.querySelector('.airy-toasts');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'airy-toasts';
      stack.setAttribute('role', 'status');
      stack.setAttribute('aria-live', 'polite');
      document.body.append(stack);
    }

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    notices.forEach((notice) => {
      const toast = document.createElement('div');
      toast.className = `airy-toast ${notice.matches('.notice-info') ? 'is-info' : 'is-success'}`;

      const body = document.createElement('div');
      body.className = 'airy-toast__body';
      Array.from(notice.childNodes).forEach((node) => {
        if (node.nodeType === 1 && node.matches('.notice-dismiss, .airy-notice-snooze, .screen-reader-text')) return;
        body.append(node.cloneNode(true));
      });

      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'airy-toast__close';
      close.setAttribute('aria-label', (config.i18n && config.i18n.dismiss) || 'Dismiss');
      close.innerHTML = '<span aria-hidden="true">&times;</span>';

      toast.append(body, close);
      stack.append(toast);
      notice.remove();

      let timer = 0;
      let left = body.querySelector('a, button') ? 8000 : 5000;
      let started = 0;

      const hide = () => {
        window.clearTimeout(timer);
        if (reduced) {
          toast.remove();
          return;
        }
        toast.classList.add('is-leaving');
        toast.addEventListener('animationend', () => toast.remove(), { once: true });
        window.setTimeout(() => toast.remove(), 400);
      };
      // The progress bar along the bottom (CSS animation) runs and pauses
      // with the timer.
      toast.style.setProperty('--airy-toast-time', `${left}ms`);
      const start = () => {
        started = Date.now();
        toast.classList.remove('is-paused');
        timer = window.setTimeout(hide, left);
      };
      const pause = () => {
        window.clearTimeout(timer);
        toast.classList.add('is-paused');
        left = Math.max(0, left - (Date.now() - started));
      };

      close.addEventListener('click', hide);
      toast.addEventListener('mouseenter', pause);
      toast.addEventListener('mouseleave', start);
      toast.addEventListener('focusin', pause);
      toast.addEventListener('focusout', (event) => {
        if (!toast.contains(event.relatedTarget)) start();
      });
      start();
    });
  };

  if (document.readyState === 'complete') {
    run();
  } else {
    document.addEventListener('DOMContentLoaded', run, { once: true });
  }
}

/* -------------------------------------------------------------------------
 * WooCommerce Reports (legacy flot charts): WooCommerce hard-codes the
 * series colours, point sizes and axis styles in inline scripts with no
 * filter, so jQuery.plot is wrapped on that screen to restyle the options:
 * the theme's palette (accent for net sales, greys for bars), thinner lines,
 * small points, and the theme's font and grid colours. The legend's colour
 * bars get the same palette. Runs before the inline scripts' ready handlers.
 * ---------------------------------------------------------------------- */
function initReportCharts() {
  const $ = window.jQuery;
  if (!$ || typeof $.plot !== 'function' || !document.body.classList.contains('woocommerce_page_wc-reports')) return;

  const styles = getComputedStyle(document.body);
  const token = (name, fallback) => styles.getPropertyValue(name).trim() || fallback;
  const accent = token('--airy-accent', '#0fc0c0');
  const accentDark = token('--airy-accent-dark', '#0da9a9');
  const muted = token('--airy-text-muted', '#646970');
  const grid = token('--airy-gray-2', '#e2e2e3');
  const font = token('--airy-font', 'sans-serif');

  // WooCommerce's colours → the theme's.
  const palette = {
    '#b1d4ea': `color-mix(in srgb, ${accent} 35%, #fff)`,
    '#3498db': accent,
    '#dbe1e3': '#d9dadc',
    '#ecf0f1': '#ececee',
    '#5cc488': '#22c55e',
    '#f1c40f': '#f59e0b',
    '#e74c3c': '#ef4444',
    '#9c5d90': accentDark,
  };
  const probe = document.createElement('span');
  document.body.append(probe);
  const resolve = (value) => {
    if (typeof value !== 'string') return value;
    const mapped = palette[value.toLowerCase()];
    if (!mapped) return value;
    probe.style.color = mapped;
    return getComputedStyle(probe).color;
  };

  document.querySelectorAll('.chart-legend li[style*="border-color"]').forEach((li) => {
    li.style.borderColor = resolve(li.style.borderColor.startsWith('rgb') ? li.getAttribute('style').match(/#[0-9a-f]{6}/i)?.[0] : li.style.borderColor);
  });

  const plot = $.plot;
  $.plot = function (placeholder, series, options) {
    (series || []).forEach((s) => {
      s.color = resolve(s.color);
      if (s.bars) s.bars.fillColor = resolve(s.bars.fillColor);
      if (s.lines && s.lines.lineWidth > 2) s.lines.lineWidth = 3;
      if (s.points && s.points.show) {
        s.points.radius = 3;
        s.points.lineWidth = 2;
      }
    });

    const opts = options || {};
    const axisFont = { color: muted, size: 11, family: font };
    opts.grid = { ...opts.grid, color: grid, borderWidth: 0 };
    (opts.xaxes || []).forEach((axis) => Object.assign(axis, { color: grid, font: axisFont }));
    (opts.yaxes || []).forEach((axis, i) => Object.assign(axis, { color: i === 0 ? grid : 'transparent', font: axisFont }));

    return plot.call(this, placeholder, series, opts);
  };
  Object.assign($.plot, plot);
}

/* -------------------------------------------------------------------------
 * Quick Edit opens as a modal instead of replacing the row. Core still
 * inserts its editor row into the table (and saves, cancels and swaps the
 * row back itself); CSS lifts that row out as a fixed overlay
 * (list-tables.css) and the original row stays visible behind it. Clicking
 * the backdrop or the × cancels through core's own Cancel button, and focus
 * returns to the row's ⋮ menu. Bulk Edit keeps core's in-table panel.
 * ---------------------------------------------------------------------- */
function initQuickEditModal() {
  const lists = document.querySelectorAll('table.wp-list-table > tbody');
  if (!lists.length) return;

  const closeLabel = config.i18n?.close || 'Close';
  let current = null;

  const cancel = (row) => row.querySelector('button.cancel, .cancel')?.click();

  const open = (row) => {
    row.dataset.airyQe = '1';
    row.classList.add('airy-qe-modal');
    row.setAttribute('role', 'dialog');
    row.setAttribute('aria-modal', 'true');

    // Keep the row being edited in the list (core hides it).
    const id = row.id.replace(/^edit-/, '');
    const original = row.parentElement.querySelector(`#post-${CSS.escape(id)}, #tag-${CSS.escape(id)}`);
    if (original) original.style.display = '';

    const panel = row.querySelector(':scope > td');
    if (panel && !panel.querySelector('.airy-qe-close')) {
      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'airy-qe-close';
      close.setAttribute('aria-label', closeLabel);
      close.innerHTML = '<svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5 5l10 10M15 5L5 15" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
      close.addEventListener('click', () => cancel(row));
      panel.prepend(close);
    }

    // Customizable selects (CSS) only fit the current option: keep the
    // native width, which fits the widest.
    row.querySelectorAll('select').forEach((select) => {
      // offsetWidth: the opening animation scales the panel.
      if (select.offsetWidth) select.style.minWidth = `${select.offsetWidth}px`;
    });
    row.classList.add('airy-qe-sized');

    const backdrop = document.createElement('div');
    backdrop.className = 'airy-qe-backdrop';
    backdrop.addEventListener('mousedown', () => cancel(row));
    document.body.append(backdrop);

    document.documentElement.classList.add('airy-qe-open');
    current = { row, original, backdrop };
  };

  const closed = () => {
    if (!current || current.row.isConnected) return;
    document.documentElement.classList.remove('airy-qe-open');
    current.backdrop.remove();
    // Core focuses its (moved) Quick Edit link; the ⋮ button is the visible one.
    const id = current.row.id.replace(/^edit-/, '');
    const row = document.querySelector(`#post-${CSS.escape(id)}, #tag-${CSS.escape(id)}`);
    row?.querySelector('.airy-ra-toggle')?.focus({ preventScroll: true });
    current = null;
  };

  const check = () => {
    document
      .querySelectorAll('table.wp-list-table > tbody > tr.inline-edit-row.inline-editor:not(#bulk-edit):not([data-airy-qe])')
      .forEach(open);
    closed();
  };

  lists.forEach((tbody) => new MutationObserver(check).observe(tbody, { childList: true, subtree: false, attributes: true, attributeFilter: ['class'] }));
}

/* -------------------------------------------------------------------------
 * List-table row actions as a "⋮" menu in a column of its own at the end
 * of each row (like Filament). Every action (Edit, Quick Edit, Trash, View,
 * ones plugins add…) moves into the menu; the title still links to the
 * editor. The original links are moved, not copied, so core's handlers
 * (Quick Edit, delete confirmations) and plugins' keep working: they find
 * the row with closest('tr'), and the menu stays inside the row. The menu
 * is position: fixed, so the scrolling content card can't clip it. Rows
 * core re-renders (after Quick Edit, or added by AJAX) are picked up again.
 * The Plugins table keeps its own links.
 * ---------------------------------------------------------------------- */
/* -------------------------------------------------------------------------
 * Wide list tables scroll sideways inside their own box instead of squeezing
 * every column (list-tables.css lays them out by content on desktop).
 * ---------------------------------------------------------------------- */
function initTableScroll() {
  document.querySelectorAll('table.wp-list-table').forEach((table) => {
    if (table.parentElement.classList.contains('airy-table-scroll')) return;
    const box = document.createElement('div');
    box.className = 'airy-table-scroll';
    table.before(box);
    box.append(table);
    sizeColumns(table);
  });
}

// Short values stay on one line; columns of long text (excerpts, meta
// descriptions) get a readable width instead of a word per line.
function sizeColumns(table) {
  const heads = [...(table.querySelector('thead tr')?.children || [])];
  const rows = [...table.querySelectorAll(':scope > tbody > tr')].slice(0, 50);

  heads.forEach((th, index) => {
    if (th.matches('.check-column, .column-primary')) return;
    let longest = 0;
    rows.forEach((tr) => {
      const cell = tr.children[index];
      if (cell && cell.colSpan === 1) longest = Math.max(longest, cell.textContent.trim().length);
    });
    if (longest > 40) th.classList.add('airy-col-long');
    else if (longest > 0) th.classList.add('airy-col-short');
    if (longest > 0 && longest <= 40) {
      rows.forEach((tr) => tr.children[index]?.classList.add('airy-col-short'));
    }
  });
}

function initRowActions() {
  const tables = [...document.querySelectorAll('table.wp-list-table:not(.plugins)')].filter((table) =>
    table.querySelector('tbody .row-actions')
  );

  if (!tables.length) return;

  const label = config.i18n?.moreActions || 'Actions';
  let open = null;

  const close = (focusButton = false) => {
    if (!open) return;
    open.menu.hidden = true;
    open.button.setAttribute('aria-expanded', 'false');
    if (focusButton) open.button.focus();
    open = null;
  };

  // Right-aligned under the button, or above it near the bottom of the window.
  const place = (button, menu) => {
    menu.hidden = false;
    const rect = button.getBoundingClientRect();
    const left = Math.max(8, rect.right - menu.offsetWidth);
    const below = rect.bottom + 4;
    const top = below + menu.offsetHeight < window.innerHeight - 8 ? below : rect.top - 4 - menu.offsetHeight;
    menu.style.setProperty('--airy-ra-left', `${Math.round(left)}px`);
    menu.style.setProperty('--airy-ra-top', `${Math.round(Math.max(8, top))}px`);
  };

  const headerCell = (table, section) => {
    const row = table.querySelector(`${section} tr`);
    if (!row || row.querySelector('.airy-ra-col')) return;
    const th = document.createElement(section === 'thead' ? 'th' : 'th');
    th.scope = 'col';
    th.className = 'manage-column airy-ra-col';
    th.innerHTML = `<span class="screen-reader-text">${label}</span>`;
    row.append(th);
  };

  const buildRow = (tr) => {
    if (tr.dataset.airyRa) return;
    tr.dataset.airyRa = '1';

    // Full-width rows (no items, inline edit, plugin notices) span the new column too.
    const cells = [...tr.children].filter((el) => el.tagName === 'TD' || el.tagName === 'TH');
    if (cells.length === 1 && cells[0].colSpan > 1) {
      cells[0].colSpan += 1;
      return;
    }

    const td = document.createElement('td');
    td.className = 'airy-ra-cell';
    tr.append(td);

    const actions = tr.querySelector('.row-actions');
    const all = actions ? [...actions.children].filter((el) => el.tagName === 'SPAN') : [];
    // Info without a link (WooCommerce's "ID: 25") stays under the title.
    const spans = all.filter((el) => el.querySelector('a, button'));
    if (!spans.length) return;

    // Drop core's " | " separators.
    all.forEach((span) => {
      [...span.childNodes].forEach((node) => {
        if (node.nodeType === Node.TEXT_NODE && /^\s*\|\s*$/.test(node.textContent)) node.remove();
      });
    });

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'airy-ra-toggle';
    button.setAttribute('aria-haspopup', 'menu');
    button.setAttribute('aria-expanded', 'false');
    button.setAttribute('aria-label', label);
    button.title = label;
    button.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/></svg>';

    const menu = document.createElement('div');
    menu.className = 'airy-ra-menu';
    menu.setAttribute('role', 'menu');
    menu.hidden = true;

    spans.forEach((span) => {
      span.classList.add('airy-ra-item');
      span.querySelectorAll('a, button').forEach((el) => el.setAttribute('role', 'menuitem'));
      menu.append(span);
    });

    if (all.length === spans.length) actions.classList.add('airy-ra-moved');
    td.append(button, menu);

    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const wasOpen = open?.button === button;
      close();
      if (wasOpen) return;
      place(button, menu);
      button.setAttribute('aria-expanded', 'true');
      open = { button, menu };
      menu.querySelector('[role="menuitem"]')?.focus({ preventScroll: true });
    });

    // A chosen action closes the menu (its own handler still runs).
    menu.addEventListener('click', () => window.setTimeout(close, 0));

    menu.addEventListener('keydown', (event) => {
      const items = [...menu.querySelectorAll('[role="menuitem"]')].filter((el) => el.offsetParent);
      const index = items.indexOf(document.activeElement);

      if (event.key === 'Escape') {
        event.preventDefault();
        close(true);
      } else if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        const step = event.key === 'ArrowDown' ? 1 : -1;
        items[(index + step + items.length) % items.length]?.focus();
      } else if (event.key === 'Tab') {
        close();
      }
    });
  };

  tables.forEach((table) => {
    table.classList.add('airy-has-ra');
    headerCell(table, 'thead');
    headerCell(table, 'tfoot');

    table.querySelectorAll(':scope > tbody').forEach((tbody) => {
      const scan = () => tbody.querySelectorAll(':scope > tr').forEach(buildRow);
      scan();
      // Quick Edit, inline saves and AJAX-added rows replace or add rows.
      new MutationObserver(scan).observe(tbody, { childList: true });
    });
  });

  document.addEventListener('click', (event) => {
    if (open && !open.menu.contains(event.target)) close();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') close(true);
  });
  // The menu is fixed: follow the button when the page or card scrolls,
  // and close once the button is out of sight.
  const follow = () => {
    if (!open) return;
    const rect = open.button.getBoundingClientRect();
    if (rect.bottom < 0 || rect.top > window.innerHeight) {
      close();
      return;
    }
    place(open.button, open.menu);
  };
  document.addEventListener('scroll', follow, true);
  window.addEventListener('resize', () => close());
}

/* -------------------------------------------------------------------------
 * Deeper menu levels (menu builder). WordPress only renders two levels, so
 * the builder flattens levels 3–4 into the submenu right after their parent:
 * a parent carries `airy-sub-parent airy-sub-key-<key>`, each child
 * `airy-sub-child airy-sub-child-of-<key> airy-sub-level-<n>`. Rebuild the tree
 * here as collapsible groups, opened along the path to the current page.
 * ---------------------------------------------------------------------- */

function initSubGroups() {
  const groups = new Map();
  const keyOf = (li) => (Array.from(li.classList).find((c) => c.startsWith('airy-sub-key-')) || '')
    .slice('airy-sub-key-'.length);

  document.querySelectorAll('#adminmenu li.airy-sub-parent').forEach((parent) => {
    const key = keyOf(parent);
    if (!key) return;

    const children = Array.from(
      parent.parentElement.querySelectorAll(`:scope > li.airy-sub-child-of-${key}`)
    );
    if (children.length) groups.set(parent, children);
  });

  const containsCurrent = (li) => li.classList.contains('current')
    || (groups.get(li) || []).some(containsCurrent);

  const setOpen = (parent, open) => {
    parent.classList.toggle('airy-sub-open', open);
    parent.querySelector(':scope > .airy-sub-toggle')?.setAttribute('aria-expanded', String(open));
    if (parent.classList.contains('airy-sub-label')) {
      parent.querySelector(':scope > a')?.setAttribute('aria-expanded', String(open));
    }

    groups.get(parent).forEach((child) => {
      child.hidden = !open;
      // Closing a group also closes everything nested inside it.
      if (!open && groups.has(child)) setOpen(child, false);
    });
  };

  // Sub-labels (headings inside a submenu) are not pages: their link toggles
  // the group below them instead of navigating.
  document.querySelectorAll('#adminmenu li.airy-sub-label > a').forEach((link) => {
    link.setAttribute('role', 'button');
    link.addEventListener('click', (event) => {
      event.preventDefault();
      const parent = link.parentElement;
      if (groups.has(parent)) setOpen(parent, !parent.classList.contains('airy-sub-open'));
    });
  });

  groups.forEach((children, parent) => {
    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'airy-sub-toggle';
    toggle.setAttribute('aria-label', parent.textContent.trim());
    toggle.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      setOpen(parent, !parent.classList.contains('airy-sub-open'));
    });
    parent.append(toggle);
  });

  // Map iteration follows DOM order, so outer groups are set before inner ones.
  groups.forEach((children, parent) => {
    setOpen(parent, containsCurrent(parent));
  });
}

/* -------------------------------------------------------------------------
 * Footer placement (the only DOM move)
 * On desktop the fixed card scrolls, so #wpfooter must live inside
 * #wpcontent (as the last child) to sit at the bottom of the card. On
 * mobile the normal page scroll is kept, so it returns to #wpwrap.
 * ---------------------------------------------------------------------- */

const FOOTER_MOVED_CLASS = 'airy-footer-moved';

function placeFooter() {
  if (!document.body.classList.contains('airy-theme')) return;

  const footer = document.getElementById('wpfooter');
  const content = document.getElementById('wpcontent');
  const wrap = document.getElementById('wpwrap');
  if (!footer || !content || !wrap) return;

  if (window.matchMedia('(min-width: 783px)').matches) {
    if (footer.parentElement !== content) content.append(footer);
    document.body.classList.add(FOOTER_MOVED_CLASS);
  } else {
    if (footer.parentElement === content && wrap) wrap.append(footer);
    document.body.classList.remove(FOOTER_MOVED_CLASS);
  }
}

function initFooter() {
  placeFooter();

  const media = window.matchMedia('(min-width: 783px)');
  const onChange = () => placeFooter();
  if (typeof media.addEventListener === 'function') {
    media.addEventListener('change', onChange);
  } else if (typeof media.addListener === 'function') {
    media.addListener(onChange);
  }
}

/* -------------------------------------------------------------------------
 * Progress bar
 * The inline script in admin_head adds `airy-loading` to <html> so the accent
 * bar animates from scaleX(0) while the document loads. Here we finish that
 * (on `load`) and switch the bar to indeterminate mode for same-origin
 * navigation, clearing it on `pageshow` so a bfcache restore never sticks.
 * Visibility and animation live entirely in the CSS.
 * ---------------------------------------------------------------------- */

const ROOT = document.documentElement;
const LOADING_CLASS = 'airy-loading';
const NAVIGATING_CLASS = 'airy-navigating';
const LOAD_DONE_CLASS = 'airy-load-done';

function endLoad() {
  if (!ROOT.classList.contains(LOADING_CLASS)) return;

  ROOT.classList.remove(LOADING_CLASS);
  ROOT.classList.add(LOAD_DONE_CLASS);

  const clear = () => {
    ROOT.classList.remove(LOAD_DONE_CLASS);
    ROOT.removeEventListener('animationend', clear);
  };
  ROOT.addEventListener('animationend', clear);
  window.setTimeout(clear, 700);
}

function startNavigating() {
  ROOT.classList.remove(LOAD_DONE_CLASS);
  ROOT.classList.add(NAVIGATING_CLASS);
}

function stopNavigating() {
  ROOT.classList.remove(NAVIGATING_CLASS);
}

function isProgressEligible() {
  return (
    config.loadingBar !== false &&
    !document.body.classList.contains('block-editor-page') &&
    window.matchMedia('(min-width: 783px)').matches
  );
}

function initProgress() {
  if (!isProgressEligible()) {
    endLoad();
    return;
  }

  if (document.readyState === 'complete') {
    endLoad();
  } else {
    window.addEventListener('load', endLoad, { once: true });
    // `load` waits for every image and iframe; one that never finishes
    // (a slow third-party embed) would hold the bar at 80%.
    window.setTimeout(endLoad, 5000);
  }

  document.addEventListener('click', (event) => {
    window.setTimeout(() => {
      if (!isProgressEligible()) return;
      if (event.defaultPrevented) return;
      if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

      const link = event.target.closest && event.target.closest('a[href]');
      if (!link) return;
      if (link.target && link.target !== '_self') return;
      if (link.hasAttribute('download')) return;
      if (link.classList.contains('thickbox')) return;
      if (event.target.closest && event.target.closest('[data-airy-no-progress]')) return;

      const href = link.getAttribute('href') || '';
      if (!href || href.startsWith('#') || /^javascript:/i.test(href)) return;

      let url;
      try {
        url = new URL(href, window.location.href);
      } catch (error) {
        return;
      }
      if (url.origin !== window.location.origin) return;

      startNavigating();
    }, 0);
  });

  document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!form || form.target === '_blank') return;
    // Wait for every handler, like clicks: core cancels some submits
    // (Plugins → Add New search, the Menus search) and runs them in place.
    window.setTimeout(() => {
      if (event.defaultPrevented) return;
      startNavigating();
    }, 0);
  });

  window.addEventListener('pageshow', stopNavigating);
  window.addEventListener('beforeunload', stopNavigating);
}

/* -------------------------------------------------------------------------
 * Flyout submenus (desktop): every section while the sidebar is folded, and
 * the non-current sections when accordion submenus are off. They open on
 * hover (li.airy-fly-open, with hover intent below) or keyboard focus as cards
 * beside the item. #adminmenuwrap
 * scrolls (overflow), which clips absolutely positioned flyouts, so they
 * are position:fixed and placed here.
 * ---------------------------------------------------------------------- */

function initFlyouts() {
  const menu = document.getElementById('adminmenu');
  const wrap = document.getElementById('adminmenuwrap');
  if (!menu || !wrap) return;

  const items = Array.from(menu.querySelectorAll(':scope > li.wp-has-submenu'));
  const desktop = window.matchMedia('(min-width: 783px)');
  const autoFolded = window.matchMedia('(min-width: 783px) and (max-width: 960px)');

  const update = () => {
    const body = document.body;
    const folded = body.classList.contains('folded') || (autoFolded.matches && body.classList.contains('auto-fold'));
    const accordion = body.classList.contains('airy-accordion');

    items.forEach((li) => {
      const fly = desktop.matches && (folded || (!accordion && !li.classList.contains('wp-has-current-submenu')));
      li.classList.toggle('airy-fly', fly);
      if (!fly) li.classList.remove('airy-fly-open');
    });
  };

  const place = (li) => {
    if (!li.classList.contains('airy-fly')) return;
    const sub = li.querySelector(':scope > .wp-submenu');
    if (!sub) return;

    // Right next to the item's own row, not the sidebar edge.
    const row = li.querySelector(':scope > a.menu-top') || li;
    const top = li.getBoundingClientRect().top;
    li.style.setProperty('--airy-fly-left', `${row.getBoundingClientRect().right}px`);
    li.style.setProperty('--airy-fly-top', `${top}px`);

    // Keep the card on screen once it has a height.
    window.requestAnimationFrame(() => {
      const max = window.innerHeight - sub.offsetHeight - 8;
      if (top > max) li.style.setProperty('--airy-fly-top', `${Math.max(8, max)}px`);
    });
  };

  // Hover intent: a card closes 300ms after the pointer leaves its item.
  // While one is open, another item takes over after 60ms, or 300ms while
  // the pointer is heading right towards the open card ("menu aim"), so a
  // diagonal move across neighbouring items doesn't swap the card.
  const CLOSE_DELAY = 300;
  const SWITCH_DELAY = 60;
  const AIM_DELAY = 300;
  let openItem = null;
  let closeTimer = 0;
  let openTimer = 0;
  let lastX = 0;
  let movingRight = false;

  menu.addEventListener('mousemove', (event) => {
    if (event.clientX !== lastX) movingRight = event.clientX > lastX;
    lastX = event.clientX;
  });

  const open = (li) => {
    window.clearTimeout(openTimer);
    window.clearTimeout(closeTimer);
    if (openItem && openItem !== li) openItem.classList.remove('airy-fly-open');
    openItem = li;
    place(li);
    li.classList.add('airy-fly-open');
  };

  const close = () => {
    window.clearTimeout(openTimer);
    if (openItem) openItem.classList.remove('airy-fly-open');
    openItem = null;
  };

  items.forEach((li) => {
    li.addEventListener('mouseenter', () => {
      if (!li.classList.contains('airy-fly')) return;
      if (li === openItem) {
        window.clearTimeout(closeTimer);
        window.clearTimeout(openTimer);
        return;
      }
      window.clearTimeout(openTimer);
      if (openItem) {
        openTimer = window.setTimeout(() => open(li), movingRight ? AIM_DELAY : SWITCH_DELAY);
      } else {
        open(li);
      }
    });

    li.addEventListener('mouseleave', () => {
      if (li !== openItem) {
        window.clearTimeout(openTimer);
        return;
      }
      window.clearTimeout(closeTimer);
      closeTimer = window.setTimeout(close, CLOSE_DELAY);
    });

    li.addEventListener('focusin', () => place(li));
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') close();
  });

  update();
  desktop.addEventListener('change', update);
  autoFolded.addEventListener('change', update);
  // Collapse Menu toggles body.folded.
  new MutationObserver(update).observe(document.body, { attributes: true, attributeFilter: ['class'] });
}

/* -------------------------------------------------------------------------
 * Toolbar search (account menu in the sidebar): the field is centred on the
 * toolbar, out of the flow. When toolbar items reach under it (plugins can add
 * many), .airy-search-crowded puts it back in line beside them
 * (admin-bar.css). Checked again whenever the bar or an item changes size.
 * ---------------------------------------------------------------------- */
function initToolbarSearch() {
  const bar = document.getElementById('wpadminbar');
  const search = document.getElementById('wp-admin-bar-command-palette');
  if (!bar || !search || !document.body.classList.contains('airy-account-sidebar')) return;

  const items = () =>
    Array.from(bar.querySelectorAll('#wp-admin-bar-root-default > li, #wp-admin-bar-top-secondary > li')).filter(
      (li) => li !== search && li.offsetWidth && getComputedStyle(li).position !== 'fixed',
    );

  const check = () => {
    // Measure the centred field, then whether anything sits beneath it.
    bar.classList.remove('airy-search-crowded');
    const field = search.getBoundingClientRect();
    if (!field.width || getComputedStyle(search).position !== 'absolute') return;

    const crowded = items().some((li) => {
      const box = li.getBoundingClientRect();
      return box.right > field.left - 8 && box.left < field.right + 8;
    });
    bar.classList.toggle('airy-search-crowded', crowded);
  };

  const observer = new ResizeObserver(check);
  observer.observe(bar);
  items().forEach((li) => observer.observe(li));
  if (document.fonts) document.fonts.ready.then(check);
}

/* -------------------------------------------------------------------------
 * Account menu opens on click (Enter/Space from the keyboard) instead of
 * hover. `airy-click-menu` tells the CSS to ignore core's :hover/.hover, so
 * without this script the menu still opens on hover.
 * ---------------------------------------------------------------------- */

function initAccountMenu() {
  const item = document.getElementById('wp-admin-bar-my-account');
  const trigger = item && item.querySelector(':scope > .ab-item');
  if (!item || !trigger) return;

  item.classList.add('airy-click-menu');
  trigger.setAttribute('aria-haspopup', 'true');
  trigger.setAttribute('aria-expanded', 'false');

  const setOpen = (open) => {
    item.classList.toggle('airy-open', open);
    trigger.setAttribute('aria-expanded', String(open));
  };

  trigger.addEventListener('click', (event) => {
    event.preventDefault();
    setOpen(!item.classList.contains('airy-open'));
  });

  trigger.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    event.preventDefault();
    event.stopPropagation();
    setOpen(!item.classList.contains('airy-open'));
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || !item.classList.contains('airy-open')) return;
    setOpen(false);
    trigger.focus();
  });

  document.addEventListener('click', (event) => {
    if (!item.contains(event.target)) setOpen(false);
  });

  item.addEventListener('focusout', (event) => {
    if (event.relatedTarget && !item.contains(event.relatedTarget)) setOpen(false);
  });
}

/* -------------------------------------------------------------------------
 * Account menu: Default / Modern / Light theme switch. Swaps the body class at once
 * and saves the choice to the user's profile in the background; the links
 * still work without JS (admin-post.php + redirect).
 * ---------------------------------------------------------------------- */

function initSidebarSwitch() {
  const options = Array.from(document.querySelectorAll('[data-airy-sidebar]'));
  if (!options.length || typeof window.ajaxurl !== 'string') return;

  options.forEach((option) => {
    option.addEventListener('click', (event) => {
      event.preventDefault();
      const style = option.dataset.airySidebar;

      document.body.classList.toggle('airy-sidebar-light', style === 'light');
      document.body.classList.toggle('airy-theme-modern', style === 'modern');
      options.forEach((other) => {
        const on = other === option;
        other.classList.toggle('is-active', on);
        other.setAttribute('aria-pressed', String(on));
      });

      const body = new URLSearchParams({
        action: 'airypress_sidebar',
        style,
        _wpnonce: option.dataset.nonce || '',
      });

      fetch(window.ajaxurl, { method: 'POST', credentials: 'same-origin', body }).catch(() => {});
    });
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
