/**
 * AiryPress — settings page behaviour (vanilla ES module).
 * Tabs, colour fields, dependency toggles, export copy button.
 */

import Sortable from 'sortablejs';
import '../styles/settings.css';

const TAB_KEY = 'airypress-tab';

/* -------------------------------------------------------------------------
 * Tabs
 * ---------------------------------------------------------------------- */

function initTabs() {
  const tabs = Array.from(document.querySelectorAll('.airy-tab'));
  const panels = Array.from(document.querySelectorAll('.airy-panel'));
  const page = document.querySelector('.airy-settings-page');
  if (!tabs.length) return;

  // Never let the browser restore/jump to a panel id on load.
  if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
  }

  const activate = (id, options = {}) => {
    const { focus = false, updateHash = true } = options;
    if (!tabs.some((tab) => tab.dataset.tab === id)) return;

    tabs.forEach((tab) => {
      const on = tab.dataset.tab === id;
      tab.classList.toggle('is-active', on);
      tab.setAttribute('aria-selected', String(on));
      tab.tabIndex = on ? 0 : -1;
      if (on && focus) tab.focus({ preventScroll: true });
    });

    // Mobile pill strip scrolls sideways: bring the active tab into view
    // without scrolling the page itself.
    const strip = tabs[0].parentElement;
    const current = tabs.find((tab) => tab.dataset.tab === id);
    if (strip && current && strip.scrollWidth > strip.clientWidth) {
      strip.scrollLeft = current.offsetLeft - strip.offsetLeft - 16;
    }

    // Panels may live inside or outside the main options.php form (Tools),
    // so toggle them by data-tab regardless of their parent.
    panels.forEach((panel) => {
      panel.classList.toggle('is-active', panel.dataset.tab === id);
    });

    // The sticky "Save changes" bar belongs to the settings form only.
    // CSS hides the footer via .is-tools (the hidden attribute would lose
    // to .airy-settings-footer's own display: flex).
    // Panels outside the settings form (Tools, Menu builder) carry data-standalone.
    const activePanel = panels.find((panel) => panel.dataset.tab === id);
    if (page) page.classList.toggle('is-tools', Boolean(activePanel && activePanel.hasAttribute('data-standalone')));

    if (updateHash) {
      // Panels are id="airy-panel-<id>", so "#<id>" never matches an element
      // and therefore never scrolls the page.
      history.replaceState(null, '', `#${id}`);
    }

    try {
      sessionStorage.setItem(TAB_KEY, id);
    } catch (error) {
      /* storage unavailable */
    }
  };

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', (event) => {
      event.preventDefault();
      activate(tab.dataset.tab, { updateHash: true });
    });

    tab.addEventListener('keydown', (event) => {
      let next = null;
      if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
        next = (index + 1) % tabs.length;
      } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
        next = (index - 1 + tabs.length) % tabs.length;
      } else if (event.key === 'Home') {
        next = 0;
      } else if (event.key === 'End') {
        next = tabs.length - 1;
      }
      if (next === null) return;
      event.preventDefault();
      activate(tabs[next].dataset.tab, { focus: true, updateHash: true });
    });
  });

  // Initial tab: URL hash, then last session tab, then the first tab.
  let initial = location.hash.replace(/^#/, '');

  if (!tabs.some((tab) => tab.dataset.tab === initial)) {
    initial = '';
  }

  if (!initial) {
    try {
      initial = sessionStorage.getItem(TAB_KEY) || '';
    } catch (error) {
      initial = '';
    }
  }

  if (!tabs.some((tab) => tab.dataset.tab === initial)) {
    initial = tabs[0].dataset.tab;
  }

  activate(initial, { updateHash: true });

  // Preserve the active tab across the options.php redirect after saving.
  document.querySelectorAll('form.airy-settings-form').forEach((form) => {
    form.addEventListener('submit', () => {
      const referer = form.querySelector('input[name="_wp_http_referer"]');
      if (referer) {
        referer.value = referer.value.replace(/#.*$/, '') + location.hash;
      }
    });
  });
}

/* -------------------------------------------------------------------------
 * Colour fields
 * ---------------------------------------------------------------------- */

function initColorFields() {
  document.querySelectorAll('.airy-field--color').forEach((field) => {
    const color = field.querySelector('input.airy-color');
    const text = field.querySelector('.airy-color-text');
    if (!color || !text) return;

    // Only the admin accent previews live; other colours (login, maintenance)
    // belong to other screens.
    const preview = (value) => {
      if (color.id !== 'airy-admin-theme-accent') return;
      document.body.style.setProperty('--airy-accent', value);
    };

    color.addEventListener('input', () => {
      text.value = color.value;
      preview(color.value);
    });

    text.addEventListener('input', () => {
      if (!/^#[0-9a-f]{6}$/i.test(text.value)) return;
      color.value = text.value;
      preview(text.value);
    });
  });
}

/* -------------------------------------------------------------------------
 * Image fields (media library picker; stores the attachment ID)
 * ---------------------------------------------------------------------- */

function initImageFields() {
  document.querySelectorAll('.airy-image').forEach((field) => {
    const input = field.querySelector('input[type="hidden"]');
    const preview = field.querySelector('.airy-image-preview');
    const choose = field.querySelector('[data-airy-image-choose]');
    const remove = field.querySelector('[data-airy-image-remove]');
    if (!input || !preview || !choose || !remove) return;

    let frame = null;

    const set = (id, url) => {
      input.value = id ? String(id) : '';
      preview.replaceChildren();
      if (url) {
        const img = document.createElement('img');
        img.src = url;
        img.alt = '';
        preview.append(img);
      }
      preview.hidden = !url;
      remove.hidden = !id;
    };

    choose.addEventListener('click', () => {
      const media = window.wp && window.wp.media;
      if (!media) return;

      if (!frame) {
        frame = media({
          title: choose.dataset.title,
          button: { text: choose.dataset.button },
          library: { type: 'image' },
          multiple: false,
        });

        frame.on('select', () => {
          const attachment = frame.state().get('selection').first().toJSON();
          const sizes = attachment.sizes || {};
          const size = sizes.medium || sizes.full || attachment;
          set(attachment.id, size.url);
        });
      }

      frame.open();
    });

    remove.addEventListener('click', () => set('', ''));
  });
}

/* -------------------------------------------------------------------------
 * Post type columns: drag to reorder (the hidden order[] inputs move with
 * their rows, so the form posts the new order), tick to show.
 * ---------------------------------------------------------------------- */

function initColumnLists() {
  document.querySelectorAll('[data-airy-columns]').forEach((list) => {
    Sortable.create(list, {
      handle: '.airy-columns-handle',
      animation: 150,
      ghostClass: 'is-ghost',
    });

    list.addEventListener('change', (event) => {
      const box = event.target;
      if (!(box instanceof HTMLInputElement) || !box.name.endsWith('[on][]')) return;
      const row = box.closest('.airy-columns-row');
      if (row) row.classList.toggle('is-off', !box.checked);
    });
  });
}

/* -------------------------------------------------------------------------
 * Plugin checklists (toolbar items, dashboard widgets): while every item is
 * kept, a hidden '*' is posted with them. Unticking a box drops it, so the
 * ticked items become the list.
 * ---------------------------------------------------------------------- */

function initKeepAllLists() {
  document.querySelectorAll('input[data-airy-keep-all]').forEach((marker) => {
    const list = marker.closest('fieldset');
    if (!list) return;

    const drop = (event) => {
      const box = event.target;
      if (!(box instanceof HTMLInputElement) || box.type !== 'checkbox' || box.checked) return;
      marker.remove();
      list.removeEventListener('change', drop);
    };

    list.addEventListener('change', drop);
  });
}

/* -------------------------------------------------------------------------
 * Dependency toggles
 * ---------------------------------------------------------------------- */

function initDependencies() {
  const fields = Array.from(document.querySelectorAll('.airy-field[data-depends]'));
  if (!fields.length) return;

  // A switch counts as on only while its own field is shown, so chains
  // (bell warnings → bell → notices) hide together.
  const isOn = (path, seen = new Set()) => {
    if (seen.has(path)) return false;
    seen.add(path);

    const control = document.querySelector(`.airy-switch[data-path="${path}"]`);
    if (!control || !control.checked) return false;

    const own = control.closest('.airy-field[data-depends]');
    return own ? isOn(own.getAttribute('data-depends'), seen) : true;
  };

  const update = () => {
    fields.forEach((field) => {
      const on = isOn(field.getAttribute('data-depends'));
      field.hidden = !on;
      field.setAttribute('aria-hidden', String(!on));
    });
  };

  document.querySelectorAll('.airy-switch[data-path]').forEach((control) => {
    control.addEventListener('change', update);
  });
  update();
}

/* -------------------------------------------------------------------------
 * Export copy button
 * ---------------------------------------------------------------------- */

function flash(button, text, duration = 1600) {
  const label = button.lastChild;
  if (!label || label.nodeType !== Node.TEXT_NODE) return;
  const previous = label.textContent;
  label.textContent = text;
  window.setTimeout(() => {
    label.textContent = previous;
  }, duration);
}

function initCopyButtons() {
  document.querySelectorAll('.airy-copy').forEach((button) => {
    const target = document.getElementById(button.dataset.target);
    if (!target) return;

    button.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(target.value);
      } catch (error) {
        target.select();
        try {
          document.execCommand('copy');
        } catch (fallbackError) {
          return;
        }
      }
      flash(button, button.dataset.done || 'Copied');
    });
  });

  // Export to JSON: download the export box's contents as a file.
  document.querySelectorAll('.airy-download').forEach((button) => {
    const target = document.getElementById(button.dataset.target);
    if (!target) return;

    button.addEventListener('click', () => {
      const blob = new Blob([target.value], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = button.dataset.filename || 'airypress-settings.json';
      document.body.append(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  });

  // Import from JSON: load a chosen .json file into the import box (the
  // user then clicks "Import settings"). Invalid JSON leaves the box as is.
  document.querySelectorAll('.airy-upload').forEach((button) => {
    const target = document.getElementById(button.dataset.target);
    const input = document.getElementById(button.dataset.file);
    if (!target || !input) return;

    button.addEventListener('click', () => input.click());

    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      if (!file) return;

      const text = await file.text();
      input.value = '';

      try {
        JSON.parse(text);
      } catch (error) {
        flash(button, button.dataset.invalid || 'Invalid JSON', 3000);
        return;
      }

      target.value = text;
      target.focus();
      flash(button, button.dataset.done || 'Loaded', 3000);
    });
  });

  // Destructive buttons ask first.
  document.querySelectorAll('[data-confirm]').forEach((button) => {
    button.addEventListener('click', (event) => {
      // eslint-disable-next-line no-alert
      if (!window.confirm(button.dataset.confirm)) event.preventDefault();
    });
  });

  document.querySelectorAll('.airy-paste').forEach((button) => {
    const target = document.getElementById(button.dataset.target);
    if (!target) return;

    button.addEventListener('click', async () => {
      try {
        target.value = await navigator.clipboard.readText();
        target.focus();
        flash(button, button.dataset.done || 'Pasted');
      } catch (error) {
        // No clipboard access (permission denied or insecure context).
        target.focus();
        flash(button, button.dataset.denied || 'Paste with Ctrl+V');
      }
    });
  });
}

/* -------------------------------------------------------------------------
 * Analytics connection test
 * ---------------------------------------------------------------------- */

function initAnalyticsTest() {
  document.querySelectorAll('[data-airy-ga-test]').forEach((button) => {
    const result = button.parentElement
      ? button.parentElement.querySelector('.airy-ga-test-result')
      : null;

    button.addEventListener('click', async () => {
      const rest = button.getAttribute('data-rest');
      const nonce = button.getAttribute('data-nonce');
      if (!rest) return;

      const previous = button.textContent;
      button.disabled = true;
      button.textContent = 'Testing…';
      if (result) {
        result.textContent = '';
        result.dataset.state = 'pending';
      }

      try {
        const url = new URL(rest, window.location.origin);
        url.searchParams.set('refresh', '1');
        const response = await fetch(url.toString(), {
          headers: { 'X-WP-Nonce': nonce || '' },
          credentials: 'same-origin',
        });
        const data = await response.json().catch(() => null);

        if (!response.ok) {
          throw new Error(
            (data && data.message) || `Request failed (${response.status})`
          );
        }

        const total = Number(data && data.activeUsers) || 0;
        if (result) {
          result.textContent = `Connected — ${total} active user${total === 1 ? '' : 's'} right now.`;
          result.dataset.state = 'ok';
        }
      } catch (error) {
        if (result) {
          result.textContent = error && error.message ? error.message : 'Connection failed.';
          result.dataset.state = 'error';
        }
      } finally {
        button.disabled = false;
        button.textContent = previous;
      }
    });
  });
}

/**
 * Range sliders show their value next to them while dragging, and can
 * preview it live through a CSS custom property on <body> (data-live-var).
 */
function initRangeFields() {
  document.querySelectorAll('input.airy-range').forEach((range) => {
    const output = range.parentElement.querySelector('.airy-range-value');
    const unit = range.dataset.unit || '';
    const update = () => {
      if (output) {
        output.textContent = range.value + unit;
      }

      // How far the accent part of the track reaches (settings.css).
      const min = Number(range.min || 0);
      const max = Number(range.max || 100);
      const fill = max > min ? ((Number(range.value) - min) / (max - min)) * 100 : 0;
      range.style.setProperty('--airy-range-fill', `${fill}%`);

      if (range.dataset.liveVar) {
        document.body.style.setProperty(range.dataset.liveVar, range.value + unit);
      }
    };

    range.addEventListener('input', update);
    range.addEventListener('change', update);
    update();
  });
}

function init() {
  initTabs();
  initColorFields();
  initRangeFields();
  initImageFields();
  initColumnLists();
  initKeepAllLists();
  initDependencies();
  initCopyButtons();
  initAnalyticsTest();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
