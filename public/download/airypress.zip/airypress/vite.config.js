import { defineConfig } from 'vite';

const FONT_RE = /\.(woff2?|ttf|eot|otf)$/;
const CSS_RE = /\.css$/;

function assetFileName(assetInfo) {
  const name = (assetInfo.names && assetInfo.names[0]) || assetInfo.name || '';

  if (CSS_RE.test(name)) {
    return '[name][extname]';
  }

  if (FONT_RE.test(name)) {
    return 'fonts/[name][extname]';
  }

  return 'assets/[name][extname]';
}

export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    manifest: false,
    cssCodeSplit: true,
    rollupOptions: {
      input: {
        admin: 'assets/scripts/admin.js',
        settings: 'assets/scripts/settings.js',
        editor: 'assets/styles/editor.css',
        tinymce: 'assets/styles/tinymce.css',
        login: 'assets/styles/login.css',
        'sidebar-light': 'assets/styles/admin/sidebar-light.css',
        'theme-modern': 'assets/styles/admin/theme-modern.css',
        analytics: 'assets/scripts/analytics.js',
        'analytics-toolbar': 'assets/scripts/analytics-toolbar.js',
        'menu-builder': 'assets/scripts/menu-builder.js',
        social: 'assets/scripts/social.js',
        request: 'assets/scripts/request.js',
      },
      output: {
        entryFileNames: '[name].js',
        // Shared code (SortableJS for the menu builder and settings) without a
        // hash, so committed dist/ files keep stable names.
        chunkFileNames: 'chunks/[name].js',
        assetFileNames: assetFileName,
      },
    },
  },
});
