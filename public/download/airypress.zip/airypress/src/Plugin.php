<?php

declare (strict_types = 1);
namespace DigitalBrew\AiryPress;

use DigitalBrew\AiryPress\Modules\Admin\Bar;
use DigitalBrew\AiryPress\Modules\Admin\Cleanup;
use DigitalBrew\AiryPress\Modules\Admin\Columns;
use DigitalBrew\AiryPress\Modules\Admin\Dashboard;
use DigitalBrew\AiryPress\Modules\Admin\Footer;
use DigitalBrew\AiryPress\Modules\Admin\Menu;
use DigitalBrew\AiryPress\Modules\Admin\Navigation;
use DigitalBrew\AiryPress\Modules\Admin\Tables;
use DigitalBrew\AiryPress\Modules\Admin\Theme;
use DigitalBrew\AiryPress\Modules\Admin\Welcome;
use DigitalBrew\AiryPress\Modules\Content\Comments;
use DigitalBrew\AiryPress\Modules\Content\LastLogin;
use DigitalBrew\AiryPress\Modules\Content\Posts;
use DigitalBrew\AiryPress\Modules\Front\Favicon;
use DigitalBrew\AiryPress\Modules\Front\Head;
use DigitalBrew\AiryPress\Modules\Front\JQuery;
use DigitalBrew\AiryPress\Modules\Front\SocialMeta;
use DigitalBrew\AiryPress\Modules\Front\Tracking;
use DigitalBrew\AiryPress\Modules\Integrations\Analytics;
use DigitalBrew\AiryPress\Modules\Login;
use DigitalBrew\AiryPress\Modules\Maintenance;
use DigitalBrew\AiryPress\Modules\Security;
use DigitalBrew\AiryPress\Licensing\Pro;
use DigitalBrew\AiryPress\Pro\Access;
use DigitalBrew\AiryPress\Pro\Notices;
use DigitalBrew\AiryPress\Pro\Requests;
use DigitalBrew\AiryPress\Pro\WhiteLabel;
use DigitalBrew\AiryPress\Settings\Settings;
use DigitalBrew\AiryPress\Settings\SettingsPage;
final class Plugin {
    public static function boot() : void {
        $settings = Settings::instance();
        if ( is_admin() ) {
            ( new SettingsPage($settings) )->register();
            // Also covers sites activated before uninstall.php was replaced.
            add_action( 'admin_init', [Uninstall::class, 'register'] );
        }
        /**
         * Filters the module classes AiryPress boots. Remove one to switch a
         * feature off in code, or add your own: a class with a public
         * `register(Settings $settings)` method that adds hooks.
         *
         * @param array<int, class-string> $modules
         */
        $modules = self::modules();
        $modules = (array) apply_filters( 'airypress/modules', $modules, $settings );
        foreach ( $modules as $class ) {
            if ( is_string( $class ) && class_exists( $class ) && method_exists( $class, 'register' ) ) {
                ( new $class() )->register( $settings );
            }
        }
        /**
         * Fires after every module registered its hooks.
         *
         * @param Settings $settings
         */
        do_action( 'airypress/loaded', $settings );
    }

    /**
     * @return array<int, class-string>
     */
    private static function modules() : array {
        return [
            Theme::class,
            Navigation::class,
            Bar::class,
            Dashboard::class,
            Footer::class,
            Tables::class,
            Welcome::class,
            Cleanup::class,
            Comments::class,
            Posts::class,
            LastLogin::class,
            Head::class,
            JQuery::class,
            Tracking::class,
            Favicon::class,
            Security::class,
            Login::class,
            Maintenance::class
        ];
    }

}
