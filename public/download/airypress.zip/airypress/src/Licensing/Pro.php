<?php

declare (strict_types = 1);
namespace DigitalBrew\AiryPress\Licensing;

/**
 * Whether Pro features are available, and which settings belong to Pro.
 */
final class Pro {
    /**
     * Settings that belong to Pro (dot paths; a path covers its children).
     */
    private const PATHS = [
        'admin.theme.sidebar',
        'admin_bar.plugins',
        'admin_bar.account',
        'dashboard.airypress',
        'dashboard.plugins',
        'tables.columns',
        'tables.orders',
        'frontend.jquery.cdn',
        'login.background_image',
        'login.message',
        'maintenance.background_image',
        'analytics.enabled',
        'analytics.property_id',
        'analytics.toolbar',
        'analytics.toolbar_frontend',
        'analytics.roles',
        'analytics.default_range',
        'social',
        'notices',
        'whitelabel',
        'access',
        'welcome.roles',
        'request'
    ];

    /**
     * Values Pro settings take without Pro, where the default isn't "off".
     */
    private const FREE_VALUES = [
        'admin.theme.sidebar' => 'dark',
        'admin_bar.account'   => 'toolbar',
        'dashboard.airypress' => [],
        'tables.columns'      => [],
        'tables.orders.add'   => [],
        'analytics.enabled'   => false,
        'analytics.toolbar'   => false,
        'social.enabled'      => false,
        'notices.enabled'     => false,
        'access.users'        => [],
        'whitelabel.enabled'  => false,
    ];

    private static ?bool $active = null;

    public static function active() : bool {
        if ( self::$active !== null ) {
            return self::$active;
        }
        // Stripped from the free build, where Pro is never active. Kept as
        // nested ifs: Freemius only strips an `if` around its own call.
        $active = false;
        // Preview the free plugin on a development site.
        if ( defined( 'AIRYPRESS_FREE_PREVIEW' ) && AIRYPRESS_FREE_PREVIEW ) {
            $active = false;
        }
        self::$active = $active;
        return $active;
    }

    /**
     * Each Pro setting's value without Pro: dot path => value.
     *
     * @param array<string, mixed> $defaults
     *
     * @return array<string, mixed>
     */
    public static function freeValues( array $defaults ) : array {
        $values = [];
        foreach ( self::PATHS as $path ) {
            $value = $defaults;
            foreach ( explode( '.', $path ) as $segment ) {
                $value = ( is_array( $value ) && array_key_exists( $segment, $value ) ? $value[$segment] : null );
            }
            if ( $value !== null ) {
                $values[$path] = $value;
            }
        }
        return array_merge( $values, self::FREE_VALUES );
    }

    public static function isProPath( string $path ) : bool {
        foreach ( self::PATHS as $pro ) {
            if ( $path === $pro || str_starts_with( $path, $pro . '.' ) ) {
                return true;
            }
        }
        return false;
    }

    /**
     * A Pro setting that can't be changed without Pro.
     */
    public static function locked( string $path ) : bool {
        return self::isProPath( $path ) && !self::active();
    }

    public static function upgradeUrl() : string {
        $url = Licensing::PRO_URL;
        if ( !Licensing::agency() ) {
            $url = (string) airy_fs()->get_upgrade_url();
        }
        return $url;
    }

    /**
     * The "Pro" pill shown next to Pro settings.
     */
    public static function pill() : string {
        return sprintf( '<a class="airy-pro-pill" href="%s" target="_blank" rel="noopener" title="%s">Pro</a>', esc_url( Licensing::PRO_URL ), esc_attr__( 'Available in AiryPress Pro', 'airypress' ) );
    }

}
