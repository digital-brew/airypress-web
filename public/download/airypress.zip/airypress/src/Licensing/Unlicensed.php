<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Licensing;

/**
 * Stands in for the Freemius instance in agency mode: the premium code is
 * present and usable, nothing is registered or tracked.
 */
final class Unlicensed
{
    /**
     * @param array<int, mixed> $arguments
     */
    public function __call(string $name, array $arguments): mixed
    {
        $name = str_replace('__premium_only', '', $name);

        return match ($name) {
            'is', 'is_premium', 'can_use_premium_code', 'is_paying', 'is_paying_or_trial' => true,
            'get_upgrade_url', 'pricing_url' => Licensing::PRO_URL,
            default => false,
        };
    }
}
