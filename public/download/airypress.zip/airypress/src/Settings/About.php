<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Settings;

use DigitalBrew\AiryPress\Licensing\Licensing;
use DigitalBrew\AiryPress\Licensing\Pro;

/**
 * The About tab of Settings → AiryPress (what it is, Free and Pro, where the
 * documentation is, what's new) and the per-tab documentation links. Both
 * stay out of a white-labelled admin.
 */
final class About
{
    /** Online documentation; one page per settings tab. */
    public const DOCS_URL = 'https://airypress.com/docs/';

    private const SUPPORT_URL = 'https://wordpress.org/support/plugin/airypress/';

    /** Settings tab => documentation page. */
    private const TAB_DOCS = [
        'appearance' => 'appearance',
        'menu-builder' => 'menu-builder',
        'toolbar' => 'toolbar',
        'dashboard' => 'dashboard',
        'content' => 'content-and-tables',
        'cleanup' => 'admin-cleanup',
        'frontend' => 'front-end',
        'security' => 'security',
        'login' => 'login',
        'maintenance' => 'maintenance',
        'analytics' => 'analytics',
        'whitelabel' => 'white-label',
        'site' => 'site-identity',
        'tools' => 'tools',
    ];

    private Settings $settings;

    public function __construct(Settings $settings)
    {
        $this->settings = $settings;
    }

    /**
     * Off in a white-labelled admin: clients shouldn't land on a product page.
     */
    public function visible(): bool
    {
        return ! (Pro::active() && $this->settings->get('whitelabel.enabled', false));
    }

    /**
     * A documentation page ('' for the index).
     */
    public static function docsUrl(string $page = ''): string
    {
        $url = self::DOCS_URL . ($page !== '' ? trailingslashit($page) : '');

        /**
         * Filters a documentation link on the settings screen.
         *
         * @param string $url  The link.
         * @param string $page The page slug ('' for the index).
         */
        return (string) apply_filters('airypress/docs_url', $url, $page);
    }

    /**
     * "Docs" link at the top of a settings tab.
     */
    public function tabLink(string $tab): void
    {
        if (! $this->visible() || ! isset(self::TAB_DOCS[$tab])) {
            return;
        }

        printf(
            '<p class="airy-panel-docs"><a href="%s" target="_blank" rel="noopener"><span class="dashicons dashicons-book-alt" aria-hidden="true"></span>%s<span class="screen-reader-text"> %s</span></a></p>',
            esc_url(self::docsUrl(self::TAB_DOCS[$tab])),
            esc_html__('Docs', 'airypress'),
            esc_html__('(opens in a new tab)', 'airypress')
        );
    }

    /**
     * @param array<string, array<string, mixed>> $sections Schema::sections().
     */
    public function render(array $sections, callable $proCard): void
    {
        if (! $this->visible()) {
            return;
        }
        ?>
        <section class="airy-panel airy-about" id="airy-panel-about" role="tabpanel" data-tab="about" data-standalone>
            <?php $this->renderIntro(); ?>
            <?php $proCard(); ?>
            <?php $this->renderPlans(); ?>
            <?php $this->renderDocs($sections); ?>
            <?php $this->renderNews(); ?>
        </section>
        <?php
    }

    private function renderIntro(): void
    {
        if (! Pro::active()) {
            $plan = __('Free', 'airypress');
        } elseif (Licensing::agency()) {
            $plan = __('Agency licence', 'airypress');
        } else {
            $plan = __('Pro', 'airypress');
        }

        $links = [
            ['dashicons-book-alt', __('Documentation', 'airypress'), self::docsUrl()],
            ['dashicons-list-view', __('Changelog', 'airypress'), self::docsUrl('changelog')],
        ];

        // Agency sites are supported by the agency itself.
        if (! Licensing::agency()) {
            // Pro: Freemius' contact form; free: the WordPress.org forum.
            $contact = Pro::active() ? (string) airy_fs()->contact_url() : '';
            $links[] = ['dashicons-sos', __('Support', 'airypress'), $contact !== '' ? $contact : self::SUPPORT_URL];

            if (Pro::active()) {
                $links[] = ['dashicons-admin-users', __('Account and licence', 'airypress'), (string) airy_fs()->get_account_url()];
            }
        }
        ?>
        <div class="airy-card airy-about-intro">
            <h2 class="airy-card-title"><?php esc_html_e('About AiryPress', 'airypress'); ?></h2>
            <p class="airy-card-desc"><?php esc_html_e('AiryPress gives wp-admin a calm, modern look and clears out what your clients don\'t need: a new admin theme, a tidier menu, toolbar and dashboard, cleaner list tables, plugin notices out of the way, a branded login and maintenance screen, and Google Analytics where you work.', 'airypress'); ?></p>
            <dl class="airy-about-meta">
                <div><dt><?php esc_html_e('Version', 'airypress'); ?></dt><dd><?php echo esc_html(AIRYPRESS_VERSION); ?></dd></div>
                <div><dt><?php esc_html_e('Plan', 'airypress'); ?></dt><dd><?php echo esc_html($plan); ?></dd></div>
                <div><dt><?php esc_html_e('Made by', 'airypress'); ?></dt><dd><a href="https://digitalbrew.io" target="_blank" rel="noopener">DigitalBrew</a></dd></div>
            </dl>
            <p class="airy-about-links">
                <?php foreach ($links as [$icon, $label, $url]) : ?>
                    <?php if ($url === '') {
                        continue;
                    } ?>
                    <a class="button" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener"><span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span><?php echo esc_html($label); ?></a>
                <?php endforeach; ?>
            </p>
        </div>
        <?php
    }

    /**
     * What each plan includes, by settings tab (docs/free-and-pro.md).
     */
    private function renderPlans(): void
    {
        $rows = [
            [__('Admin theme', 'airypress'), __('Dark frame, content card, Inter, accent colour, accordion submenus, block-editor accent, faster navigation, footer', 'airypress'), __('Modern and Light themes, per-user theme switch', 'airypress')],
            [__('Menu builder', 'airypress'), '', __('Drag-and-drop menu builder: four levels, rename, icons, custom links, labels, separators, hide per role', 'airypress')],
            [__('Toolbar', 'airypress'), __('Visible core items, front-end toolbar, Howdy, account card', 'airypress'), __('Hide items added by plugins, account at the bottom of the sidebar with a search field', 'airypress')],
            [__('Dashboard', 'airypress'), __('Visible core widgets, welcome widget', 'airypress'), __('Hide plugin widgets, Site analytics widget, welcome widget per role, request widget (email and Slack)', 'airypress')],
            [__('Content & tables', 'airypress'), __('Comments and posts off, Users columns, wide tables scroll sideways', 'airypress'), __('Post type columns (order, hide, sort, ACF fields), WooCommerce purchased products', 'airypress')],
            [__('Admin clean-up', 'airypress'), __('Help tabs, Screen Options, update nags, admin email check, saved messages as pop-ups, Appearance screens, automatic updates', 'airypress'), __('Admin notice manager, with notifications in the toolbar', 'airypress')],
            [__('Front end & security', 'airypress'), __('Everything else', 'airypress'), __('jQuery from a CDN', 'airypress')],
            [__('Login', 'airypress'), __('Logo, background colour, accent', 'airypress'), __('Background image, message', 'airypress')],
            [__('Maintenance', 'airypress'), __('Everything else', 'airypress'), __('Background image', 'airypress')],
            [__('Analytics', 'airypress'), __('GA4 tag with Consent Mode, Meta Pixel, Search Console', 'airypress'), __('GA4 dashboard widget, live visitors', 'airypress')],
            [__('White label', 'airypress'), '', __('Brand name, sidebar logo, settings access, hide AiryPress', 'airypress')],
            [__('Site identity', 'airypress'), __('Favicon', 'airypress'), __('Open Graph & X cards', 'airypress')],
            [__('Tools', 'airypress'), __('Export, import, reset', 'airypress'), ''],
        ];
        ?>
        <div class="airy-card airy-about-plans">
            <h2 class="airy-card-title"><?php esc_html_e('Free and Pro', 'airypress'); ?></h2>
            <p class="airy-card-desc"><?php esc_html_e('Free covers the theme and the clean-up. Pro adds the tools for handing a site over to a client.', 'airypress'); ?></p>
            <div class="airy-about-table-wrap">
                <table class="airy-about-table">
                    <thead>
                        <tr>
                            <th scope="col"><?php esc_html_e('Area', 'airypress'); ?></th>
                            <th scope="col"><?php esc_html_e('Free', 'airypress'); ?></th>
                            <th scope="col"><?php esc_html_e('Pro adds', 'airypress'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as [$area, $free, $pro]) : ?>
                            <tr>
                                <th scope="row"><?php echo esc_html($area); ?></th>
                                <td><?php echo $free !== '' ? esc_html($free) : '<span class="airy-about-none" aria-label="' . esc_attr__('Not included', 'airypress') . '">—</span>'; ?></td>
                                <td><?php echo $pro !== '' ? esc_html($pro) : '<span class="airy-about-none" aria-label="' . esc_attr__('Nothing extra', 'airypress') . '">—</span>'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * @param array<string, array<string, mixed>> $sections
     */
    private function renderDocs(array $sections): void
    {
        $tabs = [];

        foreach ($sections as $key => $section) {
            $tabs[(string) $key] = [(string) ($section['icon'] ?? ''), (string) $section['label']];

            if ($key === 'appearance') {
                $tabs['menu-builder'] = ['dashicons-menu-alt', __('Menu builder', 'airypress')];
            }
        }

        $tabs['tools'] = ['dashicons-admin-tools', __('Tools', 'airypress')];

        $guides = [
            ['dashicons-flag', __('Getting started', 'airypress'), 'getting-started'],
            ['dashicons-editor-help', __('FAQ', 'airypress'), 'faq'],
            ['dashicons-admin-plugins', __('Plugin compatibility', 'airypress'), 'compatibility'],
            ['dashicons-editor-code', __('Developers: hooks and constants', 'airypress'), 'developers'],
        ];
        ?>
        <div class="airy-card airy-about-docs">
            <h2 class="airy-card-title"><?php esc_html_e('Documentation', 'airypress'); ?></h2>
            <p class="airy-card-desc"><?php esc_html_e('Every setting explained, one page per tab. Each tab also has a Docs link at the top.', 'airypress'); ?></p>
            <ul class="airy-about-doclist airy-about-doclist--guides">
                <?php foreach ($guides as [$icon, $label, $page]) : ?>
                    <li><a href="<?php echo esc_url(self::docsUrl($page)); ?>" target="_blank" rel="noopener"><span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span><?php echo esc_html($label); ?></a></li>
                <?php endforeach; ?>
            </ul>
            <ul class="airy-about-doclist">
                <?php foreach ($tabs as $key => [$icon, $label]) : ?>
                    <?php if (! isset(self::TAB_DOCS[$key])) {
                        continue;
                    } ?>
                    <li><a href="<?php echo esc_url(self::docsUrl(self::TAB_DOCS[$key])); ?>" target="_blank" rel="noopener"><span class="dashicons <?php echo esc_attr($icon); ?>" aria-hidden="true"></span><?php echo esc_html($label); ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php
    }

    /**
     * The first entries of the latest version in CHANGELOG.md.
     */
    private function renderNews(): void
    {
        [$version, $items] = self::latestChanges(6);

        if ($items === []) {
            return;
        }
        ?>
        <div class="airy-card airy-about-news">
            <h2 class="airy-card-title"><?php
                /* translators: %s: version number */
                echo esc_html(sprintf(__('What\'s new in %s', 'airypress'), $version));
            ?></h2>
            <ul class="airy-about-newslist">
                <?php foreach ($items as [$title, $text]) : ?>
                    <li>
                        <?php if ($title !== '') : ?><strong><?php echo esc_html($title); ?></strong> <?php endif; ?>
                        <?php echo esc_html($text); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            <p><a href="<?php echo esc_url(self::docsUrl('changelog')); ?>" target="_blank" rel="noopener"><?php esc_html_e('Full changelog', 'airypress'); ?></a></p>
        </div>
        <?php
    }

    /**
     * @return array{0: string, 1: array<int, array{0: string, 1: string}>}
     */
    private static function latestChanges(int $limit): array
    {
        $file = AIRYPRESS_DIR . 'CHANGELOG.md';

        if (! is_readable($file)) {
            return ['', []];
        }

        $version = '';
        $items = [];

        foreach ((array) file($file, FILE_IGNORE_NEW_LINES) as $line) {
            $line = (string) $line;

            if (preg_match('/^## \[([^\]]+)\]/', $line, $match)) {
                if ($version !== '') {
                    break;
                }
                $version = $match[1];
                continue;
            }

            if ($version === '' || ! str_starts_with($line, '- ')) {
                continue;
            }

            $text = substr($line, 2);
            $title = '';

            // "**Name** (where): description" → a bold name and the description.
            if (preg_match('/^\*\*(.+?)\*\*(?:\s*\([^)]*\))?[:.]?\s*(.*)$/', $text, $match)) {
                $title = self::plain($match[1]);
                $text = $match[2];
            }

            $items[] = [$title, wp_trim_words(self::plain($text), 24)];

            if (count($items) >= $limit) {
                break;
            }
        }

        return [$version, $items];
    }

    /**
     * Markdown inline formatting to plain text.
     */
    private static function plain(string $text): string
    {
        $text = (string) preg_replace('/\[([^\]]+)\]\([^)]*\)/', '$1', $text);

        return trim(str_replace(['**', '`', '*'], '', $text));
    }
}
