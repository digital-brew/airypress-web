<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Settings;

use DigitalBrew\AiryPress\Licensing\Licensing;

/**
 * Declares every setting, its default and how it is rendered.
 *
 * `defaults()` must never use translations (it can run before `init`).
 * `sections()` builds labelled UI and is only called while rendering.
 */
final class Schema
{
    /**
     * Nested default values for the whole settings tree.
     *
     * @return array<string, mixed>
     */
    /**
     * Defaults in agency mode: everywhere else AiryPress only changes the look
     * (theme, accent, toolbar) until a setting is chosen. Dot path => value.
     */
    private const AGENCY_DEFAULTS = [
        'admin.footer.hide_version' => true,
        'admin.menu.hide' => ['customizer', 'widgets', 'writing', 'updates', 'wc_extensions', 'wc_separator'],
        'admin_bar.frontend.others' => false,
        'admin_bar.plugins' => ['kinsta-cache'],
        'network.menu.hide' => ['updates'],
        'dashboard.show' => [],
        'dashboard.plugins' => [],
        'content.comments' => false,
        'content.posts' => false,
        'tables.users.add' => ['last_login', 'registration_date'],
        'tables.users.track_last_login' => true,
        'tables.columns' => ['product' => ['hide' => ['product_tag', 'featured'], 'add' => ['total_sales']]],
        'tables.orders.add' => ['purchased'],
        'cleanup.admin_email_check' => true,
        'frontend.emoji' => false,
        'frontend.feeds' => false,
        'frontend.head_links' => false,
        'security.xmlrpc' => false,
        'security.rest_users' => true,
        'security.author_scan' => true,
        'security.login_language' => true,
        'security.login_logo_url' => true,
    ];

    public static function defaults(): array
    {
        $defaults = [
            'admin' => [
                'theme' => [
                    'enabled' => true,
                    'accent' => '#0fc0c0',
                    'sidebar' => 'dark',
                    'accordion' => true,
                    'block_editor' => true,
                ],
                'navigation' => [
                    'prefetch' => true,
                    'transitions' => true,
                ],
                'footer' => [
                    // The agency credit only on DigitalBrew's own client sites.
                    'text' => Licensing::agency()
                        ? 'Developed and maintained by the <a href="https://www.digitalbrew.io" target="_blank">award winning agency</a>.'
                        : '',
                    'hide_version' => false,
                ],
                'menu' => [
                    'hide' => [],
                    'labels' => [
                        'administration' => true,
                        'development' => true,
                    ],
                ],
            ],
            'admin_bar' => [
                'show' => ['site-name', 'edit', 'my-account', 'search'],
                'frontend' => [
                    'administrator' => true,
                    'others' => true,
                ],
                'replace_howdy' => true,
                'account' => 'toolbar',
                // '*' keeps every plugin toolbar item until one is unticked.
                'plugins' => ['*'],
            ],
            'network' => [
                'menu' => [
                    'hide' => [],
                ],
            ],
            'dashboard' => [
                // Every core widget; '*' keeps every plugin widget until one is unticked.
                'show' => self::fieldTypes()['dashboard.show']['options'],
                'airypress' => ['airypress_analytics'],
                'plugins' => ['*'],
            ],
            'content' => [
                'comments' => true,
                'posts' => true,
            ],
            'tables' => [
                'users' => [
                    'add' => [],
                    'remove' => [],
                    'track_last_login' => false,
                ],
                // Per post type: ['hide' => [...], 'add' => [...]] (Columns module).
                'columns' => [],
                'orders' => [
                    'add' => [],
                ],
            ],
            'cleanup' => [
                'help_tabs' => false,
                'screen_options' => false,
                'update_nags' => false,
                'admin_email_check' => false,
                'toasts' => true,
                // Always on for the agency's sites (updated with Composer); a choice elsewhere.
                'auto_updates_off' => Licensing::agency(),
                // Appearance sub-items; off = removed from the menu and the screen blocked.
                'appearance' => [
                    'themes' => true,
                    'design' => true,
                    'customizer' => true,
                    'fonts' => true,
                    'menus' => true,
                    'widgets' => true,
                    'patterns' => true,
                ],
            ],
            'frontend' => [
                'emoji' => true,
                'feeds' => true,
                'head_links' => true,
                'version_strings' => false,
                'oembed' => true,
                'dns_prefetch' => false,
                'jquery' => [
                    'enabled' => true,
                    'migrate' => true,
                    'cdn' => false,
                ],
            ],
            'security' => [
                'xmlrpc' => true,
                'rest_users' => false,
                'author_scan' => false,
                'login_language' => false,
                'login_logo_url' => false,
            ],
            'login' => [
                'enabled' => false,
                'logo' => 0,
                'background' => '#1e1e1e',
                'background_image' => 0,
                'message' => '',
            ],
            'maintenance' => [
                'enabled' => false,
                'title' => 'We\'ll be back soon',
                'subtitle' => 'We\'re doing some scheduled maintenance.',
                'body' => '',
                'background' => '#1e1e1e',
                'background_image' => 0,
                'text_color' => '#ffffff',
            ],
            'analytics' => [
                'enabled' => false,
                'property_id' => '',
                'toolbar' => true,
                'toolbar_frontend' => false,
                'roles' => ['administrator', 'editor'],
                'default_range' => '28',
                'tracking' => [
                    'measurement_id' => '',
                    'exclude_editors' => true,
                    'consent_mode' => true,
                    'verification' => '',
                    'meta_pixel' => '',
                ],
            ],
            'welcome' => [
                'enabled' => false,
                'title' => 'Welcome',
                'logo' => 0,
                'body' => '',
                'button_label' => 'Read our knowledge base',
                'button_url' => '',
                'links' => '',
                'roles' => [],
            ],
            'request' => [
                'enabled' => false,
                'title' => 'Request a change',
                'intro' => 'Need something changed on the website? Send us a request with the details and any files, and we\'ll get back to you.',
                'button_label' => 'Send a request',
                'email' => true,
                'recipient' => '',
                'slack' => false,
                'slack_webhook' => '',
                'attachments' => true,
                'roles' => [],
            ],
            'notices' => [
                'enabled' => false,
                'bell' => false,
                'bell_warnings' => false,
                'hidden' => [],
                'collapse_roles' => [],
            ],
            'whitelabel' => [
                'enabled' => false,
                'brand' => '',
                'logo' => 0,
                'logo_light' => 0,
                'logo_url' => '',
                'logo_position' => 'top',
                'logo_size' => 36,
                'hide_plugin' => true,
            ],
            'access' => [
                'users' => [],
            ],
            'social' => [
                'enabled' => true,
                'per_page' => false,
                'default_image' => 0,
                'home_title' => '',
                'home_description' => '',
                'twitter_card' => 'summary_large_image',
                'twitter_site' => '',
                'facebook_app_id' => '',
            ],
        ];

        // The agency's own client sites keep the opinionated set-up they were built with.
        if (Licensing::agency()) {
            foreach (self::AGENCY_DEFAULTS as $path => $value) {
                $node = &$defaults;

                foreach (explode('.', $path) as $key) {
                    $node = &$node[$key];
                }

                $node = $value;
                unset($node);
            }
        }

        return $defaults;
    }

    /**
     * Field metadata (type and allowed option keys) used by the sanitizer.
     *
     * Keys absent from this map are inferred from their default value
     * (bool => toggle, else text).
     *
     * @return array<string, array{type: string, options?: array<int, string>}>
     */
    public static function fieldTypes(): array
    {
        return [
            'admin.theme.accent' => ['type' => 'color'],
            'admin.theme.sidebar' => ['type' => 'select', 'options' => ['dark', 'modern', 'light']],
            'admin.footer.text' => ['type' => 'textarea'],
            'admin.menu.hide' => [
                'type' => 'checklist',
                'options' => ['customizer', 'widgets', 'writing', 'updates', 'wc_extensions', 'wc_separator'],
            ],
            'admin_bar.plugins' => ['type' => 'keys'],
            'admin_bar.account' => ['type' => 'select', 'options' => ['toolbar', 'sidebar']],
            'admin_bar.show' => [
                'type' => 'checklist',
                'options' => ['wp-logo', 'site-name', 'site-editor', 'comments', 'new-content', 'customize', 'archive', 'edit', 'my-account', 'updates', 'search', 'widgets'],
            ],
            'network.menu.hide' => ['type' => 'checklist', 'options' => ['updates']],
            'dashboard.show' => [
                'type' => 'checklist',
                'options' => [
                    'wp_welcome_panel',
                    'dashboard_site_health',
                    'dashboard_right_now',
                    'dashboard_activity',
                    'dashboard_primary',
                    'dashboard_quick_press',
                    'network_dashboard_right_now',
                    'network_dashboard_wordpress_events_and_news',
                ],
            ],
            'dashboard.airypress' => ['type' => 'checklist', 'options' => ['airypress_analytics']],
            'dashboard.plugins' => ['type' => 'keys'],
            'tables.users.add' => ['type' => 'checklist', 'options' => ['last_login', 'registration_date']],
            'tables.users.remove' => ['type' => 'checklist', 'options' => ['username', 'name', 'email', 'role', 'posts']],
            'analytics.tracking.measurement_id' => ['type' => 'text', 'sanitize' => [\DigitalBrew\AiryPress\Modules\Front\Tracking::class, 'sanitizeMeasurementId']],
            'analytics.tracking.verification' => ['type' => 'text', 'sanitize' => [\DigitalBrew\AiryPress\Modules\Front\Tracking::class, 'sanitizeVerification']],
            'analytics.tracking.meta_pixel' => ['type' => 'text', 'sanitize' => [\DigitalBrew\AiryPress\Modules\Front\Tracking::class, 'sanitizePixelId']],
            'social.default_image' => ['type' => 'image'],
            'social.home_description' => ['type' => 'textarea'],
            'social.twitter_card' => ['type' => 'select', 'options' => ['summary_large_image', 'summary']],
            'social.twitter_site' => ['type' => 'text', 'sanitize' => [self::class, 'sanitizeHandle']],
            'social.facebook_app_id' => ['type' => 'text', 'sanitize' => [self::class, 'sanitizeDigits']],
            'tables.columns' => ['type' => 'map', 'sanitize' => [\DigitalBrew\AiryPress\Modules\Admin\Columns::class, 'sanitize']],
            'tables.orders.add' => ['type' => 'checklist', 'options' => ['purchased']],
            'analytics.roles' => [
                'type' => 'checklist',
                'options' => ['administrator', 'editor', 'author', 'shop_manager'],
            ],
            'analytics.default_range' => ['type' => 'select', 'options' => ['7', '28', '90']],
            'login.logo' => ['type' => 'image'],
            'login.background' => ['type' => 'color'],
            'login.background_image' => ['type' => 'image'],
            'login.message' => ['type' => 'textarea'],
            'maintenance.body' => ['type' => 'textarea'],
            'maintenance.background' => ['type' => 'color'],
            'maintenance.background_image' => ['type' => 'image'],
            'maintenance.text_color' => ['type' => 'color'],
            'welcome.logo' => ['type' => 'image'],
            'welcome.body' => ['type' => 'textarea'],
            'welcome.button_url' => ['type' => 'text', 'sanitize' => [self::class, 'sanitizeLink']],
            'welcome.links' => ['type' => 'textarea', 'sanitize' => [self::class, 'sanitizeLinks']],
            'welcome.roles' => ['type' => 'keys'],
            'request.intro' => ['type' => 'textarea'],
            'request.recipient' => ['type' => 'text', 'sanitize' => [self::class, 'sanitizeEmail']],
            'request.slack_webhook' => ['type' => 'text', 'sanitize' => [self::class, 'sanitizeWebhook']],
            'request.roles' => ['type' => 'keys'],
            'notices.hidden' => ['type' => 'keys'],
            'notices.collapse_roles' => ['type' => 'keys'],
            'whitelabel.logo' => ['type' => 'image'],
            'whitelabel.logo_light' => ['type' => 'image'],
            'whitelabel.logo_url' => ['type' => 'text', 'sanitize' => [self::class, 'sanitizeLink']],
            'whitelabel.logo_position' => ['type' => 'select', 'options' => ['top', 'bottom']],
            'whitelabel.logo_size' => ['type' => 'range', 'min' => 20, 'max' => 80, 'step' => 2],
            'access.users' => ['type' => 'keys'],
        ];
    }

    /**
     * Tabs, cards and fields for the settings screen (translated).
     *
     * @return array<string, array{icon: string, label: string, cards: array<int, array<string, mixed>>}>
     */
    public static function sections(): array
    {
        return [
            'appearance' => [
                'icon' => 'dashicons-admin-appearance',
                'label' => __('Appearance', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Admin theme', 'airypress'),
                        'desc' => __('Applies the custom admin theme to wp-admin.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'admin.theme.enabled',
                                'type' => 'toggle',
                                'label' => __('Enable admin theme', 'airypress'),
                                'help' => __('Turns on the AiryPress look for wp-admin: dark frame, rounded content card, restyled menu, buttons, forms and tables. Turn it off to get the standard WordPress admin back; every other setting keeps working.', 'airypress'),
                            ],
                            [
                                'path' => 'admin.theme.accent',
                                'type' => 'color',
                                'label' => __('Accent colour', 'airypress'),
                                'help' => __('The highlight colour used for the current menu item, primary buttons, links, switches and focus rings.', 'airypress'),
                                'depends' => 'admin.theme.enabled',
                            ],
                            [
                                'path' => 'admin.theme.sidebar',
                                'type' => 'select',
                                'label' => __('Theme', 'airypress'),
                                'help' => __('Default keeps the sidebar and toolbar in the dark frame around a white content card. Light gives a light layout: a light grey sidebar joined to a grey content area under the dark toolbar, with a white highlight on the current item. Modern keeps the dark sidebar, runs it to the top of the screen and puts a light toolbar on top of the content card. Each user can override this in their profile.', 'airypress'),
                                'options' => \DigitalBrew\AiryPress\Modules\Admin\Theme::styleLabels(),
                                'depends' => 'admin.theme.enabled',
                            ],
                            [
                                'path' => 'admin.theme.accordion',
                                'type' => 'toggle',
                                'label' => __('Accordion submenus', 'airypress'),
                                'help' => __('Clicking a menu item that has a submenu opens it in place instead of loading its first page. Only one section stays open at a time.', 'airypress'),
                                'depends' => 'admin.theme.enabled',
                            ],
                            [
                                'path' => 'admin.theme.block_editor',
                                'type' => 'toggle',
                                'label' => __('Accent colours in the block editor', 'airypress'),
                                'help' => __('Uses your accent colour for buttons and highlights inside the block editor. The editor\'s layout is never changed.', 'airypress'),
                                'depends' => 'admin.theme.enabled',
                            ],
                        ],
                    ],
                    [
                        'title' => __('Navigation', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'admin.navigation.prefetch',
                                'type' => 'toggle',
                                'label' => __('Load pages on hover', 'airypress'),
                                'help' => __('When you hover a link in the admin, the browser quietly fetches that page so it opens almost instantly when clicked. Links that perform an action (trash, delete, activate, log out, anything with a security nonce) and edit screens are never fetched early. Works in Chrome, Edge and other Chromium browsers.', 'airypress'),
                            ],
                            [
                                'path' => 'admin.navigation.transitions',
                                'type' => 'toggle',
                                'label' => __('Smooth page transitions', 'airypress'),
                                'help' => __('Fades between admin pages instead of flashing white, while the toolbar and sidebar stay in place. Supported by Chromium browsers and Safari; others load pages normally. Turned off automatically for people who prefer reduced motion.', 'airypress'),
                            ],
                        ],
                    ],
                    [
                        'title' => __('Footer', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'admin.footer.text',
                                'type' => 'textarea',
                                'label' => __('Admin footer text', 'airypress'),
                                'help' => __('Text shown at the bottom of every admin page. Basic HTML such as links is allowed. Leave empty to keep WordPress\' own text.', 'airypress'),
                            ],
                            [
                                'path' => 'admin.footer.hide_version',
                                'type' => 'toggle',
                                'label' => __('Hide the WordPress version in the footer', 'airypress'),
                                'help' => __('Removes the WordPress version number from the bottom-right corner of the admin. When shown, it is always the installed version, never WordPress\' “Get Version …” update link.', 'airypress'),
                            ],
                        ],
                    ],
                ],
            ],
            // The admin menu itself (order, labels, hidden items) is managed in the
            // Menu builder tab; admin.menu.* defaults only seed its default layout.
            'toolbar' => [
                'icon' => 'dashicons-table-row-before',
                'label' => __('Toolbar', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Toolbar', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'admin_bar.show',
                                'type' => 'checklist',
                                'label' => __('Visible core toolbar items', 'airypress'),
                                'help' => __('WordPress\' own toolbar items to show, in the admin and on the front end. Unticked items are removed. The mobile menu button and the Ctrl+K command palette always stay.', 'airypress'),
                                'options' => [
                                    'wp-logo' => __('WordPress logo menu', 'airypress'),
                                    'site-name' => __('Site name', 'airypress'),
                                    'site-editor' => __('Edit site (block themes)', 'airypress'),
                                    'comments' => __('Comments', 'airypress'),
                                    'new-content' => __('New content', 'airypress'),
                                    'customize' => __('Customize', 'airypress'),
                                    'archive' => __('Archive / search', 'airypress'),
                                    'edit' => __('Edit', 'airypress'),
                                    'my-account' => __('My account', 'airypress'),
                                    'updates' => __('Updates', 'airypress'),
                                    'search' => __('Search', 'airypress'),
                                    'widgets' => __('Widgets', 'airypress'),
                                ],
                            ],
                            [
                                'path' => 'admin_bar.plugins',
                                'type' => 'keys',
                                'source' => [\DigitalBrew\AiryPress\Modules\Admin\Bar::class, 'pluginNodeOptions'],
                                'label' => __('Visible toolbar items added by plugins', 'airypress'),
                                'help' => __('Plugin menus to show in the toolbar; every other item a plugin adds is removed, in the admin and on the front end. Greyed-out items belong to plugins that aren\'t active and can be ticked in advance. Items from other plugins are added to this list the first time they appear. Every item stays until you untick one.', 'airypress'),
                            ],
                            [
                                'path' => 'admin_bar.frontend.administrator',
                                'type' => 'toggle',
                                'label' => __('Show toolbar on the front end for administrators', 'airypress'),
                                'help' => __('Shows the toolbar to administrators while they browse the website. Each user\'s own profile setting can still turn it off.', 'airypress'),
                            ],
                            [
                                'path' => 'admin_bar.frontend.others',
                                'type' => 'toggle',
                                'label' => __('Show toolbar on the front end for other roles', 'airypress'),
                                'help' => __('Shows the toolbar on the website to logged-in users who are not administrators (editors, shop managers, customers…).', 'airypress'),
                            ],
                            [
                                'path' => 'admin_bar.replace_howdy',
                                'type' => 'toggle',
                                'label' => __('Show display name instead of “Howdy, …”', 'airypress'),
                                'help' => __('Replaces the “Howdy, name” greeting in the top-right corner with just the user\'s display name.', 'airypress'),
                            ],
                            [
                                'path' => 'admin_bar.account',
                                'type' => 'select',
                                'label' => __('Account menu position', 'airypress'),
                                'help' => __('Where your name and avatar sit. Bottom of the sidebar also turns the Ctrl+K command palette into a search field in the middle of the toolbar. On phones the account stays in the toolbar.', 'airypress'),
                                'options' => [
                                    'toolbar' => __('Toolbar (top right)', 'airypress'),
                                    'sidebar' => __('Bottom of the sidebar', 'airypress'),
                                ],
                                'depends' => 'admin.theme.enabled',
                            ],
                        ],
                    ],
                    [
                        'title' => __('Network admin', 'airypress'),
                        'condition' => 'multisite',
                        'fields' => [
                            [
                                'path' => 'network.menu.hide',
                                'type' => 'checklist',
                                'label' => __('Hidden network items', 'airypress'),
                                'help' => __('Ticked items are removed from the Network Admin menu on multisite installs.', 'airypress'),
                                'options' => [
                                    'updates' => __('Dashboard → Updates', 'airypress'),
                                ],
                            ],
                        ],
                    ],
                ],
            ],
            'dashboard' => [
                'icon' => 'dashicons-dashboard',
                'label' => __('Dashboard', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Dashboard Widgets', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'dashboard.show',
                                'type' => 'checklist',
                                'label' => __('Visible core widgets', 'airypress'),
                                'help' => __('WordPress\' own Dashboard widgets to show, for everyone. Unticked widgets are removed. WordPress\' warnings about an outdated browser or PHP version always show.', 'airypress'),
                                'options' => [
                                    'wp_welcome_panel' => __('Welcome panel', 'airypress'),
                                    'dashboard_site_health' => __('Site Health', 'airypress'),
                                    'dashboard_right_now' => __('At a Glance', 'airypress'),
                                    'dashboard_activity' => __('Activity', 'airypress'),
                                    'dashboard_primary' => __('WordPress Events and News', 'airypress'),
                                    'dashboard_quick_press' => __('Quick Draft', 'airypress'),
                                    'network_dashboard_right_now' => __('Network: Right Now', 'airypress'),
                                    'network_dashboard_wordpress_events_and_news' => __('Network: Events and News', 'airypress'),
                                ],
                            ],
                            [
                                'path' => 'dashboard.airypress',
                                'type' => 'checklist',
                                'label' => __('Visible AiryPress widgets', 'airypress'),
                                'help' => __('Widgets that come with AiryPress. Site analytics shows visitors, page views, top pages, sources and devices from Google Analytics, and needs the Analytics tab to be set up; who can see it is set there.', 'airypress'),
                                'options' => [
                                    'airypress_analytics' => __('Site analytics', 'airypress'),
                                ],
                            ],
                            [
                                'path' => 'dashboard.plugins',
                                'type' => 'keys',
                                'source' => [\DigitalBrew\AiryPress\Modules\Admin\Dashboard::class, 'pluginWidgetOptions'],
                                'label' => __('Visible widgets added by plugins', 'airypress'),
                                'help' => __('Plugin widgets to show on the Dashboard; every other widget a plugin adds is removed. Greyed-out widgets belong to plugins that aren\'t active and can be ticked in advance. Widgets from other plugins are added to this list the first time they appear. Every widget stays until you untick one.', 'airypress'),
                            ],
                        ],
                    ],
                    [
                        'title' => __('Welcome widget', 'airypress'),
                        'desc' => __('A dashboard widget you write once for your clients: your logo, a short message, a button to ask for help and useful links.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'welcome.enabled',
                                'type' => 'toggle',
                                'label' => __('Show the welcome widget', 'airypress'),
                                'help' => __('Adds the widget at the top of the Dashboard.', 'airypress'),
                            ],
                            [
                                'path' => 'welcome.title',
                                'type' => 'text',
                                'label' => __('Title', 'airypress'),
                                'help' => __('The widget\'s heading, e.g. “Welcome to your website”.', 'airypress'),
                                'depends' => 'welcome.enabled',
                            ],
                            [
                                'path' => 'welcome.logo',
                                'type' => 'image',
                                'label' => __('Logo', 'airypress'),
                                'help' => __('Your agency\'s logo, shown at the top of the widget.', 'airypress'),
                                'depends' => 'welcome.enabled',
                            ],
                            [
                                'path' => 'welcome.body',
                                'type' => 'textarea',
                                'label' => __('Message', 'airypress'),
                                'help' => __('A few lines for your client: who to contact, opening hours, what\'s included. Basic HTML such as links and bold text is allowed.', 'airypress'),
                                'depends' => 'welcome.enabled',
                            ],
                            [
                                'path' => 'welcome.button_label',
                                'type' => 'text',
                                'label' => __('Button label', 'airypress'),
                                'help' => __('Text of the main button, e.g. “Read our knowledge base”. Leave the link empty to hide the button.', 'airypress'),
                                'depends' => 'welcome.enabled',
                            ],
                            [
                                'path' => 'welcome.button_url',
                                'type' => 'text',
                                'label' => __('Button link', 'airypress'),
                                'help' => __('A web address (e.g. your knowledge base or support form) or an email link such as mailto:support@example.com.', 'airypress'),
                                'depends' => 'welcome.enabled',
                            ],
                            [
                                'path' => 'welcome.links',
                                'type' => 'textarea',
                                'label' => __('Links', 'airypress'),
                                'help' => __('One link per line as “Label | address”, e.g. “How to add a blog post | https://…”. Handy for how-to videos and guides.', 'airypress'),
                                'depends' => 'welcome.enabled',
                            ],
                            [
                                'path' => 'welcome.roles',
                                'type' => 'keys',
                                'source' => [self::class, 'roleOptions'],
                                'label' => __('Show to these roles', 'airypress'),
                                'help' => __('Only these roles see the widget. Tick none to show it to everyone who can see the Dashboard.', 'airypress'),
                                'depends' => 'welcome.enabled',
                            ],
                        ],
                    ],
                    [
                        'title' => __('Request widget', 'airypress'),
                        'desc' => __('A dashboard form for your clients to ask for changes: a title, a message and optional attachments, sent to your inbox, a Slack channel or both.', 'airypress'),
                        'footer' => [\DigitalBrew\AiryPress\Pro\Requests::class, 'renderSlackSetup'],
                        'fields' => [
                            [
                                'path' => 'request.enabled',
                                'type' => 'toggle',
                                'label' => __('Show the request widget', 'airypress'),
                                'help' => __('Adds the form to the Dashboard. It needs at least one way of sending: email, or Slack with a webhook URL.', 'airypress'),
                            ],
                            [
                                'path' => 'request.title',
                                'type' => 'text',
                                'label' => __('Title', 'airypress'),
                                'help' => __('The widget\'s heading, also used for the form, e.g. “Request a change”.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.intro',
                                'type' => 'textarea',
                                'label' => __('Description', 'airypress'),
                                'help' => __('A line or two on the Dashboard about what the request form is for. Basic HTML such as links and bold text is allowed.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.button_label',
                                'type' => 'text',
                                'label' => __('Button label', 'airypress'),
                                'help' => __('The button that opens the request form.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.attachments',
                                'type' => 'toggle',
                                'label' => __('Allow attachments', 'airypress'),
                                'help' => __('Up to 5 files (10 MB each, the file types WordPress allows) for users who can upload media.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.email',
                                'type' => 'toggle',
                                'label' => __('Send by email', 'airypress'),
                                'help' => __('Emails each request, with its attachments, to the address below. Replying answers the person who sent it.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.recipient',
                                'type' => 'text',
                                'label' => __('Send to', 'airypress'),
                                'help' => __('Usually your agency\'s support address. Empty: the site\'s administration email (Settings → General).', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.slack',
                                'type' => 'toggle',
                                'label' => __('Send to Slack', 'airypress'),
                                'help' => __('Posts each request to a Slack channel. Attachments are stored on this site and linked from the message.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.slack_webhook',
                                'type' => 'text',
                                'label' => __('Slack webhook URL', 'airypress'),
                                'help' => __('The channel\'s webhook address (https://hooks.slack.com/services/…). “Connect Slack” below shows how to get one.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                            [
                                'path' => 'request.roles',
                                'type' => 'keys',
                                'source' => [self::class, 'roleOptions'],
                                'label' => __('Show to these roles', 'airypress'),
                                'help' => __('Only these roles see the form. Tick none to show it to everyone who can edit posts.', 'airypress'),
                                'depends' => 'request.enabled',
                            ],
                        ],
                    ],
                ],
            ],
            'content' => [
                'icon' => 'dashicons-list-view',
                'label' => __('Content & tables', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Content', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'content.comments',
                                'type' => 'toggle',
                                'label' => __('Enable comments', 'airypress'),
                                'help' => __('When off, comments are switched off site-wide: comment forms close, existing comments are hidden, and the Comments menu, toolbar icon and dashboard box are removed.', 'airypress'),
                            ],
                            [
                                'path' => 'content.posts',
                                'type' => 'toggle',
                                'label' => __('Enable Posts', 'airypress'),
                                'help' => __('When off, the blog Posts section (with Categories and Tags) is hidden from the admin menu, toolbar and nav-menu screen. Existing posts stay in the database and still load on the front end.', 'airypress'),
                            ],
                        ],
                    ],
                    [
                        'title' => __('Users table', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'tables.users.add',
                                'type' => 'checklist',
                                'label' => __('Add columns', 'airypress'),
                                'help' => __('Extra columns on the Users screen. “Last login” needs “Record last login time” to be on.', 'airypress'),
                                'options' => [
                                    'last_login' => __('Last login', 'airypress'),
                                    'registration_date' => __('Registration date', 'airypress'),
                                ],
                            ],
                            [
                                'path' => 'tables.users.remove',
                                'type' => 'checklist',
                                'label' => __('Remove columns', 'airypress'),
                                'help' => __('Ticked columns are removed from the Users screen.', 'airypress'),
                                'options' => [
                                    'username' => __('Username', 'airypress'),
                                    'name' => __('Name', 'airypress'),
                                    'email' => __('Email', 'airypress'),
                                    'role' => __('Role', 'airypress'),
                                    'posts' => __('Posts', 'airypress'),
                                ],
                            ],
                            [
                                'path' => 'tables.users.track_last_login',
                                'type' => 'toggle',
                                'label' => __('Record last login time', 'airypress'),
                                'help' => __('Saves the date and time each user last logged in, so it can be shown in the Users list.', 'airypress'),
                            ],
                        ],
                    ],
                    [
                        'title' => __('Post type columns', 'airypress'),
                        'desc' => __('Choose the columns of each list screen (Posts, Pages, Products and other content types): hide any of them and add extra ones.', 'airypress'),
                        'callback' => [\DigitalBrew\AiryPress\Modules\Admin\Columns::class, 'renderSettingsCard'],
                        'pro' => true,
                        'pro_desc' => __('For every post type\'s list (Posts, Pages, Products…): drag columns into order, hide any of them, choose which can be sorted, and add featured image, ID, slug, last modified, template, order, total sales and ACF field columns.', 'airypress'),
                    ],
                    [
                        'title' => __('WooCommerce', 'airypress'),
                        'condition' => 'woocommerce',
                        'fields' => [
                            [
                                'path' => 'tables.orders.add',
                                'type' => 'checklist',
                                'label' => __('Orders: add columns', 'airypress'),
                                'help' => __('Adds a column listing the products in each order (quantity × name) to the WooCommerce Orders list.', 'airypress'),
                                'options' => [
                                    'purchased' => __('Purchased products (HPOS and legacy)', 'airypress'),
                                ],
                            ],
                        ],
                    ],
                ],
            ],
            'cleanup' => [
                'icon' => 'dashicons-hidden',
                'label' => __('Admin clean-up', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Admin clean-up', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'cleanup.help_tabs',
                                'type' => 'toggle',
                                'label' => __('Hide Help tabs', 'airypress'),
                                'help' => __('Removes the “Help” drop-down tab from the top-right of admin screens.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.screen_options',
                                'type' => 'toggle',
                                'label' => __('Hide Screen Options', 'airypress'),
                                'help' => __('Removes the “Screen Options” drop-down tab, so users can\'t change columns or boxes shown on a screen.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.update_nags',
                                'type' => 'toggle',
                                'label' => __('Hide update notices for non-administrators', 'airypress'),
                                'help' => __('Hides “WordPress X is available” and maintenance notices from users who can\'t install updates anyway. Administrators still see them.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.admin_email_check',
                                'type' => 'toggle',
                                'label' => __('Disable the periodic admin email confirmation screen', 'airypress'),
                                'help' => __('Stops WordPress from periodically asking administrators to confirm the site\'s admin email address after logging in.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.toasts',
                                'type' => 'toggle',
                                'label' => __('Show “saved” messages as pop-ups', 'airypress'),
                                'help' => __('Success messages such as “Settings saved” or “Post updated” appear as a small pop-up in the top-right corner that disappears after a few seconds, instead of a box pushing the page down. Errors and warnings always stay on the page. Needs the admin theme.', 'airypress'),
                                'depends' => 'admin.theme.enabled',
                            ],
                        ],
                    ],
                    [
                        'title' => __('Updates', 'airypress'),
                        'condition' => 'not_agency',
                        'fields' => [
                            [
                                'path' => 'cleanup.auto_updates_off',
                                'type' => 'toggle',
                                'label' => __('Turn off automatic updates', 'airypress'),
                                'help' => __('Stops WordPress from updating itself, plugins, themes and translations in the background, including security releases, and hides the “Enable auto-updates” links. Only turn this on if you update sites yourself (e.g. with Composer or a management tool).', 'airypress'),
                            ],
                        ],
                    ],
                    [
                        'title' => __('Admin notices', 'airypress'),
                        'desc' => __('Tidy the notices plugins show at the top of admin screens. Hidden notices aren\'t lost: a small “N notices” button shows them again.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'notices.enabled',
                                'type' => 'toggle',
                                'label' => __('Manage admin notices', 'airypress'),
                                'help' => __('Turns on the options below and adds a “Snooze” button to every plugin notice, which hides it for that user for a week. WordPress\' own messages (such as “Settings saved”) are never hidden.', 'airypress'),
                            ],
                            [
                                'path' => 'notices.bell',
                                'type' => 'toggle',
                                'label' => __('Notifications in the toolbar', 'airypress'),
                                'help' => __('Moves plugin notices (tips, offers, “connect your account”, review requests) into a bell in the toolbar with a count, instead of the top of every screen. Plugin errors stay on the page, and so do WordPress\' own notices and notices that belong to the screen. Hidden and snoozed notices go to the bell too.', 'airypress'),
                                'depends' => 'notices.enabled',
                            ],
                            [
                                'path' => 'notices.bell_warnings',
                                'type' => 'toggle',
                                'label' => __('Move plugin warnings to the toolbar too', 'airypress'),
                                'help' => __('Also puts plugin warnings (orange notices, such as “please complete setup”) in the bell. Off: warnings stay on the page where they\'re harder to miss.', 'airypress'),
                                'depends' => 'notices.bell',
                            ],
                            [
                                'path' => 'notices.collapse_roles',
                                'type' => 'keys',
                                'source' => [self::class, 'roleOptions'],
                                'label' => __('Tuck away all plugin notices for', 'airypress'),
                                'help' => __('For these roles, every plugin notice goes behind the “N notices” button.', 'airypress'),
                                'depends' => 'notices.enabled',
                            ],
                            [
                                'path' => 'notices.hidden',
                                'type' => 'keys',
                                'source' => [\DigitalBrew\AiryPress\Pro\Notices::class, 'options'],
                                'columns' => 1,
                                'label' => __('Hidden for everyone', 'airypress'),
                                'help' => __('Notices seen on this site, newest first. Ticked ones go behind the “N notices” button for every user. Notices are added to this list the first time they appear.', 'airypress'),
                                'depends' => 'notices.enabled',
                            ],
                        ],
                    ],
                    [
                        'title' => __('Appearance menu', 'airypress'),
                        'desc' => __('Turn off Appearance screens a site doesn\'t need. A turned-off item is removed from the menu and the toolbar, and opening its screen goes to the Dashboard. Items a theme doesn\'t have (Menus and Widgets with block themes) don\'t appear anyway.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'cleanup.appearance.themes',
                                'type' => 'toggle',
                                'label' => __('Themes', 'airypress'),
                                'help' => __('Appearance → Themes: browse, install and switch themes.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.appearance.design',
                                'type' => 'toggle',
                                'label' => __('Design', 'airypress'),
                                'help' => __('The Site Editor (Appearance → Editor) for block themes: templates, styles and navigation.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.appearance.customizer',
                                'type' => 'toggle',
                                'label' => __('Customizer', 'airypress'),
                                'help' => __('Appearance → Customize, the live theme options screen, and the Customizer itself.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.appearance.fonts',
                                'type' => 'toggle',
                                'label' => __('Fonts', 'airypress'),
                                'help' => __('Appearance → Fonts, the font library.', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.appearance.menus',
                                'type' => 'toggle',
                                'label' => __('Menus', 'airypress'),
                                'help' => __('Appearance → Menus (classic themes).', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.appearance.widgets',
                                'type' => 'toggle',
                                'label' => __('Widgets', 'airypress'),
                                'help' => __('Appearance → Widgets (classic themes).', 'airypress'),
                            ],
                            [
                                'path' => 'cleanup.appearance.patterns',
                                'type' => 'toggle',
                                'label' => __('Patterns', 'airypress'),
                                'help' => __('The Patterns screen, for reusable blocks and synced patterns.', 'airypress'),
                            ],
                        ],
                    ],
                ],
            ],
            'frontend' => [
                'icon' => 'dashicons-desktop',
                'label' => __('Front end', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Head clean-up', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'frontend.emoji',
                                'type' => 'toggle',
                                'label' => __('Load emoji scripts', 'airypress'),
                                'help' => __('When off, removes WordPress\' emoji detection script and styles from every page. Modern browsers show emoji without them.', 'airypress'),
                            ],
                            [
                                'path' => 'frontend.feeds',
                                'type' => 'toggle',
                                'label' => __('Enable RSS feeds', 'airypress'),
                                'help' => __('When off, the RSS/Atom feed links are removed from the page head and any feed URL redirects to the homepage.', 'airypress'),
                            ],
                            [
                                'path' => 'frontend.head_links',
                                'type' => 'toggle',
                                'label' => __('Keep generator/RSD/WLW/shortlink/REST/oEmbed links in <head>', 'airypress'),
                                'help' => __('When off, removes extra tags from the page head: the WordPress generator/version, RSD and Windows Live Writer links, the shortlink, REST API and oEmbed discovery links.', 'airypress'),
                            ],
                            [
                                'path' => 'frontend.version_strings',
                                'type' => 'toggle',
                                'label' => __('Strip ?ver= from asset URLs', 'airypress'),
                                'help' => __('Removes the “?ver=” WordPress version number from CSS and JS URLs on the website, so the version isn\'t advertised. Plugin and theme versions are kept.', 'airypress'),
                            ],
                            [
                                'path' => 'frontend.oembed',
                                'type' => 'toggle',
                                'label' => __('Enable oEmbed JS', 'airypress'),
                                'help' => __('When off, removes the script that lets other WordPress sites embed your posts. Embedding YouTube, X and similar links in your own content still works.', 'airypress'),
                            ],
                            [
                                'path' => 'frontend.dns_prefetch',
                                'type' => 'toggle',
                                'label' => __('Remove DNS-prefetch hints', 'airypress'),
                                'help' => __('Removes WordPress\' DNS-prefetch hint for its emoji image server from the page head.', 'airypress'),
                            ],
                        ],
                    ],
                    [
                        'title' => __('jQuery', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'frontend.jquery.enabled',
                                'type' => 'toggle',
                                'label' => __('Load jQuery on the front end', 'airypress'),
                                'help' => __('Loads jQuery on the website. Turn off only if your theme and plugins don\'t need it; turning it off can break sliders, forms and similar features.', 'airypress'),
                            ],
                            [
                                'path' => 'frontend.jquery.migrate',
                                'type' => 'toggle',
                                'label' => __('Load jQuery Migrate', 'airypress'),
                                'help' => __('Loads jQuery Migrate, which keeps old jQuery code working. Most modern themes don\'t need it.', 'airypress'),
                                'depends' => 'frontend.jquery.enabled',
                            ],
                            [
                                'path' => 'frontend.jquery.cdn',
                                'type' => 'toggle',
                                'label' => __('Serve jQuery from a CDN', 'airypress'),
                                'help' => __('Loads jQuery from the official jQuery CDN instead of your own server. Usually slower than self-hosting today, and it sends visitor IPs to a third party.', 'airypress'),
                                'depends' => 'frontend.jquery.enabled',
                            ],
                        ],
                    ],
                ],
            ],
            'security' => [
                'icon' => 'dashicons-shield',
                'label' => __('Security', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Security', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'security.xmlrpc',
                                'type' => 'toggle',
                                'label' => __('Enable XML-RPC', 'airypress'),
                                'help' => __('XML-RPC is an old remote-publishing API that bots often use for password guessing. Keep it off unless something (such as the Jetpack plugin or an old mobile app) needs it.', 'airypress'),
                            ],
                            [
                                'path' => 'security.rest_users',
                                'type' => 'toggle',
                                'label' => __('Hide REST /wp/v2/users from logged-out visitors', 'airypress'),
                                'help' => __('Stops logged-out visitors from listing your users (and their login names) through /wp-json/wp/v2/users.', 'airypress'),
                            ],
                            [
                                'path' => 'security.author_scan',
                                'type' => 'toggle',
                                'label' => __('Block ?author=N enumeration', 'airypress'),
                                'help' => __('Redirects “?author=1” style URLs to the homepage so bots can\'t discover usernames. Author archive pages keep working.', 'airypress'),
                            ],
                        ],
                    ],
                ],
            ],
            'login' => [
                'icon' => 'dashicons-lock',
                'label' => __('Login', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Login screen', 'airypress'),
                        'desc' => __('Brand the wp-login.php screen. Buttons and focus rings use the accent colour from Appearance.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'login.enabled',
                                'type' => 'toggle',
                                'label' => __('Customise the login screen', 'airypress'),
                                'help' => __('Applies the settings below to the login, lost password and registration screens: Inter font, rounded form, your logo, background and accent colour. Turn it off to get the standard WordPress login screen back.', 'airypress'),
                            ],
                            [
                                'path' => 'login.logo',
                                'type' => 'image',
                                'label' => __('Logo', 'airypress'),
                                'help' => __('Replaces the WordPress logo above the form. It is scaled to fit 320 × 120 px. Leave empty to keep the WordPress logo.', 'airypress'),
                            ],
                            [
                                'path' => 'login.background',
                                'type' => 'color',
                                'label' => __('Background colour', 'airypress'),
                                'help' => __('Colour behind the form. The links below the form switch between light and dark text to stay readable.', 'airypress'),
                            ],
                            [
                                'path' => 'login.background_image',
                                'type' => 'image',
                                'label' => __('Background image', 'airypress'),
                                'help' => __('Covers the whole screen behind the form. The background colour shows while it loads.', 'airypress'),
                            ],
                            [
                                'path' => 'login.message',
                                'type' => 'textarea',
                                'label' => __('Message above the form', 'airypress'),
                                'help' => __('Optional text shown above the login form, for example who to contact for an account. Basic HTML such as links is allowed.', 'airypress'),
                            ],
                        ],
                        'footer' => [\DigitalBrew\AiryPress\Modules\Login::class, 'renderPreviewLink'],
                    ],
                    [
                        'title' => __('Login options', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'security.login_language',
                                'type' => 'toggle',
                                'label' => __('Hide language switcher on login screen', 'airypress'),
                                'help' => __('Removes the language drop-down below the login form.', 'airypress'),
                            ],
                            [
                                'path' => 'security.login_logo_url',
                                'type' => 'toggle',
                                'label' => __('Login logo links to this site', 'airypress'),
                                'help' => __('Makes the logo on the login screen link to your website instead of wordpress.org, with your site name as its text.', 'airypress'),
                            ],
                        ],
                    ],
                ],
            ],
            'maintenance' => [
                'icon' => 'dashicons-hammer',
                'label' => __('Maintenance', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Maintenance mode', 'airypress'),
                        'desc' => __('Show visitors a holding page while you work on the site. You can preview the page before turning it on.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'maintenance.enabled',
                                'type' => 'toggle',
                                'label' => __('Turn on maintenance mode', 'airypress'),
                                'help' => __('Logged-out visitors (and logged-in users who can\'t edit content, such as customers) see the maintenance page instead of the site. It is sent with a 503 status and a Retry-After header, so search engines come back later instead of dropping your pages. Anyone who can edit posts still sees the site, with a “Maintenance mode” badge in the toolbar. The admin, login screen, REST API and cron keep working.', 'airypress'),
                            ],
                            [
                                'path' => 'maintenance.title',
                                'type' => 'text',
                                'label' => __('Title', 'airypress'),
                                'help' => __('The main heading of the page, also used as the browser tab title.', 'airypress'),
                            ],
                            [
                                'path' => 'maintenance.subtitle',
                                'type' => 'text',
                                'label' => __('Subtitle', 'airypress'),
                                'help' => __('A short line under the title.', 'airypress'),
                            ],
                            [
                                'path' => 'maintenance.body',
                                'type' => 'textarea',
                                'label' => __('Body', 'airypress'),
                                'help' => __('Optional longer text under the subtitle, for example when you expect to be back or how to get in touch. Line breaks are kept and basic HTML such as links is allowed.', 'airypress'),
                            ],
                            [
                                'path' => 'maintenance.background',
                                'type' => 'color',
                                'label' => __('Background colour', 'airypress'),
                                'help' => __('Page background. With a background image it is laid over the image as a tint, which keeps the text readable.', 'airypress'),
                            ],
                            [
                                'path' => 'maintenance.background_image',
                                'type' => 'image',
                                'label' => __('Background image', 'airypress'),
                                'help' => __('Covers the whole page behind the text.', 'airypress'),
                            ],
                            [
                                'path' => 'maintenance.text_color',
                                'type' => 'color',
                                'label' => __('Text colour', 'airypress'),
                                'help' => __('Colour of the title, subtitle and body. Pick one that contrasts with the background.', 'airypress'),
                            ],
                        ],
                        'footer' => [\DigitalBrew\AiryPress\Modules\Maintenance::class, 'renderPreviewLink'],
                    ],
                ],
            ],
            'analytics' => [
                'icon' => 'dashicons-chart-area',
                'label' => __('Analytics', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Google Analytics', 'airypress'),
                        'desc' => __('Show GA4 traffic in a dashboard widget and a live visitor count in the toolbar.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'analytics.enabled',
                                'type' => 'toggle',
                                'label' => __('Enable Google Analytics', 'airypress'),
                                'help' => __('Connects AiryPress to Google Analytics 4 with a service account (see Connection below), so you can see visitor stats inside WordPress.', 'airypress'),
                            ],
                            [
                                'path' => 'analytics.property_id',
                                'type' => 'text',
                                'label' => __('GA4 property ID', 'airypress'),
                                'help' => __('The numeric property ID from Google Analytics → Admin → Property details. Ignored when AIRYPRESS_GA_PROPERTY_ID is set in .env or wp-config.php.', 'airypress'),
                                'depends' => 'analytics.enabled',
                            ],
                            [
                                'path' => 'analytics.toolbar',
                                'type' => 'toggle',
                                'label' => __('Live visitors in the toolbar', 'airypress'),
                                'help' => __('Shows a live “● N online” counter in the admin toolbar (active users in the last 30 minutes), refreshed every minute.', 'airypress'),
                                'depends' => 'analytics.enabled',
                            ],
                            [
                                'path' => 'analytics.toolbar_frontend',
                                'type' => 'toggle',
                                'label' => __('Live visitors in the toolbar on the front end', 'airypress'),
                                'help' => __('Also shows the live counter in the toolbar while browsing the website.', 'airypress'),
                                'depends' => 'analytics.enabled',
                            ],
                            [
                                'path' => 'analytics.roles',
                                'type' => 'checklist',
                                'label' => __('Who can see analytics', 'airypress'),
                                'help' => __('Which roles can see the analytics widget and live counter. Administrators can always see them.', 'airypress'),
                                'options' => [
                                    'administrator' => __('Administrator', 'airypress'),
                                    'editor' => __('Editor', 'airypress'),
                                    'author' => __('Author', 'airypress'),
                                    'shop_manager' => __('Shop manager', 'airypress'),
                                ],
                                'depends' => 'analytics.enabled',
                            ],
                            [
                                'path' => 'analytics.default_range',
                                'type' => 'select',
                                'label' => __('Default date range', 'airypress'),
                                'help' => __('The period the Dashboard widget shows first. You can still switch between 7, 28 and 90 days in the widget.', 'airypress'),
                                'options' => [
                                    '7' => __('Last 7 days', 'airypress'),
                                    '28' => __('Last 28 days', 'airypress'),
                                    '90' => __('Last 90 days', 'airypress'),
                                ],
                                'depends' => 'analytics.enabled',
                            ],
                        ],
                    ],
                    [
                        'title' => __('Connection', 'airypress'),
                        'callback' => [\DigitalBrew\AiryPress\Modules\Integrations\Analytics::class, 'renderConnectionCard'],
                        'pro' => true,
                        'pro_desc' => __('Connect Google Analytics 4 with a service account to get a dashboard widget (visitors, page views, top pages, sources, devices) and a live visitor count in the toolbar.', 'airypress'),
                    ],
                    [
                        'title' => __('Tracking', 'airypress'),
                        'desc' => __('Adds Google\'s and Meta\'s tags to the website. Works on its own: the reporting connection above isn\'t needed for it.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'analytics.tracking.measurement_id',
                                'type' => 'text',
                                'label' => __('GA4 Measurement ID', 'airypress'),
                                'help' => __('The G-… ID from Google Analytics → Admin → Data streams → your web stream. When set, the Google tag (gtag.js) is added to every page of the website and starts sending visits to that property. Leave empty if another plugin (MonsterInsights, Site Kit) or Google Tag Manager already adds it.', 'airypress'),
                            ],
                            [
                                'path' => 'analytics.tracking.exclude_editors',
                                'type' => 'toggle',
                                'label' => __('Don\'t track logged-in editors and admins', 'airypress'),
                                'help' => __('Leaves the tag out for anyone who can edit content, so your own visits don\'t count.', 'airypress'),
                            ],
                            [
                                'path' => 'analytics.tracking.consent_mode',
                                'type' => 'toggle',
                                'label' => __('Wait for cookie consent (Consent Mode)', 'airypress'),
                                'help' => __('Starts Google\'s Consent Mode with analytics and ads storage denied, and holds the Meta Pixel back, so nothing is stored until visitors accept cookies. Cookie banners such as Complianz, Cookiebot or CookieAdmin then grant consent (the Meta Pixel waits for marketing consent). Only turn off if the site has no cookie banner and doesn\'t need one.', 'airypress'),
                            ],
                            [
                                'path' => 'analytics.tracking.verification',
                                'type' => 'text',
                                'label' => __('Search Console verification', 'airypress'),
                                'help' => __('In Google Search Console choose the “HTML tag” method and paste the tag (or just the code in content="…"). It is added to the homepage head, so Search Console can verify the site.', 'airypress'),
                            ],
                            [
                                'path' => 'analytics.tracking.meta_pixel',
                                'type' => 'text',
                                'label' => __('Meta Pixel ID', 'airypress'),
                                'help' => __('The Pixel (dataset) ID from Meta Events Manager → Data sources, a number like 123456789012345. When set, the Meta Pixel is added to every page and sends page views. Uses the two settings above: editors aren\'t tracked, and with cookie consent on it waits for marketing consent. Leave empty if another plugin (Meta for WooCommerce, PixelYourSite) already adds it.', 'airypress'),
                            ],
                        ],
                    ],
                ],
            ],
            'whitelabel' => [
                'icon' => 'dashicons-id-alt',
                'label' => __('White label', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Branding', 'airypress'),
                        'desc' => __('Make the admin look like your agency\'s product rather than WordPress.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'whitelabel.enabled',
                                'type' => 'toggle',
                                'label' => __('White label the admin', 'airypress'),
                                'help' => __('Turns on the branding below.', 'airypress'),
                            ],
                            [
                                'path' => 'whitelabel.brand',
                                'type' => 'text',
                                'label' => __('Brand name', 'airypress'),
                                'help' => __('Replaces “WordPress” in the browser tab title of admin pages (e.g. “Posts ‹ My Site — Acme”). Leave empty to keep it.', 'airypress'),
                                'depends' => 'whitelabel.enabled',
                            ],
                            [
                                'path' => 'whitelabel.logo',
                                'type' => 'image',
                                'label' => __('Sidebar logo (dark)', 'airypress'),
                                'help' => __('Dark artwork for the Light theme\'s light sidebar, and for every theme when there is no light version. A wide logo on a transparent background works best; it is scaled to the sidebar\'s width.', 'airypress'),
                                'depends' => 'whitelabel.enabled',
                            ],
                            [
                                'path' => 'whitelabel.logo_light',
                                'type' => 'image',
                                'label' => __('Sidebar logo (light)', 'airypress'),
                                'help' => __('Light or white artwork for the dark sidebar of the Default and Modern themes (and when the admin theme is off). Optional: without it the dark version is used everywhere.', 'airypress'),
                                // Light artwork disappears on the light checkerboard.
                                'dark_preview' => true,
                                'depends' => 'whitelabel.enabled',
                            ],
                            [
                                'path' => 'whitelabel.logo_url',
                                'type' => 'text',
                                'label' => __('Sidebar logo link', 'airypress'),
                                'help' => __('Where the logo links to, always in a new tab. Leave empty to link to the Dashboard.', 'airypress'),
                                'depends' => 'whitelabel.enabled',
                            ],
                            [
                                'path' => 'whitelabel.logo_position',
                                'type' => 'select',
                                'label' => __('Sidebar logo position', 'airypress'),
                                'help' => __('Top: above the first menu item, next to the collapse button. Bottom: the bottom of the sidebar, fixed in place while the menu scrolls.', 'airypress'),
                                'options' => [
                                    'top' => __('Top of the sidebar', 'airypress'),
                                    'bottom' => __('Bottom of the sidebar', 'airypress'),
                                ],
                                'depends' => 'whitelabel.enabled',
                            ],
                            [
                                'path' => 'whitelabel.logo_size',
                                'type' => 'range',
                                'label' => __('Sidebar logo size', 'airypress'),
                                'help' => __('The logo\'s height in pixels; its width follows. The logo in the sidebar changes as you drag (save to keep it).', 'airypress'),
                                'min' => 20,
                                'max' => 80,
                                'step' => 2,
                                'unit' => 'px',
                                // Previews the size on the sidebar logo while dragging.
                                'live_var' => '--airy-brand-size',
                                'depends' => 'whitelabel.enabled',
                            ],
                            [
                                'path' => 'whitelabel.hide_plugin',
                                'type' => 'toggle',
                                'label' => __('Hide AiryPress from other administrators', 'airypress'),
                                'help' => __('Removes AiryPress from the Plugins screen for administrators who aren\'t allowed to change its settings (see Settings access), so it can\'t be turned off by mistake.', 'airypress'),
                                'depends' => 'whitelabel.enabled',
                            ],
                        ],
                    ],
                    [
                        'title' => __('Settings access', 'airypress'),
                        'desc' => __('Hand the site over without handing over the controls.', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'access.users',
                                'type' => 'keys',
                                'source' => [self::class, 'adminOptions'],
                                'columns' => 1,
                                'label' => __('Who can change AiryPress', 'airypress'),
                                'help' => __('Only these administrators see Settings → AiryPress, the menu builder and the Requests menu; everyone else keeps the tidied admin but can\'t change it. Tick none to let every administrator in. You are always kept in the list, so you can\'t lock yourself out.', 'airypress'),
                            ],
                        ],
                    ],
                ],
            ],
            'site' => [
                'icon' => 'dashicons-id',
                'label' => __('Site identity', 'airypress'),
                'cards' => [
                    [
                        'title' => __('Favicon', 'airypress'),
                        'fields' => [
                            [
                                'path' => 'site.favicon',
                                'type' => 'image',
                                'name' => \DigitalBrew\AiryPress\Modules\Front\Favicon::FIELD,
                                'value' => [\DigitalBrew\AiryPress\Modules\Front\Favicon::class, 'current'],
                                'label' => __('Favicon', 'airypress'),
                                'help' => __('The icon shown in browser tabs, bookmarks and on phone home screens, on the website, in the admin and on the login screen. This is WordPress\' own Site Icon, the same one as in Appearance → Customize → Site Identity: changing it here changes it there too. Use a square image of at least 512 × 512 px.', 'airypress'),
                            ],
                        ],
                    ],
                    [
                        'title' => __('Open Graph & social', 'airypress'),
                        'desc' => __('Controls how pages look when shared on Facebook, LinkedIn, X and in messaging apps (Open Graph and X card tags).', 'airypress'),
                        'callback_before' => [\DigitalBrew\AiryPress\Settings\Schema::class, 'renderSocialNotice'],
                        'fields' => [
                            [
                                'path' => 'social.enabled',
                                'type' => 'toggle',
                                'label' => __('Add Open Graph and X card tags', 'airypress'),
                                'help' => __('Adds og:title, og:description, og:image, og:url and the matching twitter: tags to every page. Skipped automatically while an SEO plugin that adds its own (Yoast SEO, SEOPress, Rank Math, All in One SEO) is active.', 'airypress'),
                            ],
                            [
                                'path' => 'social.per_page',
                                'type' => 'toggle',
                                'label' => __('Per-page share details', 'airypress'),
                                'help' => __('Adds a “Social sharing” box to the editor sidebar of every page, post and custom post type, for its own share title, description and image. Off: every page uses its title, excerpt and featured image.', 'airypress'),
                                'depends' => 'social.enabled',
                            ],
                            [
                                'path' => 'social.default_image',
                                'type' => 'image',
                                'label' => __('Default share image', 'airypress'),
                                'help' => __('Used for pages without their own share image or featured image, and for the homepage and archives. 1200 × 630 px works best.', 'airypress'),
                                'depends' => 'social.enabled',
                            ],
                            [
                                'path' => 'social.home_title',
                                'type' => 'text',
                                'label' => __('Homepage title', 'airypress'),
                                'help' => __('Title when the homepage is shared. Empty: the site name (or the front page\'s own Social sharing title).', 'airypress'),
                                'depends' => 'social.enabled',
                            ],
                            [
                                'path' => 'social.home_description',
                                'type' => 'textarea',
                                'label' => __('Homepage description', 'airypress'),
                                'help' => __('Description when the homepage is shared. Empty: the site tagline (or the front page\'s own Social sharing description).', 'airypress'),
                                'depends' => 'social.enabled',
                            ],
                            [
                                'path' => 'social.twitter_card',
                                'type' => 'select',
                                'label' => __('X card style', 'airypress'),
                                'help' => __('How links show on X: a large image above the title, or a small square image beside it.', 'airypress'),
                                'options' => [
                                    'summary_large_image' => __('Large image', 'airypress'),
                                    'summary' => __('Small image', 'airypress'),
                                ],
                                'depends' => 'social.enabled',
                            ],
                            [
                                'path' => 'social.twitter_site',
                                'type' => 'text',
                                'label' => __('X (Twitter) username', 'airypress'),
                                'help' => __('The site\'s @username, credited on shared cards. Optional.', 'airypress'),
                                'depends' => 'social.enabled',
                            ],
                            [
                                'path' => 'social.facebook_app_id',
                                'type' => 'text',
                                'label' => __('Facebook App ID', 'airypress'),
                                'help' => __('Only needed for Facebook Insights on shared links. Optional.', 'airypress'),
                                'depends' => 'social.enabled',
                            ],
                        ],
                    ],
                ],
            ],
        ];
    }

    /**
     * Card notice: AiryPress's social tags are skipped while an SEO plugin adds its own.
     */
    public static function renderSocialNotice(): void
    {
        $class = \DigitalBrew\AiryPress\Modules\Front\SocialMeta::class;
        $plugin = class_exists($class) ? $class::seoPlugin() : null;

        if ($plugin !== null) {
            printf(
                '<div class="notice notice-warning inline"><p>%s</p></div>',
                esc_html(sprintf(
                    /* translators: %1$s: SEO plugin name. */
                    __('%1$s is active and adds its own social tags, so AiryPress doesn\'t add any (they would be duplicated). Edit them in %1$s instead.', 'airypress'),
                    $plugin
                ))
            );
        }
    }

    /**
     * Roles, for `keys` fields.
     *
     * @return array<string, array{label: string, plugin: string, active: bool}>
     */
    public static function roleOptions(): array
    {
        $options = [];

        foreach (wp_roles()->get_names() as $role => $name) {
            $options[(string) $role] = ['label' => translate_user_role((string) $name), 'plugin' => '', 'active' => true];
        }

        return $options;
    }

    /**
     * Administrators (user ID => name), for `keys` fields.
     *
     * @return array<string, array{label: string, plugin: string, active: bool}>
     */
    public static function adminOptions(): array
    {
        $options = [];
        $users = get_users(['capability' => 'manage_options', 'fields' => ['ID', 'display_name', 'user_email'], 'number' => 100, 'orderby' => 'ID', 'order' => 'ASC']);

        foreach ($users as $user) {
            $options[(string) $user->ID] = [
                'label' => $user->display_name . ' (' . $user->user_email . ')',
                'plugin' => '',
                'active' => true,
            ];
        }

        return $options;
    }

    /**
     * A web address or a mailto:/tel: link.
     */
    public static function sanitizeLink(mixed $value): string
    {
        return esc_url_raw(trim(is_string($value) ? $value : ''), ['http', 'https', 'mailto', 'tel']);
    }

    /**
     * "Label | address" lines; lines without a valid address are dropped.
     */
    public static function sanitizeLinks(mixed $value): string
    {
        $lines = [];

        foreach (preg_split('/\R/', is_string($value) ? $value : '') ?: [] as $line) {
            [$label, $url] = array_pad(array_map('trim', explode('|', $line, 2)), 2, '');
            $url = self::sanitizeLink($url);

            if ($label !== '' && $url !== '') {
                $lines[] = sanitize_text_field($label) . ' | ' . $url;
            }
        }

        return implode("\n", $lines);
    }

    /**
     * Parsed "Label | address" lines.
     *
     * @return array<int, array{label: string, url: string}>
     */
    public static function links(string $value): array
    {
        $links = [];

        foreach (preg_split('/\R/', $value) ?: [] as $line) {
            [$label, $url] = array_pad(array_map('trim', explode('|', $line, 2)), 2, '');

            if ($label !== '' && $url !== '') {
                $links[] = ['label' => $label, 'url' => $url];
            }
        }

        return $links;
    }

    /**
     * Only Slack incoming-webhook and workflow URLs.
     */
    public static function sanitizeWebhook(mixed $value): string
    {
        $url = trim(is_string($value) ? $value : '');

        return preg_match('~^https://hooks\.slack\.com/(services|workflows|triggers)/[A-Za-z0-9/_-]+$~', $url) === 1 ? $url : '';
    }

    public static function sanitizeEmail(mixed $value): string
    {
        return sanitize_email(trim(is_string($value) ? $value : ''));
    }

    public static function sanitizeHandle(mixed $value): string
    {
        $handle = ltrim(trim(is_string($value) ? $value : ''), '@');

        return preg_match('/^[A-Za-z0-9_]{1,15}$/', $handle) === 1 ? '@' . $handle : '';
    }

    public static function sanitizeDigits(mixed $value): string
    {
        $digits = trim(is_string($value) ? $value : '');

        return preg_match('/^\d{5,25}$/', $digits) === 1 ? $digits : '';
    }
}
