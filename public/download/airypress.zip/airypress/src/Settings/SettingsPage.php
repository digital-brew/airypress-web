<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Settings;

use DigitalBrew\AiryPress\Licensing\Licensing;
use DigitalBrew\AiryPress\Licensing\Pro;
use DigitalBrew\AiryPress\Menu\MenuStore;
use DigitalBrew\AiryPress\Modules\Admin\Menu;

/**
 * Renders the Settings → AiryPress screen and handles import/reset.
 */
final class SettingsPage
{
    /** First time the settings page was opened (for the review request). */
    public const INSTALLED_OPTION = 'airypress_installed';

    /** Set once a user answered the review request. */
    private const REVIEW_META = 'airypress_review_asked';

    private const REVIEW_URL = 'https://wordpress.org/support/plugin/airypress/reviews/#new-post';

    private Settings $settings;

    public function __construct(Settings $settings)
    {
        $this->settings = $settings;
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'addPage']);
        add_action('admin_init', [$this, 'registerSettings']);
        add_action('admin_post_airypress_import', [$this, 'importSettings']);
        add_action('admin_post_airypress_reset', [$this, 'resetSettings']);
        add_action('admin_post_airypress_review', [$this, 'review']);
        add_filter('script_loader_tag', [$this, 'moduleTag'], 10, 3);
        add_filter('plugin_action_links_' . plugin_basename(AIRYPRESS_FILE), [$this, 'actionLinks']);
    }

    public function addPage(): void
    {
        $hook = add_options_page(
            __('AiryPress', 'airypress'),
            __('AiryPress', 'airypress'),
            'manage_options',
            'airypress',
            [$this, 'render']
        );

        if (is_string($hook)) {
            add_action('load-' . $hook, [$this, 'onLoad']);
        }
    }

    public function onLoad(): void
    {
        // When AiryPress was first used, for the review request.
        add_option(self::INSTALLED_OPTION, time(), '', false);

        add_filter('admin_body_class', [$this, 'bodyClass']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('admin_notices', [$this, 'maybeShowImportError']);
    }

    public function registerSettings(): void
    {
        register_setting('airypress', Settings::OPTION, [
            'type' => 'array',
            'sanitize_callback' => [Settings::class, 'sanitize'],
            'default' => [],
        ]);
    }

    public function bodyClass(string $classes): string
    {
        return $classes . ' airy-settings';
    }

    public function enqueue(): void
    {
        // Media library modal for image fields.
        wp_enqueue_media();

        if (file_exists(AIRYPRESS_DIR . 'dist/settings.css')) {
            wp_enqueue_style(
                'airypress-settings',
                AIRYPRESS_URL . 'dist/settings.css',
                [],
                $this->version('dist/settings.css')
            );
        }

        if ($this->menuBuilderAvailable()) {
            wp_enqueue_style('airypress-menu-builder', AIRYPRESS_URL . 'dist/menu-builder.css', ['dashicons'], $this->version('dist/menu-builder.css'));
            wp_enqueue_script('airypress-menu-builder', AIRYPRESS_URL . 'dist/menu-builder.js', [], $this->version('dist/menu-builder.js'), ['in_footer' => true, 'strategy' => 'defer']);
        }

        if (file_exists(AIRYPRESS_DIR . 'dist/settings.js')) {
            wp_enqueue_script(
                'airypress-settings',
                AIRYPRESS_URL . 'dist/settings.js',
                [],
                $this->version('dist/settings.js'),
                [
                    'in_footer' => true,
                    'strategy' => 'defer',
                ]
            );
        }
    }

    /**
     * @param string $tag
     * @param string $handle
     * @param string $src
     */
    public function moduleTag($tag, $handle, $src): string
    {
        if ($handle !== 'airypress-settings' && $handle !== 'airypress-menu-builder') {
            return $tag;
        }

        $tag = preg_replace('/\stype=([\'"])[^\'"]*\1/', '', $tag) ?? $tag;

        return str_replace('<script ', '<script type="module" ', $tag);
    }

    /**
     * @param array<int, string> $links
     *
     * @return array<int, string>
     */
    public function actionLinks(array $links): array
    {
        $url = admin_url('options-general.php?page=airypress');
        array_unshift($links, '<a href="' . esc_url($url) . '">' . esc_html__('Settings', 'airypress') . '</a>');

        return $links;
    }

    public function maybeShowImportError(): void
    {
        $error = isset($_GET['airy-error']) ? sanitize_key(wp_unslash((string) $_GET['airy-error'])) : '';

        if ($error === 'import') {
            echo '<div class="notice notice-error is-dismissible"><p>'
                . esc_html__('The import could not be read. Please paste valid AiryPress JSON.', 'airypress')
                . '</p></div>';
        }
    }

    public function render(): void
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $sections = Schema::sections();
        $about = new About($this->settings);
        ?>
        <div class="wrap airy-settings-page">
            <header class="airy-settings-header">
                <h1><?php esc_html_e('AiryPress', 'airypress'); ?></h1>
                <p class="airy-settings-version">v<?php echo esc_html(AIRYPRESS_VERSION); ?></p>
            </header>
            <?php // Core moves admin notices after .wp-header-end instead of into our flex header. ?>
            <hr class="wp-header-end">
            <div class="airy-settings-layout">
            <nav class="airy-tabs" role="tablist" aria-orientation="vertical">
                <?php $isFirst = true; ?>
                <?php foreach ($sections as $key => $section) : ?>
                    <a class="airy-tab<?php echo $isFirst ? ' is-active' : ''; ?>"
                        href="#<?php echo esc_attr((string) $key); ?>"
                        role="tab"
                        aria-selected="<?php echo $isFirst ? 'true' : 'false'; ?>"
                        data-tab="<?php echo esc_attr((string) $key); ?>"><?php $this->tabIcon((string) ($section['icon'] ?? '')); ?><?php echo esc_html((string) $section['label']); ?></a>
                    <?php if ($isFirst) : ?>
                        <a class="airy-tab" href="#menu-builder" role="tab" aria-selected="false" data-tab="menu-builder"><?php $this->tabIcon('dashicons-menu-alt'); ?><?php esc_html_e('Menu builder', 'airypress'); ?><?php echo $this->menuBuilderAvailable() ? '' : ' <span class="airy-pro-tag">Pro</span>'; ?></a>
                    <?php endif; ?>
                    <?php $isFirst = false; ?>
                <?php endforeach; ?>
                <a class="airy-tab" href="#tools" role="tab" aria-selected="false" data-tab="tools"><?php $this->tabIcon('dashicons-admin-tools'); ?><?php esc_html_e('Tools', 'airypress'); ?></a>
                <?php if ($about->visible()) : ?>
                    <a class="airy-tab" href="#about" role="tab" aria-selected="false" data-tab="about"><?php $this->tabIcon('dashicons-info-outline'); ?><?php esc_html_e('About', 'airypress'); ?></a>
                <?php endif; ?>
            </nav>
            <div class="airy-settings-main">
            <form method="post" action="options.php" class="airy-settings-form">
                <?php settings_fields('airypress'); ?>
                <?php $isFirst = true; ?>
                <?php foreach ($sections as $key => $section) : ?>
                    <section class="airy-panel<?php echo $isFirst ? ' is-active' : ''; ?>"
                        id="airy-panel-<?php echo esc_attr((string) $key); ?>"
                        role="tabpanel"
                        data-tab="<?php echo esc_attr((string) $key); ?>">
                        <?php $isFirst = false; ?>
                        <?php $about->tabLink((string) $key); ?>
                        <?php foreach ($section['cards'] as $card) : ?>
                            <?php if (! $this->cardVisible($card)) {
                                continue;
                            } ?>
                            <?php $locked = $this->cardLocked($card); ?>
                            <div class="airy-card<?php echo $locked ? ' is-pro-locked' : ''; ?>">
                                <h2 class="airy-card-title"><?php echo esc_html((string) $card['title']); ?><?php echo $locked ? wp_kses_post(Pro::pill()) : ''; ?></h2>
                                <?php if (! empty($card['desc'])) : ?>
                                    <p class="airy-card-desc"><?php echo esc_html((string) $card['desc']); ?></p>
                                <?php endif; ?>
                                <?php if (isset($card['callback_before']) && is_callable($card['callback_before'])) {
                                    call_user_func($card['callback_before']);
                                } ?>
                                <?php if (isset($card['callback'])) {
                                    if ($locked) {
                                        $this->renderProTeaser((string) ($card['pro_desc'] ?? ''));
                                    } elseif (is_callable($card['callback'])) {
                                        call_user_func($card['callback']);
                                    }
                                    echo '</div>';
                                    continue;
                                } ?>
                                <?php foreach ($card['fields'] as $field) {
                                    $this->renderField($field, $locked);
                                } ?>
                                <?php if (! $locked && isset($card['footer']) && is_callable($card['footer'])) : ?>
                                    <div class="airy-card-footer"><?php call_user_func($card['footer']); ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </section>
                <?php endforeach; ?>
                <footer class="airy-settings-footer">
                    <?php $this->renderReviewLink(); ?>
                    <button type="submit" class="button button-primary"><?php esc_html_e('Save changes', 'airypress'); ?></button>
                </footer>
            </form>
            <?php $this->renderMenuBuilder($about); ?>
            <?php $this->renderTools($about); ?>
            <?php $about->render($sections, fn () => $this->renderProCard()); ?>
            </div>
            </div>
        </div>
        <?php
    }

    private function tabIcon(string $icon): void
    {
        if ($icon !== '') {
            echo '<span class="dashicons ' . esc_attr($icon) . '" aria-hidden="true"></span>';
        }
    }

    /**
     * @param array<string, mixed> $card
     */
    private function cardVisible(array $card): bool
    {
        $condition = $card['condition'] ?? null;

        return match ($condition) {
            'multisite' => is_multisite(),
            'woocommerce' => class_exists('WooCommerce'),
            'not_agency' => ! Licensing::agency(),
            default => true,
        };
    }

    /**
     * A Pro card without Pro: flagged `pro`, or every field is a Pro setting.
     *
     * @param array<string, mixed> $card
     */
    private function cardLocked(array $card): bool
    {
        if (Pro::active()) {
            return false;
        }

        if (! empty($card['pro'])) {
            return true;
        }

        $paths = array_map(static fn (array $field): string => (string) $field['path'], (array) ($card['fields'] ?? []));

        return $paths !== [] && count(array_filter($paths, [Pro::class, 'locked'])) === count($paths);
    }

    /**
     * Stands in for a Pro card's own content.
     */
    private function renderProTeaser(string $text): void
    {
        printf(
            '<div class="airy-pro-teaser"><p>%s</p><a class="button" href="%s" target="_blank" rel="noopener">%s</a></div>',
            esc_html($text !== '' ? $text : __('This is part of AiryPress Pro.', 'airypress')),
            esc_url(Licensing::PRO_URL),
            esc_html__('See what Pro adds', 'airypress')
        );
    }

    private function menuBuilderAvailable(): bool
    {
        return Pro::active() && class_exists(Menu::class) && file_exists(AIRYPRESS_DIR . 'dist/menu-builder.js');
    }

    /**
     * @param array<string, mixed> $field
     */
    private function renderField(array $field, bool $cardLocked = false): void
    {
        $path = (string) $field['path'];
        $type = (string) $field['type'];
        // A field can read its value elsewhere and post under its own name
        // (e.g. the favicon, which is WordPress' own Site Icon option).
        $value = isset($field['value']) && is_callable($field['value'])
            ? call_user_func($field['value'])
            : $this->settings->saved($path);
        $id = $this->fieldId($path);
        $name = isset($field['name']) ? (string) $field['name'] : $this->fieldName($path);

        // Locked Pro fields are disabled, so nothing of theirs is posted.
        $locked = $cardLocked || Pro::locked($path);

        echo '<div class="airy-field airy-field--' . esc_attr($type) . ($locked ? ' is-pro-locked' : '') . '"'
            . (isset($field['depends']) ? ' data-depends="' . esc_attr((string) $field['depends']) . '"' : '') . '>';
        echo '<div class="airy-field-text">';
        echo '<label class="airy-field-label" for="' . esc_attr($id) . '">' . esc_html((string) $field['label'])
            . ($locked && ! $cardLocked ? wp_kses_post(Pro::pill()) : '') . '</label>';
        if (! empty($field['help'])) {
            echo '<p class="airy-field-help">' . esc_html((string) $field['help']) . '</p>';
        }
        echo '</div>';
        echo $locked ? '<fieldset class="airy-field-control" disabled>' : '<div class="airy-field-control">';
        $this->renderControl($field, $value, $id, $name);
        echo $locked ? '</fieldset>' : '</div>';
        echo '</div>';
    }

    /**
     * @param array<string, mixed> $field
     */
    private function renderControl(array $field, mixed $value, string $id, string $name): void
    {
        switch ((string) $field['type']) {
            case 'toggle':
                printf('<input type="hidden" name="%s" value="0">', esc_attr($name));
                printf(
                    '<input type="checkbox" class="airy-switch" role="switch" id="%s" name="%s" value="1" data-path="%s" %s>',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr((string) $field['path']),
                    checked((bool) $value, true, false)
                );
                break;

            case 'color':
                printf(
                    '<input type="color" class="airy-color" id="%s" name="%s" value="%s">',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr((string) $value)
                );
                printf(
                    '<input type="text" class="airy-color-text" pattern="#[0-9a-fA-F]{6}" value="%s" data-color-for="%s" aria-label="%s">',
                    esc_attr((string) $value),
                    esc_attr($id),
                    esc_attr((string) $field['label'])
                );
                break;

            case 'textarea':
                printf(
                    '<textarea id="%s" name="%s" rows="4" class="large-text">%s</textarea>',
                    esc_attr($id),
                    esc_attr($name),
                    esc_textarea((string) $value)
                );
                break;

            case 'range':
                printf(
                    '<input type="range" class="airy-range" id="%1$s" name="%2$s" value="%3$s" min="%4$s" max="%5$s" step="%6$s" data-unit="%7$s" data-live-var="%8$s"><output class="airy-range-value" for="%1$s" data-unit="%7$s">%3$s%7$s</output>',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr((string) (int) $value),
                    esc_attr((string) (int) ($field['min'] ?? 0)),
                    esc_attr((string) (int) ($field['max'] ?? 100)),
                    esc_attr((string) (int) ($field['step'] ?? 1)),
                    esc_attr((string) ($field['unit'] ?? '')),
                    esc_attr((string) ($field['live_var'] ?? ''))
                );
                break;

            case 'select':
                printf('<select id="%s" name="%s">', esc_attr($id), esc_attr($name));
                foreach ((array) $field['options'] as $optionValue => $optionLabel) {
                    printf(
                        '<option value="%s" %s>%s</option>',
                        esc_attr((string) $optionValue),
                        selected((string) $value, (string) $optionValue, false),
                        esc_html((string) $optionLabel)
                    );
                }
                echo '</select>';
                break;

            case 'image':
                $imageId = is_numeric($value) ? (int) $value : 0;
                $url = $imageId > 0 ? wp_get_attachment_image_url($imageId, 'medium') : false;
                echo '<div class="airy-image">';
                printf('<input type="hidden" id="%s" name="%s" value="%s">', esc_attr($id), esc_attr($name), esc_attr($imageId > 0 ? (string) $imageId : ''));
                printf(
                    '<span class="airy-image-preview%s"%s>%s</span>',
                    ! empty($field['dark_preview']) ? ' is-dark' : '',
                    $url ? '' : ' hidden',
                    $url ? '<img src="' . esc_url($url) . '" alt="">' : ''
                );
                printf(
                    '<button type="button" class="button" data-airy-image-choose data-title="%s" data-button="%s">%s</button>',
                    esc_attr((string) $field['label']),
                    esc_attr__('Use this image', 'airypress'),
                    esc_html__('Choose image', 'airypress')
                );
                printf(
                    '<button type="button" class="button-link button-link-delete" data-airy-image-remove%s>%s</button>',
                    $url ? '' : ' hidden',
                    esc_html__('Remove', 'airypress')
                );
                echo '</div>';
                break;

            case 'keys':
                // Checklist of plugin items (toolbar nodes, dashboard widgets):
                // the field's 'source' lists known items of active plugins and
                // items recorded at runtime; anything already ticked is added.
                $values = is_array($value) ? array_map('strval', $value) : [];
                // '*' (a default) means every item stays: tick them all and post
                // '*' back, so saving another setting keeps it. settings.js
                // drops the marker as soon as a box in this list is unticked.
                $all = in_array('*', $values, true);
                $values = array_values(array_diff($values, ['*']));
                $options = isset($field['source']) && is_callable($field['source']) ? (array) call_user_func($field['source']) : [];
                foreach ($values as $kept) {
                    $options[$kept] ??= ['label' => $kept, 'plugin' => '', 'active' => true];
                }
                // 'columns' => 1 for lists of long entries (people, notices).
                $single = (int) ($field['columns'] ?? 2) === 1 ? ' airy-checklist--single' : '';
                echo '<fieldset class="' . esc_attr('airy-checklist airy-checklist--nodes' . $single) . '">';
                printf('<input type="hidden" name="%s[]" value="">', esc_attr($name));
                if ($all) {
                    printf('<input type="hidden" name="%s[]" value="*" data-airy-keep-all>', esc_attr($name));
                }
                foreach ($options as $optionValue => $option) {
                    printf(
                        '<label class="airy-check%s"%s><input type="checkbox" name="%s[]" value="%s" %s> <span class="airy-check-text"><span>%s%s</span><code>%s</code></span></label>',
                        $option['active'] ? '' : ' is-inactive',
                        $option['active'] ? '' : ' title="' . esc_attr__('This plugin is not active.', 'airypress') . '"',
                        esc_attr($name),
                        esc_attr((string) $optionValue),
                        checked($all || in_array((string) $optionValue, $values, true), true, false),
                        $option['plugin'] !== '' ? '<strong>' . esc_html($option['plugin']) . '</strong> · ' : '',
                        esc_html($option['label']),
                        esc_html((string) $optionValue)
                    );
                }
                echo '</fieldset>';
                break;

            case 'checklist':
                $values = is_array($value) ? array_map('strval', $value) : [];
                echo '<fieldset class="airy-checklist">';
                printf('<input type="hidden" name="%s[]" value="">', esc_attr($name));
                foreach ((array) $field['options'] as $optionValue => $optionLabel) {
                    printf(
                        '<label class="airy-check"><input type="checkbox" name="%s[]" value="%s" %s> %s</label>',
                        esc_attr($name),
                        esc_attr((string) $optionValue),
                        checked(in_array((string) $optionValue, $values, true), true, false),
                        esc_html((string) $optionLabel)
                    );
                }
                echo '</fieldset>';
                break;

            default:
                printf(
                    '<input type="text" class="regular-text" id="%s" name="%s" value="%s">',
                    esc_attr($id),
                    esc_attr($name),
                    esc_attr((string) $value)
                );
                break;
        }
    }

    private function renderMenuBuilder(About $about): void
    {
        if (! $this->menuBuilderAvailable()) {
            ?>
            <section class="airy-panel" id="airy-panel-menu-builder" role="tabpanel" data-tab="menu-builder" data-standalone>
                <?php $about->tabLink('menu-builder'); ?>
                <div class="airy-card is-pro-locked">
                    <h2 class="airy-card-title"><?php esc_html_e('Menu builder', 'airypress'); ?><?php echo wp_kses_post(Pro::pill()); ?></h2>
                    <?php $this->renderProTeaser(__('Drag and drop the admin menu: reorder items, move them under another parent (up to four levels), rename them, change icons, add your own links, headings and separators, and hide items for everyone or for chosen roles.', 'airypress')); ?>
                </div>
            </section>
            <?php
            return;
        }

        $data = Menu::builderData();
        ?>
        <section class="airy-panel" id="airy-panel-menu-builder" role="tabpanel" data-tab="menu-builder" data-standalone>
            <?php $about->tabLink('menu-builder'); ?>
            <div class="airy-card airy-mb-card">
                <h2 class="airy-card-title"><?php esc_html_e('Menu builder', 'airypress'); ?></h2>
                <p class="airy-card-desc"><?php esc_html_e('Drag items to reorder them or move them under another parent (up to four levels). Rename items, change icons, add your own links, labels and separators, and hide items for everyone or for specific roles. Hidden items only disappear from the menu; their pages still open by URL.', 'airypress'); ?></p>
                <div id="airy-menu-builder" class="airy-mb" aria-live="polite">
                    <p class="airy-mb-loading"><?php esc_html_e('Loading the menu builder…', 'airypress'); ?></p>
                </div>
                <noscript><p><?php esc_html_e('The menu builder needs JavaScript.', 'airypress'); ?></p></noscript>
            </div>
            <script type="application/json" id="airy-menu-builder-data"><?php
                echo wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            ?></script>
        </section>
        <?php
    }

    private function renderTools(About $about): void
    {
        $export = $this->settings->stored();

        if (class_exists(MenuStore::class)) {
            $export['menu'] = MenuStore::get();
        }

        $json = (string) wp_json_encode(
            $export,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );
        $action = admin_url('admin-post.php');
        ?>
        <section class="airy-panel" id="airy-panel-tools" role="tabpanel" data-tab="tools" data-standalone>
            <?php $about->tabLink('tools'); ?>
            <?php // Without the About tab (white label), the Pro card stays here. ?>
            <?php if (! $about->visible()) {
                $this->renderProCard();
            } ?>
            <div class="airy-card airy-tools">
                <h2 class="airy-card-title"><?php esc_html_e('Tools', 'airypress'); ?></h2>
                <p class="airy-card-desc"><?php esc_html_e('Export, import or reset all AiryPress settings.', 'airypress'); ?></p>
                <div class="airy-field airy-field--textarea">
                    <div class="airy-field-text">
                        <label class="airy-field-label" for="airy-export"><?php esc_html_e('Export all AiryPress settings', 'airypress'); ?></label>
                        <p class="airy-field-help"><?php esc_html_e('Copy this JSON to back up all AiryPress settings.', 'airypress'); ?></p>
                    </div>
                    <div class="airy-field-control">
                        <textarea id="airy-export" class="large-text code" rows="10" readonly><?php echo esc_textarea($json); ?></textarea>
                        <?php $filename = 'airypress-' . sanitize_title((string) wp_parse_url(home_url(), PHP_URL_HOST)) . '-' . wp_date('Y-m-d') . '.json'; ?>
                        <div class="airy-tools-download">
                            <button type="button" class="button airy-download" data-target="airy-export" data-filename="<?php echo esc_attr($filename); ?>">
                                <span class="dashicons dashicons-download" aria-hidden="true"></span><?php esc_html_e('Export to JSON', 'airypress'); ?>
                            </button>
                        </div>
                        <div class="airy-tools-actions">
                            <button type="button" class="button airy-copy" data-target="airy-export" data-done="<?php esc_attr_e('Copied', 'airypress'); ?>">
                                <span class="dashicons dashicons-clipboard" aria-hidden="true"></span><?php esc_html_e('Copy', 'airypress'); ?>
                            </button>
                        </div>
                    </div>
                </div>
                <form method="post" action="<?php echo esc_url($action); ?>" class="airy-tools-form">
                    <?php wp_nonce_field('airypress_import'); ?>
                    <input type="hidden" name="action" value="airypress_import">
                    <div class="airy-field airy-field--textarea">
                        <div class="airy-field-text">
                            <label class="airy-field-label" for="airy-import"><?php esc_html_e('Import all AiryPress settings', 'airypress'); ?></label>
                            <p class="airy-field-help"><?php esc_html_e('Paste exported JSON and replace all current AiryPress settings.', 'airypress'); ?></p>
                        </div>
                        <div class="airy-field-control">
                            <textarea id="airy-import" name="airypress_import" class="large-text code" rows="10"></textarea>
                            <div class="airy-tools-actions">
                                <button type="button" class="button airy-paste" data-target="airy-import" data-done="<?php esc_attr_e('Pasted', 'airypress'); ?>" data-denied="<?php esc_attr_e('Clipboard not available: paste with Ctrl+V', 'airypress'); ?>">
                                    <span class="dashicons dashicons-editor-paste-text" aria-hidden="true"></span><?php esc_html_e('Paste', 'airypress'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="airy-tools-footer">
                        <div class="airy-tools-footer-start">
                            <button type="submit" class="button"><?php esc_html_e('Import settings', 'airypress'); ?></button>
                            <input type="file" id="airy-import-file" accept=".json,application/json" hidden>
                            <button type="button" class="button airy-upload" data-target="airy-import" data-file="airy-import-file" data-done="<?php esc_attr_e('Loaded — now click Import settings', 'airypress'); ?>" data-invalid="<?php esc_attr_e('That file isn\'t valid JSON', 'airypress'); ?>">
                                <span class="dashicons dashicons-upload" aria-hidden="true"></span><?php esc_html_e('Import from JSON', 'airypress'); ?>
                            </button>
                        </div>
                        <?php // Submits the reset form below (forms can't be nested). ?>
                        <button type="submit" form="airy-reset-form" class="button-link button-link-delete airy-reset-link" data-confirm="<?php esc_attr_e('Reset all AiryPress settings, including the menu layout, to their defaults? This cannot be undone.', 'airypress'); ?>"><?php esc_html_e('Reset all settings to defaults', 'airypress'); ?></button>
                    </div>
                </form>
                <form method="post" action="<?php echo esc_url($action); ?>" id="airy-reset-form" hidden>
                    <?php wp_nonce_field('airypress_reset'); ?>
                    <input type="hidden" name="action" value="airypress_reset">
                </form>
            </div>
        </section>
        <?php
    }

    /**
     * One "AiryPress Pro" card on the About tab, without Pro.
     */
    private function renderProCard(): void
    {
        if (Pro::active()) {
            return;
        }

        $features = [
            __('Modern and Light themes with a per-user theme switch', 'airypress'),
            __('Drag-and-drop admin menu builder', 'airypress'),
            __('Hide toolbar items and dashboard widgets added by plugins', 'airypress'),
            __('Post type columns: order, hide, sort, ACF fields', 'airypress'),
            __('GA4 dashboard widget and live visitors', 'airypress'),
            __('Admin notice manager, white label and settings lock', 'airypress'),
            __('Open Graph & X cards, login and maintenance background images', 'airypress'),
        ];
        ?>
        <div class="airy-card airy-pro-card">
            <h2 class="airy-card-title"><?php esc_html_e('AiryPress Pro', 'airypress'); ?></h2>
            <p class="airy-card-desc"><?php esc_html_e('Everything agencies need to hand over a tidy, branded admin.', 'airypress'); ?></p>
            <ul class="airy-pro-list">
                <?php foreach ($features as $feature) : ?>
                    <li><?php echo esc_html($feature); ?></li>
                <?php endforeach; ?>
            </ul>
            <p class="airy-pro-actions">
                <a class="button button-primary" href="<?php echo esc_url(Pro::upgradeUrl()); ?>"><?php esc_html_e('Get AiryPress Pro', 'airypress'); ?></a>
                <a class="button" href="<?php echo esc_url(Licensing::PRO_URL); ?>" target="_blank" rel="noopener"><?php esc_html_e('See all features', 'airypress'); ?></a>
            </p>
        </div>
        <?php
    }

    /**
     * After 14 days, once per user: "Enjoying AiryPress? A review helps a lot".
     * Never on the agency's own sites.
     */
    private function renderReviewLink(): void
    {
        $since = (int) get_option(self::INSTALLED_OPTION, 0);

        if (Licensing::agency() || $since === 0 || time() - $since < 14 * DAY_IN_SECONDS
            || get_user_meta(get_current_user_id(), self::REVIEW_META, true)) {
            return;
        }

        $url = static fn (string $answer): string => wp_nonce_url(
            add_query_arg(['action' => 'airypress_review', 'answer' => $answer], admin_url('admin-post.php')),
            'airypress_review'
        );

        printf(
            '<p class="airy-review">%s <a href="%s" target="_blank" rel="noopener">%s</a> <a class="airy-review-dismiss" href="%s" aria-label="%s">&times;</a></p>',
            esc_html__('Enjoying AiryPress?', 'airypress'),
            esc_url($url('review')),
            esc_html__('A review helps a lot', 'airypress'),
            esc_url($url('dismiss')),
            esc_attr__('Don\'t ask again', 'airypress')
        );
    }

    /**
     * Records the answer to the review request, then goes to WordPress.org
     * or back to the settings page.
     */
    public function review(): void
    {
        check_admin_referer('airypress_review');
        update_user_meta(get_current_user_id(), self::REVIEW_META, time());

        if (sanitize_key(wp_unslash((string) ($_GET['answer'] ?? ''))) === 'review') {
            wp_redirect(self::REVIEW_URL); // A fixed external address.
            exit;
        }

        wp_safe_redirect(admin_url('options-general.php?page=airypress'));
        exit;
    }

    public function importSettings(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to do this.', 'airypress'));
        }

        check_admin_referer('airypress_import');

        $raw = isset($_POST['airypress_import']) && is_string($_POST['airypress_import'])
            ? wp_unslash($_POST['airypress_import'])
            : '';
        $decoded = json_decode($raw, true);

        if (! is_array($decoded)) {
            wp_safe_redirect(add_query_arg(
                ['page' => 'airypress', 'airy-error' => 'import'],
                admin_url('options-general.php')
            ) . '#tools');
            exit;
        }

        $menu = $decoded['menu'] ?? null;
        unset($decoded['menu']);

        update_option(Settings::OPTION, Settings::sanitize($decoded));

        if (class_exists(MenuStore::class) && Pro::active()) {
            if (is_array($menu)) {
                MenuStore::save($menu);
            } elseif (array_key_exists('menu', (array) json_decode($raw, true))) {
                MenuStore::reset();
            }
        }

        /**
         * Fires after settings were imported on the Tools tab.
         *
         * @param array<string, mixed> $settings The saved settings.
         */
        do_action('airypress/settings_imported', Settings::instance()->stored());

        $this->redirectSaved(__('Settings imported.', 'airypress'));
    }

    public function resetSettings(): void
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to do this.', 'airypress'));
        }

        check_admin_referer('airypress_reset');

        delete_option(Settings::OPTION);

        if (class_exists(MenuStore::class)) {
            MenuStore::reset();
        }

        /**
         * Fires after all settings and the menu layout were reset to defaults.
         */
        do_action('airypress/settings_reset');

        $this->redirectSaved(__('Settings reset to defaults.', 'airypress'));
    }

    private function redirectSaved(string $message): never
    {
        add_settings_error('airypress', 'settings_updated', $message, 'success');
        set_transient('settings_errors', get_settings_errors(), 30);

        wp_safe_redirect(add_query_arg(
            ['page' => 'airypress', 'settings-updated' => 'true'],
            admin_url('options-general.php')
        ) . '#tools');
        exit;
    }

    private function fieldName(string $path): string
    {
        return 'airypress_settings[' . implode('][', explode('.', $path)) . ']';
    }

    private function fieldId(string $path): string
    {
        return 'airy-' . str_replace('.', '-', $path);
    }

    private function version(string $relative): string
    {
        $mtime = filemtime(AIRYPRESS_DIR . $relative);

        return $mtime === false ? AIRYPRESS_VERSION : (string) $mtime;
    }
}
