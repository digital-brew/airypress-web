<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress;

use DigitalBrew\AiryPress\Licensing\Licensing;

/**
 * Removes AiryPress's data when the plugin is deleted. Freemius calls it
 * (`after_uninstall`) when licensing is on; in agency mode WordPress does,
 * through the hook registered on activation. A plugin-level uninstall.php
 * would stop Freemius' own uninstall hook from running.
 */
final class Uninstall
{
    public static function register(): void
    {
        if (Licensing::agency()) {
            register_uninstall_hook(AIRYPRESS_FILE, [self::class, 'run']);
        }
    }

    public static function run(): void
    {
        // The free and Pro copies share their data: keep it while the other
        // copy is still installed (e.g. the free one deleted after upgrading).
        if (self::otherCopyInstalled()) {
            return;
        }

        foreach ([
            'airypress_settings',
            'airypress_menu',
            'airypress_toolbar_items',
            'airypress_dashboard_widgets',
            'airypress_columns_seen',
            'airypress_columns_sortable',
            'airypress_notices_seen',
            'airypress_installed',
        ] as $option) {
            delete_option($option);
        }

        foreach (['airypress_sidebar', 'airypress_snoozed_notices', 'airypress_review_asked'] as $key) {
            delete_metadata('user', 0, $key, '', true);
        }

        foreach (['_airy_og_title', '_airy_og_description', '_airy_og_image'] as $key) {
            delete_metadata('post', 0, $key, '', true);
        }
    }

    private static function otherCopyInstalled(): bool
    {
        if (! function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $self = plugin_basename(AIRYPRESS_FILE);

        foreach (array_keys(get_plugins()) as $file) {
            if ($file !== $self && preg_match('#^airypress(-pro)?(-[\w.-]+)?/airypress\.php$#', (string) $file) === 1) {
                return true;
            }
        }

        return false;
    }
}
