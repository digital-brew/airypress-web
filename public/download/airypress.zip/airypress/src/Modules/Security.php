<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Modules;

use DigitalBrew\AiryPress\Settings\Settings;

final class Security
{
    public function register(Settings $settings): void
    {
        if (! $settings->get('security.xmlrpc', false)) {
            add_filter('xmlrpc_enabled', '__return_false');
            add_filter('wp_headers', [$this, 'removePingbackHeader']);
        }

        if ($settings->get('security.rest_users', true)) {
            add_filter('rest_endpoints', [$this, 'hideRestUsers']);
        }

        if ($settings->get('security.author_scan', true)) {
            add_action('template_redirect', [$this, 'blockAuthorScan'], 1);
        }

        if ($settings->get('security.login_language', true)) {
            add_filter('login_display_language_dropdown', '__return_false');
        }

        if ($settings->get('security.login_logo_url', true)) {
            add_filter('login_headerurl', static fn(): string => home_url('/'));
            add_filter('login_headertext', static fn(): string => (string) get_bloginfo('name'));
        }
    }

    /**
     * @param array<string, string> $headers
     *
     * @return array<string, string>
     */
    public function removePingbackHeader(array $headers): array
    {
        unset($headers['X-Pingback']);

        return $headers;
    }

    /**
     * @param array<string, mixed> $endpoints
     *
     * @return array<string, mixed>
     */
    public function hideRestUsers(array $endpoints): array
    {
        if (is_user_logged_in()) {
            return $endpoints;
        }

        unset($endpoints['/wp/v2/users']);
        unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);

        return $endpoints;
    }

    public function blockAuthorScan(): void
    {
        if (is_admin() || ! isset($_GET['author'])) {
            return;
        }

        $author = wp_unslash($_GET['author']);

        if (is_scalar($author) && is_numeric((string) $author)) {
            wp_safe_redirect(home_url('/'), 301);
            exit;
        }
    }
}
