<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Modules\Content;

use DigitalBrew\AiryPress\Settings\Settings;
use WP_User;

final class LastLogin
{
    public function register(Settings $settings): void
    {
        if (! $settings->get('tables.users.track_last_login', true)) {
            return;
        }

        add_action('wp_login', [$this, 'record'], 20, 2);
    }

    public function record(string $userLogin, WP_User $user): void
    {
        update_user_meta($user->ID, 'last_login', current_time('mysql', true));
    }
}
