<?php

declare (strict_types = 1);
namespace DigitalBrew\AiryPress\Modules\Front;

use DigitalBrew\AiryPress\Licensing\Pro;
use DigitalBrew\AiryPress\Settings\Settings;
use WP_Scripts;
final class JQuery {
    private Settings $settings;

    public function register( Settings $settings ) : void {
        $this->settings = $settings;
        if ( !$settings->get( 'frontend.jquery.enabled', true ) ) {
            add_action( 'init', [$this, 'disable'] );
            return;
        }
        if ( !$settings->get( 'frontend.jquery.migrate', true ) ) {
            add_action( 'wp_default_scripts', [$this, 'removeMigrate'] );
        }
    }

    public function disable() : void {
        if ( is_admin() ) {
            return;
        }
        wp_deregister_script( 'jquery' );
        wp_register_script(
            'jquery',
            false,
            [],
            AIRYPRESS_VERSION,
            true
        );
    }

    public function removeMigrate( WP_Scripts $scripts ) : void {
        if ( is_admin() || empty( $scripts->registered['jquery'] ) ) {
            return;
        }
        $jquery = $scripts->registered['jquery'];
        if ( is_array( $jquery->deps ) ) {
            $jquery->deps = array_diff( $jquery->deps, ['jquery-migrate'] );
        }
    }

}
