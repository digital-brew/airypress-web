<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Modules\Front;

use DigitalBrew\AiryPress\Settings\Settings;

final class Head
{
    private Settings $settings;

    public function register(Settings $settings): void
    {
        $this->settings = $settings;

        if (! $settings->get('frontend.emoji', false)) {
            $this->disableEmoji();
        }

        if (! $settings->get('frontend.feeds', false)) {
            $this->disableFeeds();
        }

        if (! $settings->get('frontend.head_links', false)) {
            $this->removeHeadLinks();
        }

        if (! $settings->get('frontend.version_strings', false)) {
            $this->stripVersionStrings();
        }

        if (! $settings->get('frontend.oembed', true)) {
            $this->disableOembed();
        }

        if ($settings->get('frontend.dns_prefetch', false)) {
            $this->removeDnsPrefetch();
        }
    }

    public function redirectFeed(): void
    {
        if (! is_feed()) {
            return;
        }

        wp_redirect(home_url(), 301);
        exit;
    }

    public function stripVersion(string $src): string
    {
        if (is_admin()) {
            return $src;
        }

        global $wp_version;

        $query = wp_parse_url($src, PHP_URL_QUERY);

        if (! is_string($query) || $query === '') {
            return $src;
        }

        parse_str($query, $args);

        if (isset($args['ver']) && (string) $args['ver'] === (string) $wp_version) {
            return remove_query_arg('ver', $src);
        }

        return $src;
    }

    private function disableEmoji(): void
    {
        remove_action('wp_head', 'print_emoji_detection_script', 7);
        remove_action('admin_print_scripts', 'print_emoji_detection_script');
        remove_action('wp_print_styles', 'print_emoji_styles');
        remove_action('admin_print_styles', 'print_emoji_styles');
        remove_action('wp_enqueue_scripts', 'wp_enqueue_emoji_styles');
        remove_action('admin_enqueue_scripts', 'wp_enqueue_emoji_styles');
        remove_filter('the_content_feed', 'wp_staticize_emoji');
        remove_filter('comment_text_rss', 'wp_staticize_emoji');
        remove_filter('wp_mail', 'wp_staticize_emoji_for_email');

        add_filter('emoji_svg_url', '__return_false');
        add_filter('tiny_mce_plugins', static function ($plugins) {
            return is_array($plugins) ? array_diff($plugins, ['wpemoji']) : $plugins;
        });
    }

    private function disableFeeds(): void
    {
        add_action('init', static function (): void {
            remove_action('wp_head', 'feed_links_extra', 3);
            remove_action('wp_head', 'feed_links', 2);
        });

        foreach ([
            'do_feed_rdf',
            'do_feed_rss',
            'do_feed_rss2',
            'do_feed_atom',
            'do_feed_rss2_comments',
            'do_feed_atom_comments',
        ] as $hook) {
            add_action($hook, [$this, 'redirectFeed'], 1);
        }

        add_action('template_redirect', [$this, 'redirectFeed'], 1);
    }

    private function removeHeadLinks(): void
    {
        add_action('init', static function (): void {
            remove_action('wp_head', 'wp_generator');
            remove_action('wp_head', 'rsd_link');
            remove_action('wp_head', 'wlwmanifest_link');
            remove_action('wp_head', 'wp_shortlink_wp_head');
            remove_action('wp_head', 'rest_output_link_wp_head');
            remove_action('wp_head', 'wp_oembed_add_discovery_links');
            remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10);
        });
    }

    private function stripVersionStrings(): void
    {
        add_filter('script_loader_src', [$this, 'stripVersion'], 15);
        add_filter('style_loader_src', [$this, 'stripVersion'], 15);
    }

    private function disableOembed(): void
    {
        add_action('init', static function (): void {
            remove_action('wp_head', 'wp_oembed_add_host_js');
        });

        add_action('wp_enqueue_scripts', static function (): void {
            wp_deregister_script('wp-embed');
        });
    }

    private function removeDnsPrefetch(): void
    {
        add_filter('wp_resource_hints', static function ($hints, $relationType) {
            if ($relationType !== 'dns-prefetch' || ! is_array($hints)) {
                return $hints;
            }

            // The emoji CDN host is derived from core's emoji URLs instead of being hardcoded: core's own
            // hint is its emoji SVG URL, and a site may point the emoji filters at another CDN.
            $emojiHosts = [];
            foreach ([apply_filters('emoji_url', ''), apply_filters('emoji_svg_url', '')] as $emojiUrl) {
                $emojiHost = is_string($emojiUrl) && $emojiUrl !== '' ? wp_parse_url($emojiUrl, PHP_URL_HOST) : null;
                if (is_string($emojiHost) && $emojiHost !== '') {
                    $emojiHosts[] = strtolower($emojiHost);
                }
            }

            return array_values(array_filter($hints, static function ($hint) use ($emojiHosts): bool {
                $url = is_array($hint) ? (string) ($hint['href'] ?? '') : (string) $hint;
                $host = wp_parse_url($url, PHP_URL_HOST);
                $path = (string) wp_parse_url($url, PHP_URL_PATH);

                return ! (
                    str_contains($path, '/images/core/emoji/')
                    || (is_string($host) && in_array(strtolower($host), $emojiHosts, true))
                );
            }));
        }, 10, 2);
    }
}
