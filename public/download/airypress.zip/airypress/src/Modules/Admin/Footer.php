<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Modules\Admin;

use DigitalBrew\AiryPress\Settings\Settings;

final class Footer
{
    private Settings $settings;

    public function register(Settings $settings): void
    {
        $this->settings = $settings;

        // PHP_INT_MAX so the AiryPress setting always wins over other
        // plugins/mu-plugins (e.g. Kinsta filters admin_footer_text at 99).
        add_filter('admin_footer_text', [$this, 'footerText'], PHP_INT_MAX);
        add_filter('update_footer', [$this, 'updateFooter'], PHP_INT_MAX);
    }

    public function footerText(mixed $text): string
    {
        $text = (string) $text;
        $custom = (string) $this->settings->get('admin.footer.text', '');

        return $custom !== '' ? wp_kses_post($custom) : $text;
    }

    /**
     * The installed WordPress version, never core's "Get Version x.y" update
     * link (on Composer sites updates are done in code). When a newer version
     * is known it is flagged (orange, see layout.css) with the new number in
     * its tooltip.
     */
    public function updateFooter(mixed $text): string
    {
        $text = (string) $text;
        if ($this->settings->get('admin.footer.hide_version', true)) {
            return '';
        }

        /* translators: %s: WordPress version. */
        $version = esc_html(sprintf(__('Version %s', 'airypress'), get_bloginfo('version', 'display')));
        $newer = $this->availableVersion();

        if ($newer === null) {
            return $version;
        }

        return sprintf(
            '<span class="airy-version-outdated" title="%s">%s</span>',
            /* translators: %s: the newer WordPress version. */
            esc_attr(sprintf(__('WordPress %s is available.', 'airypress'), $newer)),
            $version
        );
    }

    /**
     * The newer WordPress version core's update check found, if any.
     */
    private function availableVersion(): ?string
    {
        if (! function_exists('get_preferred_from_update_core')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }

        $update = get_preferred_from_update_core();

        if (! is_object($update) || ($update->response ?? '') !== 'upgrade' || empty($update->current)) {
            return null;
        }

        return (string) $update->current;
    }
}
