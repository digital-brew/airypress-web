<?php

declare (strict_types = 1);
namespace DigitalBrew\AiryPress\Modules\Admin;

use DigitalBrew\AiryPress\Licensing\Pro;
use DigitalBrew\AiryPress\Settings\Settings;
/**
 * Admin theme override layer: enqueues the forked admin CSS and behaviour JS
 * after core styles without ever deregistering core handles.
 */
final class Theme {
    /**
     * Core style handles the admin theme builds on (dependencies only).
     *
     * @var array<int, string>
     */
    /**
     * No dependencies on purpose: WordPress silently drops a stylesheet whose
     * dependency is missing, and some plugins deregister core handles on their
     * screens (SEOPress removes 'forms'), which would take the whole theme
     * down. Enqueued at admin_enqueue_scripts after core's admin styles, so it
     * still prints after them.
     *
     * @var array<int, string>
     */
    private const STYLE_DEPS = [];

    /** User meta holding a personal theme ('dark' = Default | 'modern' | 'light'); empty = site default. */
    public const SIDEBAR_META = 'airypress_sidebar';

    private const SIDEBAR_STYLES = ['dark', 'modern', 'light'];

    private Settings $settings;

    public function register( Settings $settings ) : void {
        $this->settings = $settings;
        /**
         * Filters whether the admin theme is on. Runs on `plugins_loaded`, so
         * hook it from a plugin or mu-plugin, not a theme.
         *
         * @param bool $enabled
         */
        if ( !apply_filters( 'airypress/theme/enabled', (bool) $settings->get( 'admin.theme.enabled', true ) ) ) {
            return;
        }
        add_filter( 'admin_body_class', [$this, 'bodyClass'] );
        add_action( 'admin_head', [$this, 'loadingBarScript'], 1 );
        add_action( 'admin_enqueue_scripts', [$this, 'enqueue'], 20 );
        add_filter(
            'script_loader_tag',
            [$this, 'moduleTag'],
            10,
            3
        );
        add_action( 'admin_init', [$this, 'removeColorSchemePicker'] );
        // The "session expired" dialog loads wp-login.php in an iframe: tell
        // it whether the admin is light or dark (Login::interimStyle). Core
        // builds the iframe URL in wp_auth_check_html (priority 5).
        add_action( 'admin_print_footer_scripts', [$this, 'addAuthCheckStyle'], 4 );
        add_action( 'admin_print_footer_scripts', [$this, 'removeAuthCheckStyle'], 6 );
        // List tables: the post's status and states as pills after the title
        // (so the date column drops its "Published" / "Last Modified" line).
        add_filter(
            'post_states_html',
            [$this, 'statePills'],
            10,
            3
        );
        add_filter( 'post_date_column_status', '__return_empty_string' );
        // Classic (TinyMCE) editors, ACF's too: content in Inter with the accent.
        if ( is_admin() ) {
            add_filter( 'mce_css', [$this, 'editorContentCss'] );
            add_filter( 'tiny_mce_before_init', [$this, 'editorContentAccent'] );
        }
    }

    /**
     * The sidebar style for the current user: their own choice, else the site's.
     */
    private function sidebarStyle() : string {
        return self::sidebarStyleFor( $this->settings, get_current_user_id() );
    }

    public static function sidebarStyleFor( Settings $settings, int $userId ) : string {
        $own = (string) get_user_meta( $userId, self::SIDEBAR_META, true );
        $site = (string) $settings->get( 'admin.theme.sidebar', 'dark' );
        $style = ( in_array( $own, self::SIDEBAR_STYLES, true ) ? $own : $site );
        // Modern and Light are Pro.
        if ( !Pro::active() ) {
            $style = 'dark';
        }
        /**
         * Filters a user's theme: 'dark' (Default), 'modern' or 'light'.
         *
         * @param string $style
         * @param int    $userId
         */
        $style = (string) apply_filters( 'airypress/theme/sidebar_style', $style, $userId );
        return ( in_array( $style, self::SIDEBAR_STYLES, true ) ? $style : 'dark' );
    }

    /**
     * The theme switch in the account menu: admin-ajax from admin.js
     * (the page switches instantly), admin-post with a redirect without JS.
     */
    public function switchSidebar() : void {
        // The ajax check answers a stale nonce with -1, not core's HTML "link expired" page.
        if ( wp_doing_ajax() ) {
            check_ajax_referer( 'airypress_sidebar' );
        } else {
            check_admin_referer( 'airypress_sidebar' );
        }
        $style = ( isset( $_REQUEST['style'] ) ? sanitize_key( wp_unslash( (string) $_REQUEST['style'] ) ) : '' );
        if ( in_array( $style, self::SIDEBAR_STYLES, true ) ) {
            update_user_meta( get_current_user_id(), self::SIDEBAR_META, $style );
        } elseif ( $style === 'default' ) {
            delete_user_meta( get_current_user_id(), self::SIDEBAR_META );
        }
        if ( wp_doing_ajax() ) {
            wp_send_json_success( [
                'style' => self::sidebarStyleFor( $this->settings, get_current_user_id() ),
            ] );
        }
        wp_safe_redirect( ( wp_get_referer() ?: admin_url() ) );
        exit;
    }

    public function addAuthCheckStyle() : void {
        add_filter( 'login_url', [$this, 'authCheckStyle'] );
    }

    public function removeAuthCheckStyle() : void {
        remove_filter( 'login_url', [$this, 'authCheckStyle'] );
    }

    /**
     * Default is dark; Modern and Light (light around the card) are light.
     */
    public function authCheckStyle( string $url ) : string {
        return add_query_arg( 'airy-style', ( $this->sidebarStyle() === 'dark' ? 'dark' : 'light' ), $url );
    }

    /**
     * Theme names, in menu order. 'dark' is stored for Default, so older
     * choices still apply.
     *
     * @return array<string, string>
     */
    public static function styleLabels() : array {
        return [
            'dark'   => __( 'Default', 'airypress' ),
            'modern' => __( 'Modern', 'airypress' ),
            'light'  => __( 'Light', 'airypress' ),
        ];
    }

    public function renderSidebarField( \WP_User $user ) : void {
        $value = (string) get_user_meta( $user->ID, self::SIDEBAR_META, true );
        $site = (string) $this->settings->get( 'admin.theme.sidebar', 'dark' );
        $labels = self::styleLabels();
        ?>
        <tr class="user-airypress-sidebar-wrap">
            <th scope="row"><label for="airypress-sidebar"><?php 
        esc_html_e( 'Admin theme', 'airypress' );
        ?></label></th>
            <td>
                <select name="airypress_sidebar" id="airypress-sidebar">
                    <option value="" <?php 
        selected( $value, '' );
        ?>><?php 
        /* translators: %s: the site's theme, e.g. "Light". */
        echo esc_html( sprintf( __( 'Site default (%s)', 'airypress' ), $labels[$site] ?? $labels['dark'] ) );
        ?></option>
                    <?php 
        foreach ( $labels as $key => $label ) {
            ?>
                        <option value="<?php 
            echo esc_attr( $key );
            ?>" <?php 
            selected( $value, $key );
            ?>><?php 
            echo esc_html( $label );
            ?></option>
                    <?php 
        }
        ?>
                </select>
                <p class="description"><?php 
        esc_html_e( 'Default: a dark sidebar beside a white content card. Light: a light grey sidebar joined to the content area. Modern: a dark sidebar with a light toolbar on top of the content card. Overrides the site-wide choice for this user only.', 'airypress' );
        ?></p>
            </td>
        </tr>
        <?php 
    }

    /**
     * Core verifies the profile form nonce before these hooks run.
     */
    public function saveSidebarField( int $userId ) : void {
        if ( !current_user_can( 'edit_user', $userId ) || !isset( $_POST['airypress_sidebar'] ) ) {
            return;
        }
        $value = sanitize_key( wp_unslash( (string) $_POST['airypress_sidebar'] ) );
        if ( in_array( $value, self::SIDEBAR_STYLES, true ) ) {
            update_user_meta( $userId, self::SIDEBAR_META, $value );
        } else {
            delete_user_meta( $userId, self::SIDEBAR_META );
        }
    }

    /**
     * While the theme paints the whole admin, core's "Administration Color
     * Scheme" picker is meaningless: drop its row on profile.php and
     * user-edit.php (theme off → the hook is never removed).
     */
    /**
     * Adds dist/tinymce.css to the stylesheets loaded inside TinyMCE's iframe.
     *
     * @param mixed $css Comma-separated stylesheet URLs.
     */
    public function editorContentCss( $css ) : string {
        $css = ( is_string( $css ) ? $css : '' );
        if ( !file_exists( AIRYPRESS_DIR . 'dist/tinymce.css' ) ) {
            return $css;
        }
        $url = add_query_arg( 'ver', $this->version( 'dist/tinymce.css' ), AIRYPRESS_URL . 'dist/tinymce.css' );
        return ( $css === '' ? $url : $css . ',' . $url );
    }

    /**
     * The accent for the editor content (links, quotes, selection).
     *
     * @param mixed $init
     * @return array<string, mixed>
     */
    public function editorContentAccent( $init ) : array {
        $init = ( is_array( $init ) ? $init : [] );
        $style = 'body#tinymce.wp-editor{--airy-accent:' . $this->accent() . '}';
        $init['content_style'] = trim( (string) ($init['content_style'] ?? '') . ' ' . $style );
        return $init;
    }

    /** Post states the status pill already shows. */
    private const STATUS_STATES = [
        'draft',
        'pending',
        'scheduled',
        'private'
    ];

    /**
     * Replaces core's " — Draft, Sticky" after a list-table title with pills:
     * the post's status first (Published too, coloured by status), then its
     * other states (Front Page, Sticky, Password protected…). Attachments get
     * no status pill.
     *
     * @param mixed $html
     * @param mixed $states
     * @param mixed $post
     */
    public function statePills( $html, $states, $post ) : string {
        if ( !$post instanceof \WP_Post ) {
            return ( is_string( $html ) ? $html : '' );
        }
        $pills = '';
        if ( $post->post_type !== 'attachment' ) {
            $key = $post->post_status;
            $object = get_post_status_object( $key );
            $label = ( $object !== null ? (string) $object->label : $key );
            if ( $key === 'future' && time() > (int) get_post_timestamp( $post ) ) {
                $key = 'missed';
                $label = __( 'Missed schedule', 'airypress' );
            }
            $pills .= sprintf( '<span class="post-state airy-status airy-status-%s">%s</span>', esc_attr( sanitize_html_class( $key ) ), esc_html( $label ) );
        }
        $states = ( is_array( $states ) ? $states : [] );
        $others = ( $post->post_type === 'attachment' ? $states : array_diff_key( $states, array_flip( self::STATUS_STATES ) ) );
        foreach ( $others as $state ) {
            // Labels come from core/plugins already escaped, sometimes with markup.
            $pills .= '<span class="post-state airy-state">' . wp_kses_post( (string) $state ) . '</span>';
        }
        return ( $pills === '' ? '' : '<span class="airy-states">' . $pills . '</span>' );
    }

    public function removeColorSchemePicker() : void {
        remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
    }

    /**
     * Flag the initial page load as early as possible so the accent progress
     * bar (assets/styles/admin/admin-bar.css) can start animating. Skipped on
     * the block editor, which never receives the theme.
     */
    public function loadingBarScript() : void {
        if ( $this->isBlockEditor() ) {
            return;
        }
        if ( !$this->settings->get( 'admin.theme.loading_bar', true ) ) {
            return;
        }
        echo '<script>document.documentElement.classList.add("airy-loading");</script>';
    }

    public function bodyClass( string $classes ) : string {
        if ( !$this->isBlockEditor() ) {
            $classes .= ' airy-theme';
        }
        if ( $this->isNarrowScreen() ) {
            $classes .= ' airy-narrow';
        }
        if ( $this->settings->get( 'admin.theme.accordion', true ) ) {
            $classes .= ' airy-accordion';
        }
        $style = $this->sidebarStyle();
        // Pro (Pro::freeValues keeps it 'toolbar' otherwise): the account menu
        // at the bottom of the sidebar, search in the middle of the toolbar.
        if ( $this->settings->get( 'admin_bar.account', 'toolbar' ) === 'sidebar' ) {
            $classes .= ' airy-account-sidebar';
        }
        if ( $style === 'light' ) {
            $classes .= ' airy-sidebar-light';
        } elseif ( $style === 'modern' ) {
            $classes .= ' airy-theme-modern';
        }
        return $classes;
    }

    public function enqueue() : void {
        $accent = $this->accent();
        if ( $this->isBlockEditor() ) {
            if ( $this->settings->get( 'admin.theme.block_editor', true ) && file_exists( AIRYPRESS_DIR . 'dist/editor.css' ) ) {
                wp_enqueue_style(
                    'airypress-editor',
                    AIRYPRESS_URL . 'dist/editor.css',
                    [],
                    $this->version( 'dist/editor.css' )
                );
                wp_add_inline_style( 'airypress-editor', $this->editorInlineStyle( $accent ) );
            }
            return;
        }
        if ( file_exists( AIRYPRESS_DIR . 'dist/admin.css' ) ) {
            wp_enqueue_style(
                'airypress-admin',
                AIRYPRESS_URL . 'dist/admin.css',
                self::STYLE_DEPS,
                $this->version( 'dist/admin.css' )
            );
            $rgb = str_replace( ' ', '', $this->hexToRgb( $accent ) ?? '15,192,192' );
            wp_add_inline_style( 'airypress-admin', 'body.airy-theme{--airy-accent:' . $accent . ';--airy-accent-rgb:' . $rgb . '}' );
            // Plugins screen: the Active / Inactive pills are CSS ::after
            // content, so their (translated) labels come in as variables.
            $screen = get_current_screen();
            if ( $screen !== null && in_array( $screen->id, ['plugins', 'plugins-network'], true ) ) {
                $label = static fn( string $text ): string => (string) wp_json_encode( $text, JSON_HEX_TAG | JSON_UNESCAPED_UNICODE );
                wp_add_inline_style( 'airypress-admin', 'body.airy-theme{--airy-l-active:' . $label( __( 'Active', 'airypress' ) ) . ';--airy-l-inactive:' . $label( __( 'Inactive', 'airypress' ) ) . '}' );
            }
        }
        if ( file_exists( AIRYPRESS_DIR . 'dist/admin.js' ) ) {
            wp_enqueue_script(
                'airypress-admin',
                AIRYPRESS_URL . 'dist/admin.js',
                [],
                $this->version( 'dist/admin.js' ),
                [
                    'in_footer' => true,
                    'strategy'  => 'defer',
                ]
            );
            wp_add_inline_script( 'airypress-admin', 'window.airypress = ' . wp_json_encode( [
                'accordion'  => (bool) $this->settings->get( 'admin.theme.accordion', true ),
                'loadingBar' => (bool) $this->settings->get( 'admin.theme.loading_bar', true ),
                'toasts'     => (bool) $this->settings->get( 'cleanup.toasts', true ),
                'i18n'       => [
                    'moreActions' => __( 'Actions', 'airypress' ),
                    'close'       => __( 'Close', 'airypress' ),
                    'dismiss'     => __( 'Dismiss this notice.', 'airypress' ),
                ],
            ] ) . ';', 'before' );
        }
    }

    /**
     * @param string $tag
     * @param string $handle
     * @param string $src
     */
    public function moduleTag( $tag, $handle, $src ) : string {
        if ( $handle !== 'airypress-admin' ) {
            return $tag;
        }
        $tag = preg_replace( '/\\stype=([\'"])[^\'"]*\\1/', '', $tag ) ?? $tag;
        return str_replace( '<script ', '<script type="module" ', $tag );
    }

    /** Form screens whose content reads better as a centred column. */
    private const NARROW_SCREENS = [
        'options-general',
        'options-writing',
        'options-reading',
        'options-discussion',
        'options-media',
        'options-permalink',
        'options-privacy',
        'settings_page_airypress',
        'profile',
        'user-edit',
        'user-new',
        'tools',
        'import',
        'export',
        'site-health',
        'update-core',
        'about',
        'credits',
        'freedoms',
        'privacy',
        // Plugin settings pages that are plain forms.
        'settings_page_duplicate_page_settings',
        'settings_page_two-factor-settings',
    ];

    /**
     * Whether the current screen gets the centred content column (max 900px; 1150px for AiryPress)
     * (layout.css .airy-narrow). List tables, editors and plugin apps keep
     * the full width.
     */
    private function isNarrowScreen() : bool {
        if ( !function_exists( 'get_current_screen' ) ) {
            return false;
        }
        $screen = get_current_screen();
        if ( $screen === null ) {
            return false;
        }
        /**
         * Filters the screens (screen IDs) shown in a centred column of at
         * most 900px (1150px for AiryPress).
         *
         * @param array<int, string> $screens
         */
        $screens = (array) apply_filters( 'airypress/theme/narrow_screens', self::NARROW_SCREENS );
        return in_array( $screen->id, $screens, true );
    }

    private function isBlockEditor() : bool {
        if ( !function_exists( 'get_current_screen' ) ) {
            return false;
        }
        $screen = get_current_screen();
        return $screen !== null && $screen->is_block_editor();
    }

    private function accent() : string {
        $hex = sanitize_hex_color( (string) $this->settings->get( 'admin.theme.accent', '#0fc0c0' ) );
        return ( is_string( $hex ) && $hex !== '' ? $hex : '#0fc0c0' );
    }

    /**
     * Inline variables for the block-editor accent layer. Core defines
     * --wp-admin-theme-color* on body.admin-color-* so we must set ours on
     * body.wp-admin to win; --airy-accent stays on :root for the CSS default.
     */
    private function editorInlineStyle( string $hex ) : string {
        $css = 'body.wp-admin{--airy-accent:' . $hex . ';';
        $rgb = $this->hexToRgb( $hex );
        if ( $rgb !== null ) {
            $css .= '--airy-accent-rgb:' . $rgb . ';';
            $css .= '--wp-admin-theme-color--rgb:' . $rgb . ';';
        }
        return $css . '}';
    }

    /**
     * Convert #rgb/#rrggbb to the "r, g, b" form core expects for
     * --wp-admin-theme-color--rgb (used as rgb(var(--…))).
     */
    private function hexToRgb( string $hex ) : ?string {
        $hex = ltrim( $hex, '#' );
        if ( strlen( $hex ) === 3 ) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        if ( strlen( $hex ) !== 6 || !ctype_xdigit( $hex ) ) {
            return null;
        }
        return implode( ', ', [(int) hexdec( substr( $hex, 0, 2 ) ), (int) hexdec( substr( $hex, 2, 2 ) ), (int) hexdec( substr( $hex, 4, 2 ) )] );
    }

    private function version( string $relative ) : string {
        $mtime = filemtime( AIRYPRESS_DIR . $relative );
        return ( $mtime === false ? AIRYPRESS_VERSION : (string) $mtime );
    }

}
