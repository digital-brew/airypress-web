<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Modules\Admin;

use DigitalBrew\AiryPress\Settings\Schema;
use DigitalBrew\AiryPress\Settings\Settings;

/**
 * The welcome / support dashboard widget an agency writes once for its
 * clients: logo, message, a main button (e.g. "Read our knowledge base") and links. Limiting it
 * to roles is a Pro setting (welcome.roles is empty without Pro).
 */
final class Welcome
{
    public const WIDGET_ID = 'airypress_welcome';

    private Settings $settings;

    public function register(Settings $settings): void
    {
        $this->settings = $settings;

        if ($settings->get('welcome.enabled', false)) {
            add_action('wp_dashboard_setup', [$this, 'add']);
        }
    }

    public function add(): void
    {
        $roles = array_map('strval', (array) $this->settings->get('welcome.roles', []));

        if ($roles !== [] && array_intersect($roles, (array) wp_get_current_user()->roles) === []) {
            return;
        }

        $title = trim((string) $this->settings->get('welcome.title', ''));

        wp_add_dashboard_widget(
            self::WIDGET_ID,
            esc_html($title !== '' ? $title : __('Welcome', 'airypress')),
            [$this, 'render'],
            null,
            null,
            'normal',
            'high'
        );
    }

    public function render(): void
    {
        $logo = wp_get_attachment_image((int) $this->settings->get('welcome.logo', 0), 'medium', false, ['class' => 'airy-welcome-logo', 'alt' => '']);
        $body = trim((string) $this->settings->get('welcome.body', ''));
        $label = trim((string) $this->settings->get('welcome.button_label', ''));
        $url = (string) $this->settings->get('welcome.button_url', '');
        $links = Schema::links((string) $this->settings->get('welcome.links', ''));

        echo '<style>'
            . '#airypress_welcome .airy-welcome-logo{display:block;max-width:180px;max-height:64px;width:auto;height:auto;margin:4px 0 12px}'
            . '#airypress_welcome .airy-welcome-body>:first-child{margin-top:0}'
            . '#airypress_welcome .airy-welcome-button{margin:4px 0 8px}'
            . '#airypress_welcome .airy-welcome-links{margin:12px 0 0;padding:12px 0 0;border-top:1px solid #f0f0f1;list-style:none}'
            . '#airypress_welcome .airy-welcome-links li{margin:0 0 6px}'
            . '</style>';

        echo '<div class="airy-welcome">';

        if ($logo !== '') {
            echo wp_kses_post($logo);
        }

        if ($body !== '') {
            echo '<div class="airy-welcome-body">' . wp_kses_post(wpautop($body)) . '</div>';
        }

        if ($label !== '' && $url !== '') {
            printf(
                '<p class="airy-welcome-button"><a class="button button-primary" href="%s"%s>%s</a></p>',
                esc_url($url, ['http', 'https', 'mailto', 'tel']),
                str_starts_with($url, 'http') ? ' target="_blank" rel="noopener"' : '',
                esc_html($label)
            );
        }

        if ($links !== []) {
            echo '<ul class="airy-welcome-links">';

            foreach ($links as $link) {
                printf(
                    '<li><a href="%s"%s>%s</a></li>',
                    esc_url($link['url'], ['http', 'https', 'mailto', 'tel']),
                    str_starts_with($link['url'], 'http') ? ' target="_blank" rel="noopener"' : '',
                    esc_html($link['label'])
                );
            }

            echo '</ul>';
        }

        echo '</div>';
    }
}
