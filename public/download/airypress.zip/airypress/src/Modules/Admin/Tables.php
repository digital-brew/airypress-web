<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Modules\Admin;

use DigitalBrew\AiryPress\Settings\Settings;
use WP_User_Query;

final class Tables
{
    private Settings $settings;

    public function register(Settings $settings): void
    {
        $this->settings = $settings;

        $this->users();
        $this->orders();
    }

    private function users(): void
    {
        $add = (array) $this->settings->get('tables.users.add', []);
        $remove = (array) $this->settings->get('tables.users.remove', []);

        if ($add === [] && $remove === []) {
            return;
        }

        add_filter('manage_users_columns', function (array $columns) use ($add, $remove): array {
            foreach ($remove as $column) {
                unset($columns[$column]);
            }

            foreach ($add as $column) {
                if ($column === 'registration_date') {
                    $columns['registration_date'] = __('Registration date', 'airypress');
                }
                if ($column === 'last_login') {
                    $columns['last_login'] = __('Last login', 'airypress');
                }
            }

            return $columns;
        });

        add_filter('manage_users_custom_column', [$this, 'renderUserColumn'], 10, 3);

        add_filter('manage_users_sortable_columns', function (array $columns) use ($add): array {
            if (in_array('registration_date', $add, true)) {
                $columns['registration_date'] = 'registered';
            }
            if (in_array('last_login', $add, true)) {
                $columns['last_login'] = 'last_login';
            }

            return $columns;
        });

        if (in_array('last_login', $add, true)) {
            add_action('pre_get_users', [$this, 'orderUsersByLastLogin']);
        }
    }

    /**
     * @param mixed $output
     * @param mixed $column
     * @param mixed $userId
     */
    public function renderUserColumn($output, $column, $userId): string
    {
        $column = (string) $column;
        $userId = (int) $userId;
        $format = $this->dateTimeFormat();

        if ($column === 'registration_date') {
            $user = $userId > 0 ? get_userdata($userId) : false;

            if ($user === false) {
                return '&mdash;';
            }

            $timestamp = strtotime((string) $user->user_registered);

            return $timestamp === false ? '&mdash;' : wp_date($format, $timestamp);
        }

        if ($column === 'last_login') {
            $lastLogin = get_user_meta($userId, 'last_login', true);

            if (! is_string($lastLogin) || $lastLogin === '') {
                return '&mdash;';
            }

            $timestamp = strtotime($lastLogin . ' UTC');

            return $timestamp === false ? '&mdash;' : wp_date($format, $timestamp);
        }

        return is_string($output) ? $output : '';
    }

    public function orderUsersByLastLogin(WP_User_Query $query): void
    {
        if (! function_exists('get_current_screen')) {
            return;
        }

        $screen = get_current_screen();

        if ($screen === null || $screen->id !== 'users') {
            return;
        }

        if ($query->get('orderby') !== 'last_login') {
            return;
        }

        $order = strtoupper((string) $query->get('order'));

        if (! in_array($order, ['ASC', 'DESC'], true)) {
            $order = 'ASC';
        }

        $query->set('meta_query', [
            'relation' => 'OR',
            'airy_last_login' => [
                'key' => 'last_login',
                'compare' => 'EXISTS',
            ],
            [
                'key' => 'last_login',
                'compare' => 'NOT EXISTS',
            ],
        ]);
        $query->set('orderby', 'airy_last_login');
        $query->set('order', $order);
    }

    private function orders(): void
    {
        if (! class_exists('WooCommerce')) {
            return;
        }

        if (! in_array('purchased', (array) $this->settings->get('tables.orders.add', []), true)) {
            return;
        }

        $insert = static function (array $columns): array {
            return array_slice($columns, 0, 4, true)
                + ['order_products' => __('Purchased products', 'airypress')]
                + array_slice($columns, 4, null, true);
        };

        add_filter('manage_woocommerce_page_wc-orders_columns', $insert);
        add_filter('manage_edit-shop_order_columns', $insert);

        $render = static function ($column, $orderOrId): void {
            if ((string) $column !== 'order_products') {
                return;
            }

            $order = $orderOrId instanceof \WC_Order ? $orderOrId : wc_get_order($orderOrId);

            if (! $order instanceof \WC_Order) {
                return;
            }

            foreach ($order->get_items() as $item) {
                $productId = (int) $item->get_product_id();
                $name = (string) $item->get_name();

                if ($productId <= 0) {
                    printf(
                        '%s &times; %s<br />',
                        esc_html((string) $item->get_quantity()),
                        esc_html($name)
                    );
                    continue;
                }

                printf(
                    '%s &times; <a href="%s">%s</a><br />',
                    esc_html((string) $item->get_quantity()),
                    esc_url((string) get_edit_post_link($productId)),
                    esc_html($name)
                );
            }
        };

        add_action('manage_woocommerce_page_wc-orders_custom_column', $render, 25, 2);
        add_action('manage_shop_order_posts_custom_column', $render, 25, 2);
    }

    private function dateTimeFormat(): string
    {
        return (string) get_option('date_format') . ' ' . (string) get_option('time_format');
    }
}
