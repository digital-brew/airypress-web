<?php

declare(strict_types=1);

namespace DigitalBrew\AiryPress\Modules;

use DigitalBrew\AiryPress\Settings\Settings;
use WP_Admin_Bar;

/**
 * Maintenance mode: front-end requests from visitors who can't edit content
 * get a 503 holding page. The admin, wp-login.php, REST, AJAX and cron never
 * reach template_redirect, so they keep working. Administrators can preview
 * the page at /?airy-maintenance-preview=1 whether or not it is switched on.
 */
final class Maintenance
{
    public const PREVIEW_ARG = 'airy-maintenance-preview';

    /** Users with this capability see the site normally. */
    private const BYPASS_CAP = 'edit_posts';

    private Settings $settings;

    public function register(Settings $settings): void
    {
        $this->settings = $settings;

        add_action('template_redirect', [$this, 'maybeRender'], 0);

        if ($settings->get('maintenance.enabled', false)) {
            add_action('admin_bar_menu', [$this, 'toolbarBadge'], 100);
            add_action('admin_head', [$this, 'badgeCss']);
            add_action('wp_head', [$this, 'badgeCss']);
        }
    }

    /**
     * Footer of the Maintenance settings card.
     */
    public static function renderPreviewLink(): void
    {
        printf(
            '<a class="button" href="%s" target="_blank" rel="noopener">%s</a><span>%s</span>',
            esc_url(add_query_arg(self::PREVIEW_ARG, '1', home_url('/'))),
            esc_html__('Preview the maintenance page', 'airypress'),
            esc_html__('Save your changes first. The preview works while maintenance mode is off.', 'airypress')
        );
    }

    public function maybeRender(): void
    {
        $preview = isset($_GET[self::PREVIEW_ARG]) && current_user_can('manage_options');

        if (! $preview) {
            if (! $this->settings->get('maintenance.enabled', false) || self::canBypass()) {
                return;
            }

            /**
             * Filters the Retry-After header of the maintenance page, in seconds.
             *
             * @param int $seconds
             */
            $retry = (int) apply_filters('airypress/maintenance/retry_after', 3600);

            status_header(503);

            if ($retry > 0) {
                header('Retry-After: ' . $retry);
            }
        }

        nocache_headers();
        header('Content-Type: text/html; charset=' . get_bloginfo('charset'));

        $this->render();
        exit;
    }

    /**
     * Whether the current visitor sees the site instead of the maintenance page.
     */
    public static function canBypass(): bool
    {
        /**
         * Filters whether the current visitor skips the maintenance page.
         * By default users who can edit posts do.
         *
         * @param bool $bypass
         */
        return (bool) apply_filters('airypress/maintenance/bypass', current_user_can(self::BYPASS_CAP));
    }

    public function toolbarBadge(WP_Admin_Bar $bar): void
    {
        if (! self::canBypass() || ! is_user_logged_in()) {
            return;
        }

        $bar->add_node([
            'id' => 'airy-maintenance',
            'parent' => 'top-secondary',
            'title' => esc_html__('Maintenance mode', 'airypress'),
            'href' => current_user_can('manage_options')
                ? admin_url('options-general.php?page=airypress#maintenance')
                : false,
            'meta' => [
                'title' => __('Visitors see the maintenance page. You see the site because you are logged in.', 'airypress'),
            ],
        ]);
    }

    public function badgeCss(): void
    {
        if (! is_admin_bar_showing() || ! self::canBypass()) {
            return;
        }

        // Desktop only: on phones the toolbar keeps just core's essential icons.
        echo '<style id="airypress-maintenance-badge">@media screen and (min-width:783px){'
            . '#wpadminbar #wp-admin-bar-airy-maintenance{display:flex;align-items:center;height:var(--airy-bar-h,var(--wp-admin--admin-bar--height,32px))}'
            . '#wpadminbar #wp-admin-bar-airy-maintenance>.ab-item,#wpadminbar #wp-admin-bar-airy-maintenance:hover>.ab-item,#wpadminbar #wp-admin-bar-airy-maintenance>.ab-item:focus'
            . '{height:auto;padding:0 8px;line-height:22px;border-radius:4px;background:#d63638;color:#fff}'
            . '}</style>';
    }

    private function render(): void
    {
        $title = (string) $this->settings->get('maintenance.title', '');
        $subtitle = (string) $this->settings->get('maintenance.subtitle', '');
        $body = trim((string) $this->settings->get('maintenance.body', ''));
        $background = (string) $this->settings->get('maintenance.background', '#1e1e1e');
        $text = (string) $this->settings->get('maintenance.text_color', '#ffffff');
        $image = wp_get_attachment_image_url((int) $this->settings->get('maintenance.background_image', 0), 'full');

        $view = [
            'title' => $title !== '' ? $title : (string) get_bloginfo('name'),
            'subtitle' => $subtitle,
            'body' => $body !== '' ? wpautop(wp_kses_post($body)) : '',
            'background' => $background,
            'text' => $text,
            'image' => is_string($image) ? $image : '',
            'font' => AIRYPRESS_URL . 'dist/fonts/inter-latin-wght-normal.woff2',
            'site' => (string) get_bloginfo('name'),
            'lang' => get_language_attributes(),
            'charset' => (string) get_bloginfo('charset'),
            'icon' => get_site_icon_url(64),
        ];

        /**
         * Filters the maintenance page's data. `body` is HTML; `background` and
         * `text` must stay hex colours and `image` a URL.
         *
         * @param array<string, mixed> $view
         */
        $view = array_merge($view, (array) apply_filters('airypress/maintenance/view', $view));

        // The template prints these inside <style>, so re-check filtered values.
        $view['background'] = sanitize_hex_color((string) $view['background']) ?: '#1e1e1e';
        $view['text'] = sanitize_hex_color((string) $view['text']) ?: '#ffffff';
        $view['image'] = esc_url_raw((string) $view['image']);

        /**
         * Filters the maintenance page template file.
         *
         * @param string $template Absolute path.
         */
        $template = (string) apply_filters('airypress/maintenance/template', AIRYPRESS_DIR . 'templates/maintenance.php');

        include is_readable($template) ? $template : AIRYPRESS_DIR . 'templates/maintenance.php';
    }
}
