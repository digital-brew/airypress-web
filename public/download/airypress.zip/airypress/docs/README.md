# AiryPress documentation

AiryPress turns wp-admin into a clean, modern, branded workspace. Everything is configured at **Settings → AiryPress**; each setting has a short explanation right under it.

## Start here

- [Getting started](getting-started.md) — requirements, installation (WordPress.org, zip, Composer), first five settings

## Settings, tab by tab

| Tab | Page |
| --- | --- |
| Appearance | [appearance.md](appearance.md) — admin theme, Default/Modern/Light themes, navigation speed, footer |
| Menu builder | [menu-builder.md](menu-builder.md) |
| Toolbar | [toolbar.md](toolbar.md) — visible core and plugin items, account menu |
| Dashboard | [dashboard.md](dashboard.md) — core, AiryPress and plugin widgets, welcome widget |
| Content & tables | [content-and-tables.md](content-and-tables.md) — comments/posts, post type columns, Users, WooCommerce |
| Admin clean-up | [admin-cleanup.md](admin-cleanup.md) — help tabs, nags, admin notices, Appearance screens, updates |
| Front end | [front-end.md](front-end.md) — head clean-up, jQuery |
| Security | [security.md](security.md) |
| Login | [login.md](login.md) — branded login screen |
| Maintenance | [maintenance.md](maintenance.md) |
| Analytics | [analytics.md](analytics.md) — GA4 dashboard, live visitors, tag, Search Console |
| White label | [white-label.md](white-label.md) — brand name, sidebar logo, settings access (Pro) |
| Site identity | [site-identity.md](site-identity.md) — favicon, Open Graph & X cards |
| Tools | [tools.md](tools.md) — export, import, reset |
| About | [about.md](about.md) — version, Free and Pro, documentation links, what's new |

Features marked **Pro** need AiryPress Pro; see [Free and Pro](free-and-pro.md).

## More

- [Plugin compatibility](compatibility.md)
- [FAQ & troubleshooting](faq.md)
- [For developers](developers.md) — options, constants, Composer, uninstall
