# Admin clean-up

## Admin clean-up

| Setting | Default | What it does |
| --- | --- | --- |
| Hide Help tabs | Off | Removes the "Help" drop-down tab from the top-right of admin screens. |
| Hide Screen Options | Off | Removes the "Screen Options" tab, so users can't change columns or boxes shown on a screen. |
| Hide update notices for non-administrators | Off | Hides "WordPress X is available" and maintenance notices from users who can't install updates. |
| Disable the periodic admin email confirmation screen | Off | Stops WordPress asking administrators to confirm the admin email after logging in. |
| Show “saved” messages as pop-ups | On | Success messages ("Settings saved", "Post updated", "Plugin activated") appear as a small pop-up in the top-right corner instead of a box at the top of the page. It disappears after 5 seconds (8 when it has a link such as "View post"), stays while the pointer is over it, and has a × to close it. Errors and warnings always stay on the page. Needs the admin theme. |

## Updates

**Turn off automatic updates** (off by default) stops WordPress from updating core, plugins, themes and translations by itself, including security releases, and removes the "Enable auto-updates" links. Only turn it on if you update sites yourself (Composer, a management tool). WordPress still checks for new versions — the footer version turns orange when one is available.

On sites in agency mode (`AIRYPRESS_AGENCY`, see [developers](developers.md)) automatic updates are always off and the setting isn't shown.

## Admin notices (Pro)

Plugins love notices: setup reminders, upsells, review requests. Turn on **Manage admin notices** to tidy them:

- Every plugin notice gets a **Snooze for a week** link, which hides it for that user only.
- **Tuck away all plugin notices for** — for the ticked roles, every plugin notice goes behind a small **N notices** button under the page title. Click it to see them.
- **Hidden for everyone** — notices seen on the site (plugin name and text, newest first). Ticked ones go behind the button for every user. A notice is added to this list the first time it appears.
- **Notifications in the toolbar** (off by default) — plugin notices go to a bell in the toolbar, with a count, instead of the top of every screen. Click the bell to read, follow or dismiss them. Plugin **errors** stay on the page, and so do warnings unless **Move plugin warnings to the toolbar too** is on. Hidden and snoozed notices go to the bell instead of the "N notices" button. On phones the bell opens a full-width panel.

WordPress' own messages ("Settings saved", update and error messages) are never touched. Notices that plugins add with JavaScript aren't covered.

## Appearance menu

Turn off Appearance screens a site doesn't need. A turned-off item is removed from the menu and the toolbar, and opening its screen goes to the Dashboard. All on by default.

| Toggle | Screen |
| --- | --- |
| Themes | Appearance → Themes |
| Design | The Site Editor (Appearance → Editor) for block themes |
| Customizer | Appearance → Customize (and the Customizer itself) |
| Fonts | Appearance → Fonts |
| Menus | Appearance → Menus (classic themes) |
| Widgets | Appearance → Widgets (classic themes) |
| Patterns | The Patterns screen (works independently of Design) |

Items a theme doesn't have (Menus and Widgets with block themes) don't appear anyway.

## Screen Options and Help panels

AiryPress restyles the Screen Options and Help tabs (they hang from the top of the content card) and the Help panel (topics as rounded rows, the active one highlighted).
