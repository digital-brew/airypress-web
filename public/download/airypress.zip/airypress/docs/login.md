# Login

Brand the WordPress login, lost-password and registration screens.

## Login screen

| Setting | Default | What it does |
| --- | --- | --- |
| Customise the login screen | Off | Applies the settings below: Inter font, rounded form, your logo, background and accent colour. Off = standard WordPress login. |
| Logo | — | Replaces the WordPress logo above the form, scaled to fit 320 × 120 px. Empty = WordPress logo. |
| Background colour | `#1e1e1e` | Colour behind the form. Links below the form switch between light and dark text to stay readable. |
| Background image (Pro) | — | Covers the whole screen behind the form. |
| Message above the form (Pro) | — | Optional text, e.g. who to contact for an account. Basic HTML (links) allowed. |

Buttons and focus rings use the accent colour from [Appearance](appearance.md). Use **Open the login screen** (bottom of the card) to check the result — save first; the login form shows even while you're logged in.

## Login options

| Setting | Default | What it does |
| --- | --- | --- |
| Hide language switcher on login screen | Off | Removes the language drop-down below the form. |
| Login logo links to this site | Off | The logo links to your website (instead of wordpress.org), with your site name as its text. |
