# Getting started

## Requirements

- WordPress 6.8 or newer (built and tested on 7.1)
- PHP 8.2 or newer (tested on 8.5)
- A modern browser. Page prefetch works in Chrome, Edge and other Chromium browsers; page transitions in Chromium and Safari. Other browsers simply load pages normally.

## Install

### From WordPress.org

Plugins → Add New → search **AiryPress** → Install → Activate.

### From a zip

Plugins → Add New → Upload Plugin → choose `airypress.zip` → Install → Activate.

### With Composer (Bedrock and similar)

```bash
composer require wp-plugin/airypress
```

Then activate the plugin. The package comes from the WordPress.org mirror Bedrock already includes ([WP Packages](https://wp-packages.org)); with [WPackagist](https://wpackagist.org), require `wpackagist-plugin/airypress`. See [For developers](developers.md) for more.

## Out of the box

Activating AiryPress only changes the look: the admin theme, your accent colour and a tidier toolbar (site name, Edit, My account and Search; the display name instead of "Howdy"). Clean-up, content, front-end and security settings stay as WordPress has them until you switch them on.

## Your first five minutes

1. **Appearance → Accent colour** — your brand colour for buttons, links, switches and the current menu item.
2. **Appearance → Theme** — Default, Modern for a white toolbar on top of a light grey content card, or Light for a light grey sidebar joined to the content.
3. **Toolbar** — tick only the toolbar items your clients need; untick plugin items you don't want to see.
4. **Dashboard** — tick the widgets worth keeping.
5. **Login** — turn on *Customise the login screen* and add your logo.

Then go to **Tools → Export to JSON** and keep the file: import it on your next site to start from the same setup.

## How AiryPress changes the admin

- It **adds** a layer of styles on top of WordPress' own; nothing is replaced. If you turn the admin theme off (Appearance → Enable admin theme), WordPress looks standard again and all other settings keep working.
- The block editor keeps its own layout; it only picks up your accent colour (optional).
- Phones get the admin menu as a slide-in drawer.
- Settings are stored in one database option (`airypress_settings`); the menu layout in `airypress_menu`.
