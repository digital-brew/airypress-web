# Dashboard

**Settings → AiryPress → Dashboard → Dashboard Widgets** decides exactly which widgets appear on the Dashboard home screen, for everyone. Three lists:

## Visible core widgets

WordPress' own widgets. **All shown by default.** Untick to hide: Welcome panel, Site Health, At a Glance, Activity, WordPress Events and News, Quick Draft, Network: Right Now, Network: Events and News (multisite).

WordPress' warnings about an outdated browser or PHP version always show.

## Visible AiryPress widgets (Pro)

Widgets that come with AiryPress. Default: **Site analytics** on. It needs the [Analytics](analytics.md) tab to be set up; who can see it is set there.

## Visible widgets added by plugins (Pro)

Without Pro, plugin widgets are left as the plugins add them.

Only ticked plugin widgets show; every other widget a plugin adds is removed. **All of them stay until you untick one.**

- Widgets of inactive plugins are greyed out but can be ticked in advance.
- Widgets from other plugins are added to the list the first time they appear on the Dashboard.

Known widgets: Cookie Notice (Cookie Compliance), Cookiebot (status), Gravity Forms (Forms), iubenda (Compliance status), MonsterInsights (Reports), The Events Calendar (News), WooCommerce (Status, Store setup, Recent reviews), WPConsent (Setup), Yoast SEO (Posts overview, Wincher top keyphrases).

## Welcome widget

A widget you write once for your clients, shown at the top of the Dashboard. Off by default.

| Setting | What it does |
| --- | --- |
| Show the welcome widget | Turns it on. |
| Title | The widget's heading (default "Welcome"). |
| Logo | Your agency's logo at the top of the widget. |
| Message | A few lines: who to contact, opening hours, what's included. Basic HTML allowed. |
| Button label / Button link | The main button (default "Read our knowledge base"), linking to your knowledge base, support form or `mailto:support@example.com`. No link = no button. |
| Links | One per line as `Label | address`, e.g. how-to videos and guides. |
| Show to these roles (Pro) | Only these roles see it. None ticked = everyone who can see the Dashboard. |

## Request widget (Pro)

A Dashboard widget for clients to ask for changes: a short description and a button that opens a form in a modal, with a **title**, a **message** and optional **attachments**. Each request goes to your inbox, a Slack channel or both. Off by default.

| Setting | What it does |
| --- | --- |
| Show the request widget | Turns it on. It needs at least one way of sending: email, or Slack with a webhook URL. |
| Title | The widget's and the form's heading (default "Request a change"). |
| Description | What the form is for, shown in the widget above the button. Basic HTML allowed. |
| Button label | The button that opens the form (default "Send a request"). |
| Send by email | On by default. Emails each request, with its attachments, to **Send to**. The email's Reply-To is the person who sent it, so replying answers them. |
| Send to | Usually your agency's support address. Empty = the site's administration email (Settings → General). |
| Send to Slack | Posts each request to a Slack channel through an incoming webhook. |
| Slack webhook URL | The channel's `https://hooks.slack.com/services/…` address. See **Connecting Slack** below. |
| Allow attachments | Up to 5 files, 10 MB each (or less if the server's upload limit is lower), of the types WordPress allows. Only for users who can upload media. |
| Show to these roles | Only these roles see the form. None ticked = everyone who can edit posts. |

### Connecting Slack

With **Send to Slack** on, the card shows three steps:

1. **Create the Slack app** opens Slack with an app already set up for posting to a channel (named "<site> requests"). Pick your workspace, then Next and Create.
2. Click **Install to Workspace**, choose the channel for requests and click Allow.
3. Open **Incoming Webhooks** in the app's menu, copy the webhook URL and paste it into **Slack webhook URL**.

**Send a test message** posts to the URL in the field (saved or not), so you can check it before saving. [Slack's guide to webhooks](https://docs.slack.dev/messaging/sending-messages-using-incoming-webhooks/) has more detail.

- Every request is also saved in the database, under the **Requests** menu, above Appearance (your agency's administrators only: the ones picked in White label → settings access, or every administrator if none are picked). The list shows who sent each one, whether the email and Slack message went through (e.g. "Slack failed") and its attachments. Open one to read it, or move it to the Trash. Requests are kept when the widget is turned off.
- If neither email nor Slack goes through, the request is still saved and the client is asked to contact you directly as well.
- The email is sent from the site (WordPress' usual sender) with the user's name and email in the message.
- Attachments are stored in `wp-content/uploads/airypress-requests/<random folder>/`, attached to the email and linked from the saved request and the Slack message (Slack webhooks can't carry files).
- One request per user every 30 seconds.
