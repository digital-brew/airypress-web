# Plugin compatibility

AiryPress adds a layer on top of WordPress' own admin styles and never replaces them, so most plugins just work. The plugins below were checked page by page on desktop (1440 px) and mobile (390 px) with WordPress 7.1. Where a plugin needed a fix, it's built into AiryPress.

| Plugin | Status | Notes |
| --- | --- | --- |
| WooCommerce 11 | Adjusted | React pages fit the content card; store badge centred in the toolbar; wide tab strips and the activity panel scroll on mobile |
| Gravity Forms 3.1 (+ CLI, HubSpot, Mailchimp, Webhooks) | Adjusted | Form editor toolbar and sidebars line up with the card; the New Form modal stays inside the card; dropdowns and Help pages fixed |
| Gravity SMTP | OK | |
| Yoast SEO 28 | Adjusted | React pages fit the card; notification toasts sit beside the sidebar |
| SEOPress 10 | Adjusted | Works even though it unloads a core stylesheet; its fixed header sits on the card |
| Rank Math SEO 1.0 | Adjusted | Its switches keep their own look; its notices run full width |
| ACF PRO 6.8 (+ ACF Extended, QuickEdit Fields, Gravity Forms add-on) | Adjusted | ACF fields available as list columns; WYSIWYG fields share the classic-editor style; button groups are segmented controls |
| MonsterInsights 11 | Adjusted | Settings screen no longer pushes the sidebar down |
| The Events Calendar 6.17 | Adjusted | Accent colour on its setup guide; wide Help pages scroll inside the card |
| All-in-One WP Migration 7 | Adjusted | Its forced menu colour is overridden |
| WPConsent | Adjusted | Edge-to-edge header restored |
| Beautiful and responsive cookie consent | Adjusted | No sideways scrolling on phones |
| Redirection, Akismet | Adjusted | Screen Options/Help tabs don't cover their notices |
| Complianz, CookieAdmin, Cookie Bar, Cookiebot, Cookie Notice, iubenda | OK | |
| TablePress 3.3 | Adjusted | Table editor: row numbers stay in their column; the sticky title bar and column header stick to the top of the card; the title bar spans the full width |
| Contact Form 7 6 | Adjusted | Shortcode box in the accent colour, rounded |
| Post Types Order, Duplicate Page, Enable Media Replace, Safe SVG, Simple Custom CSS and JS | OK | |
| HubSpot, Meta pixel, ShareThis, Social Intents, Better Click To Share | OK | |
| Really Simple Security, Two Factor | OK | |
| WP Migrate (Pro), Spatie Ray | OK | |
| Query Monitor | Works — server caveat | Sends very large response headers; on nginx with default buffers this causes "502 upstream sent too big header" with or without AiryPress. Raise `fastcgi_buffer_size` / `fastcgi_buffers` or keep it off in production. |

WordPress core screens are covered too, including the React-based Fonts and Connectors screens (they get the accent colour). The block editor keeps its own layout.

Something doesn't look right? Report the plugin, the admin page and a screenshot.
