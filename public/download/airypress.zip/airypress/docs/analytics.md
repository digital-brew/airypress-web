# Analytics

Two separate things live on this tab:

1. **Reports in WordPress** — a GA4 dashboard widget and a live visitor count, read from Google Analytics through a service account.
2. **Tracking** — the GA4 tag (gtag.js), the Search Console verification tag and the Meta Pixel on the website.

They work independently: you can use either or both.

## Google Analytics (reports, Pro)

| Setting | Default | What it does |
| --- | --- | --- |
| Enable Google Analytics | Off | Connects AiryPress to GA4 via a service account (see Connection). |
| GA4 property ID | — | Numeric ID from GA → Admin → Property details. Ignored when `AIRYPRESS_GA_PROPERTY_ID` is set. |
| Live visitors in the toolbar | On | "● N online" in the admin toolbar (active users in the last 30 minutes), refreshed every minute. |
| Live visitors in the toolbar on the front end | Off | Also shows the counter while browsing the website. |
| Who can see analytics | Administrator, Editor | Roles that see the widget and counter. Administrators always can. |
| Default date range | Last 28 days | The widget's first view; 7 / 28 / 90 days can be switched in the widget. |

The **Site analytics** widget itself is switched on/off under [Dashboard → Visible AiryPress widgets](dashboard.md). It shows visitors, page views, a chart, top pages, traffic sources and devices.

### Connection (one-time setup)

AiryPress reads GA4 with a Google **service account**. Its key is never stored in the database.

1. In Google Cloud, create (or pick) a project and **enable the Google Analytics Data API**.
2. **Create a service account** and download its **JSON key**.
3. In GA4 → **Admin → Property access management**, add the service-account email as a **Viewer**.
4. Tell WordPress where the key is, in `wp-config.php` or `.env` (Bedrock):

```php
define('AIRYPRESS_GA_CREDENTIALS', '/path/outside/webroot/service-account.json'); // or the raw JSON string
define('AIRYPRESS_GA_PROPERTY_ID', '123456789'); // optional; can also be set in the settings
```

```dotenv
AIRYPRESS_GA_CREDENTIALS='/srv/keys/ga-service-account.json'
AIRYPRESS_GA_PROPERTY_ID='123456789'
```

5. Back in **Analytics → Connection**, check that the credentials, JSON key, service-account email and property ID show as found, then click **Test connection**.

Reports are cached briefly to keep the dashboard fast and stay within Google's quotas.

## Tracking

| Setting | Default | What it does |
| --- | --- | --- |
| GA4 Measurement ID | — | The `G-…` ID from GA → Admin → Data streams → your web stream. When set, the Google tag is added to every page. Leave empty if another plugin (MonsterInsights, Site Kit) or Google Tag Manager already adds it — otherwise visits are counted twice. |
| Don't track logged-in editors and admins | On | No tag for anyone who can edit content. |
| Wait for cookie consent (Consent Mode) | On | Starts Google Consent Mode with analytics and ads storage **denied**, and holds the Meta Pixel back until **marketing** consent; cookie banners such as Complianz, Cookiebot or CookieAdmin grant consent (the pixel listens to the WP Consent API and Cookiebot). Only turn off if the site has no cookie banner and doesn't need one. |
| Search Console verification | — | In Search Console choose the **HTML tag** method and paste the tag (or just the code). Added to the homepage head. |
| Meta Pixel ID | — | The Pixel (dataset) ID from Meta Events Manager → Data sources. When set, the Meta Pixel is added to every page and tracks page views. Follows the two settings above (no tracking for editors; waits for marketing consent). Leave empty if Meta for WooCommerce or PixelYourSite already adds it. |
