# White label (Pro)

**Settings → AiryPress → White label** makes the admin look like your agency's product and keeps clients out of AiryPress's settings.

## Branding

| Setting | What it does |
| --- | --- |
| White label the admin | Turns on the branding below. |
| Brand name | Replaces "WordPress" at the end of the browser-tab title of admin pages: "Posts ‹ My Site — Acme". |
| Sidebar logo (dark) | Your logo at the top of the admin sidebar, scaled to fit (hidden while the sidebar is folded). Dark artwork: shown in the Light theme's light sidebar, and in every theme when there is no light version. |
| Sidebar logo (light) | Optional light or white version for the dark sidebar of the Default and Modern themes (and when the admin theme is off). Each user's theme picks the version, and it changes as soon as they switch themes. |
| Sidebar logo link | Where the logo goes, always in a new tab; empty = the Dashboard. |
| Sidebar logo position | **Top of the sidebar** (default), or **Bottom of the sidebar**: fixed at the bottom, so it stays in place while the menu scrolls. On phones it follows the last menu item. |
| Sidebar logo size | A slider for the logo's height, 20–80 px (default 36); the width follows the logo's proportions (anything wider than the sidebar is cut off at its edge). The sidebar logo and the number next to the slider change while you drag; save to keep the size. |
| Hide AiryPress from other administrators | Removes AiryPress from the Plugins screen for administrators who aren't allowed to change it (see below), so it can't be turned off by mistake. On by default. |

The login screen logo is set on the [Login](login.md) tab, the footer text on [Appearance](appearance.md), and the toolbar's WordPress logo on [Toolbar](toolbar.md).

## Settings access

**Who can change AiryPress** lists the site's administrators. Tick the ones who may open Settings → AiryPress and the menu builder, and save, import or reset settings. Everyone else keeps the tidied admin but can't change it: the page disappears from their menu and opening it directly is refused.

- The same administrators see the **Requests** menu (requests sent from the request widget).
- None ticked (default) = every administrator.
- You can't lock yourself out: whoever saves the list is always kept in it.
- If none of the ticked users exist any more, every administrator gets access again.
- In an emergency, the `airypress/settings` filter can clear the list from code (see [developers](developers.md)).
