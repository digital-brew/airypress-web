# Appearance

## Admin theme

| Setting | Default | What it does |
| --- | --- | --- |
| Enable admin theme | On | The AiryPress look: dark frame, rounded content card, Inter font, restyled menu, buttons, forms and tables. Off = standard WordPress; every other setting keeps working. |
| Accent colour | `#0fc0c0` | Current menu item, primary buttons, links, switches, focus rings, the loading bar. |
| Theme | Default | **Modern and Light are Pro.** **Default**: the sidebar and toolbar sit in the dark frame around a white card. **Modern**: the dark sidebar runs to the top of the screen and the toolbar becomes a white header on top of a light grey content card (desktop; phones keep the dark toolbar). **Light**: a light grey sidebar joined to a grey content area, with a white highlight on the current item. |
| Accordion submenus | On | Clicking a menu item with a submenu opens it in place; one section open at a time. Off: submenus open on hover as cards beside the sidebar (the current section stays open). |
| Accent colours in the block editor | On | The editor's buttons and highlights use your accent colour. Its layout is never changed. |

Settings screens, your profile, Tools, Site Health and AiryPress's own settings sit in a centred column on wide screens (at most 900px; 1150px for AiryPress and for Settings → General, Reading, Media, Permalinks, Privacy and Connectors, so they line up); list tables (Posts, Pages, Plugins…) keep the full width.

### Per-user theme (Pro)

Each user can override the theme:

- **Profile → Personal Options → Admin theme**: Site default, Default, Modern or Light. *Site default* follows the setting above.
- **Account menu** (click your name, top right) **→ Theme**: Default / Modern / Light — switches instantly and highlights the theme in use.

### Collapsed sidebar

The collapse button (the panel icon in the top-right corner of the sidebar) folds it to icons; hovering an icon opens its submenu as a card. Between 783 and 960 px wide the sidebar folds automatically.

### Row actions

In lists (posts, pages, products, users, media, categories…) the actions under each title — Edit, Quick Edit, Trash, View and any a plugin adds, such as Duplicate — are in a **⋮** menu at the end of the row. The title still opens the editor. Trash and Delete come last, in red. On phones the button sits next to the row's expand arrow. The Plugins screen keeps WordPress' own links.

**Quick Edit** opens in a modal window over the list instead of replacing the row. Close it with Cancel, the ×, Esc or a click outside; Update saves as usual. Bulk Edit keeps WordPress' own panel. Rows are centred vertically.

Each title is followed by pills: the post's status — Published (green), Pending (orange), Scheduled (blue), Missed schedule (red), Draft and Private (grey) — then any other states, such as Front Page, Sticky or Password protected. The date column shows only the date.

### Wide lists

On desktop, a list with many columns (SEO plugins, ACF fields, AiryPress' extra columns) scrolls sideways inside its own box instead of squeezing every column. Short values stay on one line, long text such as meta descriptions wraps at a readable width, and the page itself never scrolls sideways. Fewer columns? Hide some in Screen Options, or under **Content & tables → Post type columns** (Pro).

### Plugins screen

Active plugins are tinted in the accent colour and marked with an **Active** pill; the others get an **Inactive** pill and quieter text. Activate, Deactivate and Delete sit under the name without separators (Delete in red).

### Classic editor

Where WordPress uses the classic editor (WooCommerce products, ACF WYSIWYG fields, other plugins' rich-text fields), the editor gets a rounded frame, a flat toolbar with active buttons in the accent colour, a Visual/Code switch and a matching link pop-up. The text you type is shown in Inter, with links and quotes in the accent colour. The block editor is not affected.

## Navigation

| Setting | Default | What it does |
| --- | --- | --- |
| Load pages on hover | On | The browser fetches a page when you hover its link, so it opens almost instantly. Never applied to links that change something (delete, trash, activate, log out, anything with a security nonce) or to edit screens. Chromium browsers. |
| Smooth page transitions | On | Pages fade into each other while the toolbar and sidebar stay still. Chromium and Safari; off automatically for people who prefer reduced motion. |

A thin accent bar at the very top of the screen shows page-load progress.

## Footer

| Setting | Default | What it does |
| --- | --- | --- |
| Admin footer text | Empty (the DigitalBrew credit in agency mode) | Text at the bottom of every admin page. Basic HTML (links) allowed. Empty = WordPress' own text. |
| Hide the WordPress version in the footer | Off | Removes the version from the bottom-right. When shown, it's always the installed version (never WordPress' "Get Version" link) and turns orange when a newer WordPress is available. |
