# About

The last tab of Settings → AiryPress.

- **About AiryPress** — what it does, the installed version, your plan (Free, Pro or Agency licence), and links to the documentation, the changelog and support (with Pro, the contact form under Settings → AiryPress → Contact Us; without Pro, the WordPress.org forum; not shown in agency mode). With Pro, a link to your Freemius account and licence.
- **AiryPress Pro** — without Pro: what Pro adds, with *Get AiryPress Pro* and *See all features*.
- **Free and Pro** — what each plan includes, tab by tab (the same as [Free and Pro](free-and-pro.md)).
- **Documentation** — getting started, FAQ, plugin compatibility, developer notes and one link per settings tab.
- **What's new** — the first entries of the installed version's changelog.

Every other tab has a **Docs** link in its top-right corner that opens its page of this documentation.

While **White label** is on, the About tab and the Docs links are hidden, so a branded admin doesn't point clients to AiryPress; the AiryPress Pro card then stays on the Tools tab.
